package xxx;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import java.awt.Button;
import java.awt.CheckboxMenuItem;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Transceiver implements Serializable {

 public static final boolean DefindCheckRFDevice = false;
 private static final long serialVersionUID = -6868716251078362877L;
 public LoraUtil mloralib;
 private ArrayList<String> mLoRaSerialPortString;
 private String mDeviceID;
 public byte Freq1 = 1;
 public byte Freq2 = 101;
 public byte Freq3 = 108;
 public byte Power = 3;
 public int m_BaudRate = 9600;
 private Choice mUIComPortName;
 private int tUITop = 30;
 private TextArea recevieText;
 private TextArea sendText;
 private Choice mChoiceRecevieDisplay;
 private Frame mainFrame;
 private Label labelMessage;
 private Label labelLoRaStatus;
 private Label mLabelStatus;
 private Label mLabelID;
 private Label mLabelFireware;
 private Choice ChoiceKind;
 private String mDomainName = "http://dashboard.local";
 public String[] mURL;
 public String[][] mStr;
 private Transceiver transceiverFrameClass;
 public App app;
 public int lan;
 public String StringLogFileName;
 public String TextFieldUrl;
 public String checkBoxSaveLog;
 public String checkBoxUpload;
 public String checkBoxDashboard;
 public String Frequency;
 public String PersonId;
 public String ProjectId;
 public String APIKEY;
 public long mCounter;
 static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
 static SecureRandom rnd = new SecureRandom();
 private ThreadRecevieText mThreadRecevieText;

 public void savePreference(String PREF_NAME, String newValue) {
  java.util.prefs.Preferences prefs = java.util.prefs.Preferences.userNodeForPackage(this.getClass());
  prefs.put(PREF_NAME, newValue);
 }

 public String loadPreferences(String PREF_NAME, String defaultValue) {
  java.util.prefs.Preferences prefs = java.util.prefs.Preferences.userNodeForPackage(this.getClass());
  String propertyValue = prefs.get(PREF_NAME, defaultValue);
  return propertyValue;
 }

 public Transceiver() {
  this.mURL = new String[]{this.mDomainName + "AjaxPerson.php?action=login", this.mDomainName + "AjaxPerson.php?action=create&groupid=0&level=0&FBID=0", this.mDomainName + "AjaxIoTProjects.php?action=selectPersonalId&IoT=1", this.mDomainName + "AjaxIoTProjects.php?action=create&IoT=1", this.mDomainName + "AjaxIoTWidgets.php?action=List", this.mDomainName + "AjaxIoTWidgets.php?action=create&IoT=1", this.mDomainName + "AjaxIoTWidgets.php?action=ListDB", this.mDomainName + "page_IoT_index.php?device=LoRa&IoT=1&share=1&projectid=", this.mDomainName + "AjaxIoTTable.php?action=upload"};
  this.mStr = new String[][]{{"Step1:", "步驟 1:"}, {"Select LoRa Com Port", "RF LoRa 設備"}, {"Reload", "搜尋LoRa設備"}, {"Searching:", "搜尋中LoRa"}, {"Done", "完成"}, {"Step2:", "步驟 2:"}, {"Setup device", "設定設備"}, {"Stauts: ", "設備狀態:"}, {"No LoRa Device", "沒有LoRa設備"}, {"MAC Address:", "MAC 地址："}, {"Fireware Version:", "韌體版本:"}, {"Broadcast", "廣播Broadcast"}, {"Node (Client)", "節點端 Node"}, {"Gateway (Server)", "伺服器端 Gateway"}, {"Preferences", "更多設定"}, {"Step3:", "步驟 3:"}, {"", ""}, {"", ""}, {"", ""}, {"Send data", "傳送的資料"}, {"Send", "送出"}, {"LoRa Device Selected: ", "LoRa設備被選取:"}, {"LoRa Device Setup to: ", "LoRa設備被設定為:"}, {"Open LoRa Device: ", "LoRa設備連接中:"}, {"Open LoRa", "啟動LoRa"}, {"Close LoRa", "關閉LoRa"}, {"Turn On LoRa ID ", "使用中LoRa設備編號"}, {"LoRa Turn Close", "LoRa未啟動"}, {"", ""}, {"", ""}, {"", ""}, {"Clear", "清除"}, {"Receive data ", "收到的資料"}, {"Text (UTF-8):", "UTF-8  文字"}, {"Hex (00 to ff) for E.g 01,aa", "16進位數字 (00 到 ff) 例如：01,aa"}, {"Decimal (0 to 255) E.g: 1,122,255", "10進位 (0-255)  例如: 1,122,255 "}, {"File:", "檔案"}, {"", ""}, {"", ""}, {"", ""}, {"English", "English"}, {"Traditional Chinese", "繁體中文"}, {"Send a lot of data", "送大量資料"}, {" isn't RF LoRa Device", " 不是RF LoRa 設備"}, {"RF LoRa Device working, now.", "RF LoRa 工作中"}, {"Upload to Dashboard", "上傳到儀表板"}, {"Open Dashboard", "打開儀表板"}, {"save data to", "儲存資料到"}, {"http://127.0.0.1/index.php?data=", "http://127.0.0.1/index.php?data="}, {"LoRa Setup:", "設定LoRa設備:"}, {"frequency MHz(137.00~1020.00)default 915", "頻率MHz(137.00 ~ 1020.00,內定915.00:"}, {"Power( default 5dBm):", "功率 (內定5dBm):"}, {"When Receive Data:", "當接收到資料:"}, {"Upload to HTTP (URL+data)", "上傳到網路HTTP+data"}, {"Upload to MQTT", "上傳到MQTT"}, {"Data can be spread to the Internet, Dashboard etc.,see \"Preferences\".", "接收到資料時還可以傳到網路、Dashboard、MQTT，請在「更多設定」選取"}, {"Application Setup", "軟體設定"}, {"Language:", "語言:"}, {"Need to re-start application for the new settings.", "需重新開啟應用程式，才會執行新的設定"}, {"Remember to choose, open and execute immediately next time", "記住選擇的APP，下次立即開啟和啟動該APP"}, {"COM Port cannnot coneected.", "這個COM Port無法使用，不是UART 設備"}, {"Com Port baud rates, (RF LoRa has 9600 or 115200)", "傳輸速度(RF LoRa 有 9600 或 115200)"}};
  this.lan = 0;
  this.StringLogFileName = "RF.csv";
  this.data_init();
  if (this.mloralib == null) {
   this.mloralib = new LoraUtil(this.m_BaudRate, 193);
  }

  this.mDeviceID = "";
  this.transceiverFrameClass = this;
 }

 public void init(App app) {
  this.app = app;
  this.mainFrame = new Frame("RF LoRa Application");
  this.mainFrame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent windowEvent) {
    Transceiver.this.TreadStop();
    if (Transceiver.this.mloralib != null) {
     Transceiver.this.mloralib.FunLora_close();
    }

    if (Transceiver.this.app != null) {
     Transceiver.this.app.mUI.mainFrame.setVisible(true);
     Transceiver.this.mainFrame.setVisible(false);
    } else {
     System.exit(0);
    }

   }
  });
  this.mainFrame.setSize(600, 550);
  this.mainFrame.setMinimumSize(new Dimension(600, 550));
  this.mainFrame.setMaximumSize(new Dimension(600, 550));
  this.mainFrame.setResizable(false);
  this.mainFrame.setLayout((LayoutManager)null);
  this.ui_Step1(this.mainFrame);
  this.ui_Step2(this.mainFrame);
  this.ui_Step3(this.mainFrame);
  this.mainFrame.setVisible(true);
  this.mainFrame.addComponentListener(new ComponentListener() {
   public void componentResized(ComponentEvent e) {
   }

   public void componentMoved(ComponentEvent e) {
   }

   public void componentShown(ComponentEvent e) {
   }

   public void componentHidden(ComponentEvent e) {
   }
  });
  this.showMenu();
  this.data_app_dashboard();
 }

 private void ui_Setp1_OpenComPort() {
  if (this.mLoRaSerialPortString != null && this.mLoRaSerialPortString.size() > 0) {
   this.labelMessage.setText(this.mStr[23][this.lan] + this.mUIComPortName.getSelectedItem());
   this.mloralib.SerialPort_setSerialPort(this.mUIComPortName.getSelectedItem());
  }

 }

 private void data_init() {
  String t1 = this.loadPreferences("Language", "0");
  if (t1 != "") {
   this.lan = Integer.parseInt(t1);
  }

  this.StringLogFileName = this.loadPreferences("StringLogFileName", "app.csv");
  this.TextFieldUrl = this.loadPreferences("TextFieldUrl", "http://127.0.0.1/index.php?data=");
  this.checkBoxSaveLog = this.loadPreferences("checkBoxSaveLog", "false");
  this.checkBoxUpload = this.loadPreferences("checkBoxUpload", "false");
  this.checkBoxDashboard = this.loadPreferences("checkBoxDashboard", "true");
  this.Frequency = this.loadPreferences("Frequency", "915.00");
  float tFloatFrequency = Float.parseFloat(this.Frequency);
  tFloatFrequency *= 100.0F;
  int tIntFrequency = (int)tFloatFrequency;
  int tFreq1 = tIntFrequency / 65536;
  int tFreq2 = (tIntFrequency - tFreq1 * 65536) / 256;
  int tFreq3 = tIntFrequency % 256;
  this.Freq1 = (byte)tFreq1;
  this.Freq2 = (byte)tFreq2;
  this.Freq3 = (byte)tFreq3;
  String tPower = this.loadPreferences("Power", "3");
  this.Power = (byte)Integer.parseInt(tPower);
  this.ProjectId = this.loadPreferences("ProjectId", "60");
  this.mDeviceID = this.loadPreferences("mDeviceID", "010000D5");
  this.APIKEY = this.loadPreferences("APIKEY", "");
  this.mCounter = Long.parseLong(this.loadPreferences("mCounter", "0"));
  String t4 = this.loadPreferences("BaudRate", "115200");
  this.m_BaudRate = Integer.parseInt(t4);
 }

 private void ui_Setp1_listPorts() {
  this.labelMessage.setText(this.mStr[3][this.lan]);

  try {
   this.mLoRaSerialPortString = this.mloralib.serial_allPorts();
   this.mUIComPortName.removeAll();
   if (this.mLoRaSerialPortString.size() > 0) {
    for(int i = 0; i < this.mLoRaSerialPortString.size(); ++i) {
     this.mUIComPortName.add(((String)this.mLoRaSerialPortString.get(i)).toString());
    }
   } else {
    this.mUIComPortName.add(this.mStr[1][this.lan]);
   }

   this.ui_Setp1_OpenComPort();
  } catch (Exception e1) {
   e1.printStackTrace();
  }

 }

 public String FunHTTPPost(String urlString, String PostData) {
  StringBuilder sb = new StringBuilder();
  String Data = PostData;

  try {
   URL url = new URL(urlString);
   HttpURLConnection con = (HttpURLConnection)url.openConnection();
   con.setRequestMethod("POST");
   con.setDoOutput(true);
   con.getOutputStream().write(Data.getBytes("UTF-8"));
   con.getInputStream();
   int HttpResult = con.getResponseCode();
   if (HttpResult == 200) {
    BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
    String line = null;

    while((line = br.readLine()) != null) {
     sb.append(line + "\n");
    }

    br.close();
    return sb.toString();
   }
  } catch (ProtocolException e) {
   e.printStackTrace();
  } catch (UnsupportedEncodingException e) {
   e.printStackTrace();
  } catch (IOException e) {
   e.printStackTrace();
  }

  return "";
 }

 private String FunRandomString(int len) {
  StringBuilder sb = new StringBuilder(len);

  for(int i = 0; i < len; ++i) {
   sb.append("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".length())));
  }

  return sb.toString();
 }

 public String FunHTTP(String urlString) {
  String data3 = "";

  try {
   URL url = new URL(urlString);

   try {
    URLConnection conn = url.openConnection();
    InputStream is = conn.getInputStream();
    BufferedReader br = new BufferedReader(new InputStreamReader(is, "utf8"));
    StringBuffer sb = new StringBuffer();
    String line = "";

    while((line = br.readLine()) != null) {
     sb.append(line);
    }

    data3 = sb.toString();
   } catch (IOException e) {
    e.printStackTrace();
   }
  } catch (MalformedURLException e) {
   e.printStackTrace();
  }

  return data3;
 }

 public String data_app_dashboard_01_login(String mDeviceID) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[0], "email=" + mDeviceID + "&password=" + mDeviceID);
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }

    if ("OK".equals(result) && "1".equals(totalRecordCount)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("PersonId") ? obj3.get("PersonId").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    // Retaining your original empty catch block behavior here
   }
  }

  return "";
 }

 public String data_app_dashboard_02_CreateAccount(String mDeviceID) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[1], "Name=" + mDeviceID + "&email=" + mDeviceID + "&password=" + mDeviceID + "&BirthDate=&idNumber=&Phone=&EmergencyPhone=&EmergencyPeople=&deviceID=&Memo=");
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result)) {
     JsonObject obj3 = obj2.getAsJsonObject("Record");
     if (obj3 != null && obj3.has("PersonId")) {
      return obj3.get("PersonId").getAsString();
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_03_ListProject(String mDeviceID, String PersonalId) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[2], "PersonalId=" + PersonalId);
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }

    if ("OK".equals(result)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("id") ? obj3.get("id").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_04_CreateProject(String mDeviceID, String PersonalId) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[3], "projectName=" + mDeviceID + "&imagefilename2=&description=" + mDeviceID + "&instructions=" + mDeviceID + "&PersonalId=" + PersonalId + "&shared=1&block=&device=");
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }

    if ("OK".equals(result) && "1".equals(totalRecordCount)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("PersonId") ? obj3.get("PersonId").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_05_ListIoTWidgets(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[4], "IoTProjectsId=" + IoTProjectsId);
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result) && obj2.has("maxid")) {
     return obj2.get("maxid").getAsString();
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_06_CreateIoTWidgets(String mDeviceID, String PersonId, String IoTProjectsId, String maxid, String APIKEY, String iData, String iDatatype) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[5], "Data=" + iData + "&OwnerId=" + PersonId + "&Datatype=" + iDatatype + "&IoTProjectsId=" + IoTProjectsId + "&IoTWidgetID=" + maxid + "&title=appLoRa&APIKEY=" + APIKEY);
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("id") ? obj3.get("id").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_07_ListIoTWidgetsDB(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[6], "IoTProjectsId=" + IoTProjectsId + "&Datatype='database'");
   System.out.println(" URL: " + t1);

   try {
    // In Gson 2.8.6+, parseString() is the modern static method to parse raw JSON
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    // Extract the result safely as strings
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCountStr = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "0";

    System.out.println(result);
    System.out.println(totalRecordCountStr);

    if ("OK".equals(result)) {
     if (!totalRecordCountStr.isEmpty()) {
      int tintTotalRecordCount = Integer.parseInt(totalRecordCountStr);
      if (tintTotalRecordCount == 0) {
       return "";
      }

      // Extract the JSON array and its first object
      JsonArray array = obj2.getAsJsonArray("Records");
      if (array != null && !array.isEmpty()) {
       JsonObject obj3 = array.get(0).getAsJsonObject();
       return obj3.get("id").getAsString();
      }
     }
    }
   } catch (JsonSyntaxException | IllegalStateException | NumberFormatException e) {
    // Catches malformed JSON, incorrect type casting, or integer parsing failures
    e.printStackTrace();
   }
  }

  return "";
 }

 public String data_app_dashboard_08_GetAPIKEY(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (mDeviceID.length() > 0) {
   String t1 = this.FunHTTPPost(this.mURL[6], "IoTProjectsId=" + IoTProjectsId + "&Datatype='database'");
   System.out.println(" URL: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();

    // Extract the result safely
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    System.out.println(result);
    System.out.println(totalRecordCount);

    if ("OK".equals(result)) {
     if (totalRecordCount.length() > 0) {
      int tintTotalRecordCount = Integer.parseInt(totalRecordCount);
      if (tintTotalRecordCount == 0) {
       return "";
      }

      // Extract the JSON array and parse the API key
      JsonArray array = obj2.getAsJsonArray("Records");
      if (array != null && !array.isEmpty()) {
       JsonObject obj3 = array.get(0).getAsJsonObject();
       return obj3.has("APIKEY") ? obj3.get("APIKEY").getAsString() : "";
      }
     }
    }
   } catch (JsonSyntaxException | IllegalStateException | NumberFormatException e) {
    // Catching NumberFormatException here just in case TotalRecordCount returns non-numeric garbage
    e.printStackTrace();
   }
  }

  return "";
 }

 public void data_app_dashboard() {
  if (this.mDeviceID.length() == 0) {
   this.mDeviceID = "010000D5";
  }

  System.out.println(" mDeviceID: " + this.mDeviceID);
  this.PersonId = this.data_app_dashboard_01_login(this.mDeviceID);
  if (this.PersonId.length() != 0) {
   if (this.PersonId == "0") {
    this.PersonId = this.data_app_dashboard_02_CreateAccount(this.mDeviceID);
    if (this.PersonId.length() == 0) {
     return;
    }
   }

   if (this.PersonId != "0") {
    this.ProjectId = this.data_app_dashboard_03_ListProject(this.mDeviceID, this.PersonId);
    if (this.ProjectId == "0") {
     this.ProjectId = this.data_app_dashboard_04_CreateProject(this.mDeviceID, this.PersonId);
    }

    String IoTWidgetsId = this.data_app_dashboard_07_ListIoTWidgetsDB(this.mDeviceID, this.PersonId, this.ProjectId);
    if (IoTWidgetsId.length() == 0) {
     String maxid = this.data_app_dashboard_05_ListIoTWidgets(this.mDeviceID, this.PersonId, this.ProjectId);
     int intmaxid = Integer.parseInt(maxid);
     maxid = Integer.toString(intmaxid + 1);
     String date = (new SimpleDateFormat("yyyMMddHH")).format(new Date());
     this.APIKEY = date + this.FunRandomString(5);
     this.APIKEY = this.ProjectId + "-" + this.mDeviceID;
     IoTWidgetsId = this.data_app_dashboard_06_CreateIoTWidgets(this.mDeviceID, this.PersonId, this.ProjectId, maxid, this.APIKEY, this.APIKEY, "database");
     System.out.println(IoTWidgetsId);
    }

    this.APIKEY = this.data_app_dashboard_08_GetAPIKEY(this.mDeviceID, this.PersonId, this.ProjectId);
    this.savePreference("APIKEY", this.APIKEY);
    this.savePreference("ProjectId", this.ProjectId);
    this.savePreference("mDeviceID", this.mDeviceID);
   }

  }
 }

 public void ui_Step1(Frame mainFrame) {
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mStr[0][this.lan]);
  l1.setSize(80, 30);
  mainFrame.add(l1);
  l1.setLocation(10, 20 + this.tUITop);
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mStr[1][this.lan]);
  l2.setSize(140, 30);
  mainFrame.add(l2);
  l2.setLocation(10, 40 + this.tUITop);
  this.mUIComPortName = new Choice();
  this.mUIComPortName.setBounds(100, 100, 250, 30);
  this.mUIComPortName.add(this.mStr[1][this.lan]);
  mainFrame.add(this.mUIComPortName);
  this.mUIComPortName.setLocation(155, 25 + this.tUITop + this.mUIComPortName.size().height / 2);
  this.mUIComPortName.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    try {
     String data = Transceiver.this.mStr[21][Transceiver.this.lan] + Transceiver.this.mUIComPortName.getItem(Transceiver.this.mUIComPortName.getSelectedIndex());
     Transceiver.this.labelMessage.setText(data);
     Transceiver.this.ui_Setp1_OpenComPort();
    } catch (Exception var3) {
     Transceiver.this.labelMessage.setText(Transceiver.this.mStr[25][Transceiver.this.lan]);
    }

   }
  });
  Button refreshButton = new Button(this.mStr[2][this.lan]);
  refreshButton.setBounds(100, 100, 130, 30);
  mainFrame.add(refreshButton);
  refreshButton.setLocation(410, 25 + this.tUITop + refreshButton.size().height / 2);
  refreshButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    Transceiver.this.ui_Setp1_listPorts();
   }
  });
  this.labelMessage = new Label();
  this.labelMessage.setAlignment(0);
  this.labelMessage.setText("Status:");
  this.labelMessage.setSize(mainFrame.size().width - 250, 25);
  this.labelMessage.setBackground(Color.lightGray);
  mainFrame.add(this.labelMessage);
  int y = mainFrame.size().height - 25;
  if (LoraUtil.OS.startsWith("Windows")) {
   y = 442;
  }

  this.labelMessage.setLocation(0, y);
  this.labelLoRaStatus = new Label();
  this.labelLoRaStatus.setAlignment(2);
  this.labelLoRaStatus.setText(this.mStr[27][this.lan]);
  this.labelLoRaStatus.setSize(250, 25);
  this.labelLoRaStatus.setBackground(Color.lightGray);
  mainFrame.add(this.labelLoRaStatus);
  y = mainFrame.size().height - 25;
  if (LoraUtil.OS.startsWith("Windows")) {
   y = 442;
  }

  this.labelLoRaStatus.setLocation(mainFrame.size().width - 250, y);
  Label lineLabel = new Label();
  lineLabel.setAlignment(0);
  lineLabel.setText("");
  lineLabel.setSize(mainFrame.size().width, 1);
  lineLabel.setBackground(Color.lightGray);
  mainFrame.add(lineLabel);
  lineLabel.setLocation(0, 75 + this.tUITop);
  this.ui_Setp1_listPorts();
 }

 public void ui_Step2(final Frame mainFrame) {
  int y = 60;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mStr[5][this.lan]);
  l1.setSize(90, 25);
  mainFrame.add(l1);
  l1.setLocation(10, y + 20 + this.tUITop);
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mStr[6][this.lan]);
  l2.setSize(100, 30);
  mainFrame.add(l2);
  l2.setLocation(10, y + 40 + this.tUITop);
  this.mLabelStatus = new Label();
  this.mLabelStatus.setAlignment(0);
  this.mLabelStatus.setText(this.mStr[7][this.lan] + this.mStr[8][this.lan]);
  this.mLabelStatus.setSize(400, 25);
  mainFrame.add(this.mLabelStatus);
  this.mLabelStatus.setLocation(130, y + 20 + this.tUITop);
  this.mLabelID = new Label();
  this.mLabelID.setAlignment(0);
  this.mLabelID.setText(this.mStr[9][this.lan]);
  this.mLabelID.setSize(400, 25);
  mainFrame.add(this.mLabelID);
  this.mLabelID.setLocation(300, y + 40 + this.tUITop);
  this.mLabelFireware = new Label();
  this.mLabelFireware.setAlignment(0);
  this.mLabelFireware.setText(this.mStr[10][this.lan]);
  this.mLabelFireware.setSize(400, 25);
  mainFrame.add(this.mLabelFireware);
  this.mLabelFireware.setLocation(130, y + 40 + this.tUITop);
  final Choice LoRaModeChoice = new Choice();
  LoRaModeChoice.setBounds(100, 100, 170, 30);
  LoRaModeChoice.add(this.mStr[11][this.lan]);
  LoRaModeChoice.add(this.mStr[12][this.lan]);
  LoRaModeChoice.add(this.mStr[13][this.lan]);
  mainFrame.add(LoRaModeChoice);
  LoRaModeChoice.setLocation(125, y + 50 + this.tUITop + LoRaModeChoice.size().height / 2);
  LoRaModeChoice.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    String data = Transceiver.this.mStr[22][Transceiver.this.lan] + LoRaModeChoice.getItem(LoRaModeChoice.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
   }
  });
  final Button startButton = new Button(this.mStr[24][this.lan]);
  startButton.setBounds(100, 100, 115, 30);
  mainFrame.add(startButton);
  startButton.setLocation(290, y + 50 + startButton.size().height / 2 + this.tUITop);
  startButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    if (Transceiver.this.mThreadRecevieText != null) {
     Transceiver.this.labelMessage.setText(Transceiver.this.mStr[25][Transceiver.this.lan]);
     Transceiver.this.labelLoRaStatus.setText(Transceiver.this.mStr[27][Transceiver.this.lan]);
     startButton.setLabel(Transceiver.this.mStr[24][Transceiver.this.lan]);
     Transceiver.this.mDeviceID = "";
     Transceiver.this.TreadStop();
     Transceiver.this.mloralib.FunLora_close();
     Transceiver.this.mLabelStatus.setText(Transceiver.this.mStr[7][Transceiver.this.lan] + Transceiver.this.mStr[8][Transceiver.this.lan]);
     Transceiver.this.mLabelID.setText(Transceiver.this.mStr[9][Transceiver.this.lan]);
     Transceiver.this.mLabelFireware.setText(Transceiver.this.mStr[10][Transceiver.this.lan]);
    } else {
     Transceiver.this.labelMessage.setText(Transceiver.this.mStr[24][Transceiver.this.lan]);
     Transceiver.this.mDeviceID = Transceiver.this.mloralib.GetDeviceID();
     Transceiver.this.TreadStop();
     startButton.setLabel(Transceiver.this.mStr[25][Transceiver.this.lan]);
     String StringID = Integer.toString(Transceiver.this.mloralib.GetFirmwareVersion());
     Transceiver.this.labelLoRaStatus.setText(Transceiver.this.mStr[26][Transceiver.this.lan] + Transceiver.this.mDeviceID + "," + Transceiver.this.mStr[10][Transceiver.this.lan] + ":" + StringID);
     Transceiver.this.mLabelStatus.setText(Transceiver.this.mStr[26][Transceiver.this.lan] + Transceiver.this.mDeviceID + "," + Transceiver.this.mStr[10][Transceiver.this.lan] + ":" + StringID);
     Transceiver.this.mLabelID.setText(Transceiver.this.mStr[9][Transceiver.this.lan] + Transceiver.this.mDeviceID);
     Transceiver.this.mLabelFireware.setText(Transceiver.this.mStr[10][Transceiver.this.lan] + StringID);
     Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
     Transceiver.this.TreadStart();
     Transceiver.this.labelMessage.setText(Transceiver.this.mStr[44][Transceiver.this.lan]);
    }

   }
  });
  Button preferencesButton = new Button(this.mStr[14][this.lan]);
  preferencesButton.setBounds(100, 100, 130, 30);
  mainFrame.add(preferencesButton);
  preferencesButton.setLocation(410, y + 50 + this.tUITop + preferencesButton.size().height / 2);
  preferencesButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    Transceiver.this.labelMessage.setText(Transceiver.this.mStr[12][Transceiver.this.lan]);
    new Preferences(Transceiver.this.transceiverFrameClass);
   }
  });
  Label lineLabel = new Label();
  lineLabel.setAlignment(0);
  lineLabel.setText("");
  lineLabel.setSize(mainFrame.size().width, 1);
  lineLabel.setBackground(Color.lightGray);
  mainFrame.add(lineLabel);
  lineLabel.setLocation(0, y + 100 + this.tUITop);
 }

 public void ui_Step3(Frame mainFrame) {
  int y = 140;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mStr[15][this.lan]);
  l1.setSize(100, 25);
  mainFrame.add(l1);
  l1.setLocation(10, y + 30 + this.tUITop);
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mStr[19][this.lan]);
  l2.setSize(100, 30);
  mainFrame.add(l2);
  l2.setLocation(10, y + 50 + this.tUITop);
  this.ChoiceKind = new Choice();
  this.ChoiceKind.setBounds(100, 100, 180, 30);
  this.ChoiceKind.add(this.mStr[33][this.lan]);
  this.ChoiceKind.add(this.mStr[34][this.lan]);
  this.ChoiceKind.add(this.mStr[35][this.lan]);
  mainFrame.add(this.ChoiceKind);
  this.ChoiceKind.setLocation(125, y + 35 + this.ChoiceKind.size().height / 2 + this.tUITop);
  this.ChoiceKind.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    String data = "Setup: " + Transceiver.this.ChoiceKind.getItem(Transceiver.this.ChoiceKind.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
   }
  });
  Button buttonSend = new Button(this.mStr[20][this.lan]);
  buttonSend.setBounds(100, 100, 120, 30);
  mainFrame.add(buttonSend);
  buttonSend.setLocation(310, y + 35 + buttonSend.size().height / 2 + this.tUITop);
  buttonSend.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    Transceiver.this.TreadStop();

    try {
     TimeUnit.MILLISECONDS.sleep(100L);
    } catch (InterruptedException e1) {
     e1.printStackTrace();
    }

    Transceiver.this.mloralib.WriteMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
    String tSendTextString = Transceiver.this.sendText.getText();
    Transceiver.this.labelMessage.setText(Transceiver.this.mStr[20][Transceiver.this.lan] + ":" + tSendTextString);

    try {
     TimeUnit.MILLISECONDS.sleep(100L);
    } catch (InterruptedException e1) {
     e1.printStackTrace();
    }

    if (Transceiver.this.ChoiceKind.getSelectedIndex() == 0) {
     int len = tSendTextString.length();
     if (len > 16) {
      len = 16;
     }

     byte[] data = tSendTextString.getBytes(StandardCharsets.UTF_8);
     Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len);
    } else if (Transceiver.this.ChoiceKind.getSelectedIndex() == 1) {
     try {
      String[] parts = tSendTextString.split(",");
      int len1 = parts.length;
      int len = tSendTextString.length();
      if (len1 > 16) {
       len1 = 16;
      }

      byte[] data = new byte[len1];

      for(int i = 0; i < len1; ++i) {
       data[i] = (byte)((int)Long.parseLong(parts[i], 16));
      }

      Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len1);
     } catch (NumberFormatException var12) {
     }
    } else if (Transceiver.this.ChoiceKind.getSelectedIndex() == 2) {
     try {
      String[] parts = tSendTextString.split(",");
      int len1 = parts.length;
      int len = tSendTextString.length();
      if (len1 > 16) {
       len1 = 16;
      }

      byte[] data = new byte[len1];

      for(int i = 0; i < len1; ++i) {
       data[i] = (byte)((int)Long.parseLong(parts[i], 10));
      }

      Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len1);
     } catch (NumberFormatException var11) {
     }
    }

    try {
     TimeUnit.MILLISECONDS.sleep(100L);
    } catch (InterruptedException e1) {
     e1.printStackTrace();
    }

    Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
    Transceiver.this.TreadStart();
   }
  });
  this.sendText = new TextArea("", 5, 30);
  this.sendText.setText(this.mStr[19][this.lan]);
  this.sendText.setSize(580, 80);
  mainFrame.add(this.sendText);
  this.sendText.setLocation(10, y + 80 + this.tUITop);
  this.mChoiceRecevieDisplay = new Choice();
  this.mChoiceRecevieDisplay.setBounds(100, 100, 180, 30);
  this.mChoiceRecevieDisplay.add(this.mStr[33][this.lan]);
  this.mChoiceRecevieDisplay.add(this.mStr[34][this.lan]);
  this.mChoiceRecevieDisplay.add(this.mStr[35][this.lan]);
  mainFrame.add(this.mChoiceRecevieDisplay);
  this.mChoiceRecevieDisplay.setLocation(125, y + 160 + this.tUITop);
  this.mChoiceRecevieDisplay.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    String data = "Recevie: " + Transceiver.this.mChoiceRecevieDisplay.getItem(Transceiver.this.mChoiceRecevieDisplay.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
    Transceiver.this.recevieText.setText("");
    Transceiver.this.TreadStop();
    Transceiver.this.TreadStart();
   }
  });
  Button buttonClear = new Button(this.mStr[31][this.lan]);
  buttonClear.setBounds(100, 100, 120, 30);
  mainFrame.add(buttonClear);
  buttonClear.setLocation(310, y + 160 + this.tUITop);
  buttonClear.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    Transceiver.this.labelMessage.setText(Transceiver.this.mStr[31][Transceiver.this.lan]);
    Transceiver.this.recevieText.setText("");
   }
  });
  Label l3 = new Label();
  l3.setAlignment(0);
  l3.setText(this.mStr[32][this.lan]);
  l3.setSize(100, 30);
  mainFrame.add(l3);
  l3.setLocation(10, y + 160 + this.tUITop);
  this.recevieText = new TextArea("", 5, 30);
  this.recevieText.setText(this.mStr[55][this.lan]);
  this.recevieText.setSize(580, 80);
  mainFrame.add(this.recevieText);
  this.recevieText.setLocation(10, y + 190 + this.tUITop);
 }

 private void showMenu() {
  final MenuBar menuBar = new MenuBar();
  Menu fileMenu = new Menu("File");
  Menu editMenu = new Menu("Edit");
  final Menu aboutMenu = new Menu("app");
  MenuItem newMenuItem = new MenuItem("New", new MenuShortcut(78));
  newMenuItem.setActionCommand("New");
  MenuItem openMenuItem = new MenuItem("Open");
  openMenuItem.setActionCommand("Open");
  MenuItem saveMenuItem = new MenuItem("Save");
  saveMenuItem.setActionCommand("Save");
  MenuItem exitMenuItem = new MenuItem("Exit");
  exitMenuItem.setActionCommand("Exit");
  MenuItem cutMenuItem = new MenuItem("Cut");
  cutMenuItem.setActionCommand("Cut");
  MenuItem copyMenuItem = new MenuItem("Copy");
  copyMenuItem.setActionCommand("Copy");
  MenuItem pasteMenuItem = new MenuItem("Paste");
  pasteMenuItem.setActionCommand("Paste");
  MenuItem aboutMenuItem = new MenuItem("About");
  aboutMenuItem.setActionCommand("about app");
  MenuItemListener menuItemListener = new MenuItemListener();
  newMenuItem.addActionListener(menuItemListener);
  openMenuItem.addActionListener(menuItemListener);
  saveMenuItem.addActionListener(menuItemListener);
  exitMenuItem.addActionListener(menuItemListener);
  cutMenuItem.addActionListener(menuItemListener);
  copyMenuItem.addActionListener(menuItemListener);
  pasteMenuItem.addActionListener(menuItemListener);
  aboutMenu.addActionListener(menuItemListener);
  final CheckboxMenuItem showWindowMenu = new CheckboxMenuItem("Show About", true);
  showWindowMenu.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    if (showWindowMenu.getState()) {
     menuBar.add(aboutMenu);
    } else {
     menuBar.remove(aboutMenu);
    }

   }
  });
  fileMenu.add(newMenuItem);
  fileMenu.add(openMenuItem);
  fileMenu.add(saveMenuItem);
  fileMenu.addSeparator();
  fileMenu.add(showWindowMenu);
  fileMenu.addSeparator();
  fileMenu.add(exitMenuItem);
  editMenu.add(cutMenuItem);
  editMenu.add(copyMenuItem);
  editMenu.add(pasteMenuItem);
  aboutMenu.add(aboutMenuItem);
  menuBar.add(aboutMenu);
  this.mainFrame.setMenuBar(menuBar);
  this.mainFrame.setVisible(true);
 }

 private String encodeValue(String value) {
  try {
   return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
  } catch (UnsupportedEncodingException e) {
   e.printStackTrace();
   return "";
  }
 }

 public void TreadStop() {
  this.savePreference("mCounter", Long.toString(this.mCounter));
  if (this.mThreadRecevieText != null) {
   this.mThreadRecevieText.interrupt(); // Replaced .stop()
   this.mThreadRecevieText = null;
  }
 }

 public void TreadStart() {
  if (this.mThreadRecevieText != null) {
   this.mThreadRecevieText.interrupt(); // Replaced .stop()
   this.mThreadRecevieText = null;
  }

  this.mThreadRecevieText = new ThreadRecevieText(this.labelMessage, this.recevieText, this.mloralib, this.mChoiceRecevieDisplay, this.transceiverFrameClass);
  this.mThreadRecevieText.start();
 }

 class MenuItemListener implements ActionListener {
  MenuItemListener() {
  }

  public void actionPerformed(ActionEvent e) {
   Transceiver.this.labelMessage.setText(e.getActionCommand() + " MenuItem clicked.");
   if (Desktop.isDesktopSupported()) {
    try {
     Desktop.getDesktop().browse(new URI("http://www.app.com/"));
    } catch (IOException | URISyntaxException e1) {
     e1.printStackTrace();
    }
   }
  }
 }

 class ThreadRecevieText extends Thread {
  private Random generator;
  private TextArea mRrecevieText;
  private LoraUtil threadloralib;
  private byte[] oldData;
  private Choice mChoiceRecevieDisplay;
  private int delaytime = 1000;
  private Label mlabelMessage;
  private Transceiver mLo;

  public ThreadRecevieText(Label ilabelMessage, TextArea iComRrecevieText, LoraUtil iloralib, Choice iChoiceRecevieDisplay, Transceiver imLo) {
   this.mlabelMessage = ilabelMessage;
   this.mRrecevieText = iComRrecevieText;
   this.generator = new Random();
   this.threadloralib = iloralib;
   Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
   this.mChoiceRecevieDisplay = iChoiceRecevieDisplay;
   this.mLo = imLo;
  }

  public void run() {
   int counter = 0;

   while(!interrupted()) {
    long tCounter = Transceiver.this.mloralib.FunLora_7_counter_long();
    if (tCounter != this.mLo.mCounter) {
     System.out.println("tCounter=" + Long.toString(tCounter));
     this.mLo.mCounter = tCounter;
     byte[] data = Transceiver.this.mloralib.FunLora_6_readPureData();
     int len3 = data.length;
     byte var10000 = data[len3 - 1];
     data[len3 - 1] = 0;
     Transceiver.this.mloralib.Fun_CRC(data);
     if (data != null && data.length > 4 && data[0] == -63 && data[1] == -122) {
      int len = data[2] - 2;
      int len2 = data.length;
      if (data.length == len + 6 && len > 0) {
       byte[] data2 = new byte[len];

       for(int i2 = 0; i2 < len; ++i2) {
        byte t1 = data[3 + i2];
        data2[i2] = t1;
       }

       String tRecHex = "";

       try {
        if (this.mChoiceRecevieDisplay.getSelectedIndex() == 0) {
         tRecHex = new String(data2, "UTF-8");
        } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 1) {
         tRecHex = LoraUtil.FunBytesToHexString(data2, ',');
        } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 2) {
         tRecHex = LoraUtil.FunBytesToString(data2, ',');
        }
       } catch (UnsupportedEncodingException var20) {
       }

       System.out.println("收到資料COM Port<-" + tRecHex);
       Transceiver.this.recevieText.setText(tRecHex + "\n" + Transceiver.this.recevieText.getText());
       if (this.mLo.checkBoxUpload == "true" && Transceiver.this.TextFieldUrl.length() > 5) {
        String data3 = Transceiver.this.FunHTTP(Transceiver.this.TextFieldUrl + tRecHex);
        this.mlabelMessage.setText(data3);
       }

       String t1aa = this.mLo.checkBoxDashboard;
       if (this.mLo.checkBoxDashboard.equals("true")) {
        String thttpURLResult = "";
        (new StringBuilder(String.valueOf(this.mLo.mURL[8]))).append("&Key=data&Value=").append(Transceiver.this.encodeValue(tRecHex)).append("&apikey=").append(Transceiver.this.APIKEY).toString();
        if (this.mChoiceRecevieDisplay.getSelectedIndex() == 0) {
         String fw = this.mLo.mURL[8] + "&Key=String&Value=" + Transceiver.this.encodeValue(tRecHex) + "&apikey=" + Transceiver.this.APIKEY;
         thttpURLResult = Transceiver.this.FunHTTP(fw);
        } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 1 || this.mChoiceRecevieDisplay.getSelectedIndex() == 2) {
         for(int i = 0; i < len; ++i) {
          int t1 = data2[i] & 255;
          String t2 = Integer.toString(t1);
          String thttpURL = this.mLo.mURL[8] + "&Key=byte" + Integer.toString(i) + "&Value=" + t2 + "&apikey=" + Transceiver.this.APIKEY;
          thttpURLResult = Transceiver.this.FunHTTP(thttpURL);
         }
        }

        this.mlabelMessage.setText(thttpURLResult);
       }

       if (this.mLo.checkBoxSaveLog.equals("true")) {
        try {
         if (this.mLo.StringLogFileName.length() > 0) {
          String filename = this.mLo.StringLogFileName;
          FileWriter fw = new FileWriter(filename, true);
          fw.write(tRecHex + "\n");
          fw.close();
         }
        } catch (IOException ioe) {
         System.err.println("IOException: " + ioe.getMessage());
        }
       }
       this.oldData = data2.clone();
      }
     }
    }

    try {
     sleep((long)this.delaytime);
    } catch (InterruptedException e) {
     e.printStackTrace();
    }

    if (this.delaytime < 500) {
     this.delaytime += 2;
    }
   }

  }
 }

 public interface Callback {
  void OnSuccess(String var1);

  void OnError(int var1, String var2);
 }
}

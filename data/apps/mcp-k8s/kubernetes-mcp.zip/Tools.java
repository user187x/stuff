package mcp;

import com.google.gson.*;
import java.io.File;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Tool definitions and execution for the Kubernetes MCP server.
 *
 * Safety controls (environment variables):
 *   MCP_READ_ONLY=true      -> mutating tools are refused
 *   MCP_ALLOW_SHELL=true    -> enables the run_shell tool (host shell access)
 *   MCP_KUBECONFIG=/path    -> passed to kubectl/helm via --kubeconfig
 *   MCP_CONTEXT=name        -> default kube context (can be overridden per call with "context")
 *   MCP_MAX_OUTPUT=60000    -> output cap in characters
 */
public final class Tools {

    private static final boolean READ_ONLY = "true".equalsIgnoreCase(System.getenv("MCP_READ_ONLY"));
    private static final boolean ALLOW_SHELL = "true".equalsIgnoreCase(System.getenv("MCP_ALLOW_SHELL"));
    private static final String KUBECONFIG = System.getenv("MCP_KUBECONFIG");
    private static final String DEFAULT_CONTEXT = System.getenv("MCP_CONTEXT");

    private static final int DEFAULT_TIMEOUT = 60;
    private static final int LONG_TIMEOUT = 300;

    // ---------- Tool schema helpers ----------

    private record Param(String name, String type, String desc, boolean required, String[] enumVals) {}

    private static Param s(String name, String desc)  { return new Param(name, "string", desc, false, null); }
    private static Param sr(String name, String desc) { return new Param(name, "string", desc, true, null); }
    private static Param b(String name, String desc)  { return new Param(name, "boolean", desc, false, null); }
    private static Param i(String name, String desc)  { return new Param(name, "integer", desc, false, null); }
    private static Param arr(String name, String desc){ return new Param(name, "array", desc, false, null); }
    private static Param en(String name, String desc, boolean req, String... vals) { return new Param(name, "string", desc, req, vals); }

    private static final Param CTX = s("context", "kubeconfig context to use (optional; overrides server default)");

    private static final List<JsonObject> TOOLS = new ArrayList<>();
    private static final Set<String> MUTATING = new HashSet<>();

    private static void tool(String name, String desc, boolean mutating, boolean destructive, Param... params) {
        JsonObject t = new JsonObject();
        t.addProperty("name", name);
        t.addProperty("description", desc);
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonArray required = new JsonArray();
        for (Param p : params) {
            JsonObject pj = new JsonObject();
            pj.addProperty("type", p.type());
            pj.addProperty("description", p.desc());
            if ("array".equals(p.type())) {
                JsonObject items = new JsonObject();
                items.addProperty("type", "string");
                pj.add("items", items);
            }
            if (p.enumVals() != null) {
                JsonArray e = new JsonArray();
                for (String v : p.enumVals()) e.add(v);
                pj.add("enum", e);
            }
            props.add(p.name(), pj);
            if (p.required()) required.add(p.name());
        }
        // Context is available on every kubectl/helm tool
        JsonObject ctx = new JsonObject();
        ctx.addProperty("type", "string");
        ctx.addProperty("description", CTX.desc());
        props.add("context", ctx);
        schema.add("properties", props);
        if (required.size() > 0) schema.add("required", required);
        t.add("inputSchema", schema);

        JsonObject ann = new JsonObject();
        ann.addProperty("readOnlyHint", !mutating);
        ann.addProperty("destructiveHint", destructive);
        ann.addProperty("idempotentHint", !mutating);
        t.add("annotations", ann);

        TOOLS.add(t);
        if (mutating) MUTATING.add(name);
    }

    static {
        // ======================= DISCOVERY & OVERVIEW =======================
        tool("cluster_overview",
             "One-shot snapshot of the cluster: kubectl/server versions, current context, cluster-info, nodes, namespaces, "
             + "detected local cluster tool (minikube/k3d/kind), and helm releases. Call this first when starting a session.",
             false, false);

        tool("cluster_health_check",
             "Automated triage: NotReady nodes, non-Running pods, pods with high restart counts, CrashLoopBackOff/ImagePull errors, "
             + "deployments/statefulsets not fully available, pending PVCs, Warning events, and resource usage (if metrics-server exists). "
             + "Returns a prioritized problem list. Use to find what to investigate.",
             false, false,
             s("namespace", "Restrict to one namespace (default: all)"),
             i("restart_threshold", "Flag pods with restarts >= this (default 3)"));

        tool("kubectl_api_resources",
             "List supported API resources including CRDs. Use to discover resource kinds (e.g. for ArgoCD, Istio, Gateway API).",
             false, false,
             b("namespaced_only", "Only namespaced resources"),
             s("api_group", "Filter by API group (e.g. apps, networking.k8s.io, argoproj.io)"),
             b("verbs_wide", "Show verbs column (-o wide)"));

        tool("kubectl_explain",
             "Show documentation/schema for a resource or field (e.g. 'pod.spec.containers.livenessProbe').",
             false, false,
             sr("resource", "Resource or dotted field path"),
             b("recursive", "Print all fields recursively"));

        tool("kubectl_config",
             "Manage kubeconfig contexts: current-context, get-contexts, use-context, view (redacted).",
             false, false,
             en("action", "Action", true, "current-context", "get-contexts", "use-context", "view", "get-clusters"),
             s("name", "Context name (for use-context)"));

        // ======================= READ / INSPECT =======================
        tool("kubectl_get",
             "Get any resource (native or CRD). Supports label/field selectors and output formats. "
             + "Use output='yaml' for full spec, 'wide' for node/IP info, 'json' for programmatic parsing, "
             + "or jsonpath/custom-columns via output='jsonpath={...}'.",
             false, false,
             sr("resource", "Resource type, e.g. pods, deploy, svc, ingress, httproutes, applications, all, 'pods,svc'"),
             s("name", "Specific resource name"),
             s("namespace", "Namespace (default: all namespaces unless resource is cluster-scoped)"),
             s("selector", "Label selector, e.g. app=web,tier!=cache"),
             s("field_selector", "Field selector, e.g. status.phase=Pending,spec.nodeName=node1"),
             s("output", "yaml | json | wide | name | jsonpath=... | custom-columns=..."),
             b("show_labels", "Append labels column"),
             s("sort_by", "JSONPath to sort by, e.g. .metadata.creationTimestamp"));

        tool("kubectl_describe",
             "Describe a resource: full state, conditions, and recent events. Best first step for a failing pod/node/PVC.",
             false, false,
             sr("resource", "Resource type"),
             s("name", "Resource name (omit to describe all matching selector)"),
             s("namespace", "Namespace"),
             s("selector", "Label selector"));

        tool("kubectl_get_events",
             "Cluster events sorted by time. Filter to Warnings or to a specific object to find scheduling, image, probe, or mount failures.",
             false, false,
             s("namespace", "Namespace (default: all)"),
             b("warnings_only", "Only type=Warning events"),
             s("involved_object", "Only events for this object name (e.g. a pod name)"),
             s("kind", "Only events for this object kind (Pod, Node, Deployment...)"));

        tool("kubectl_logs",
             "Fetch container logs. Supports previous crashed container, all containers, label selector, time windows, and regex grep.",
             false, false,
             s("pod_name", "Pod name (or omit and use selector)"),
             sr("namespace", "Namespace"),
             s("container", "Container name for multi-container pods"),
             b("all_containers", "Logs from all containers in the pod"),
             b("previous", "Logs from the previous (crashed) container instance"),
             s("selector", "Label selector to get logs from multiple pods (e.g. app=api)"),
             i("tail", "Number of lines from the end (default 300)"),
             s("since", "Relative window, e.g. 10m, 2h"),
             s("grep", "Java regex; only return matching lines (case-insensitive)"),
             b("timestamps", "Include timestamps"));

        tool("kubectl_top",
             "CPU/memory usage for nodes or pods (needs metrics-server; on minikube: 'minikube addons enable metrics-server').",
             false, false,
             en("target", "nodes or pods", true, "nodes", "pods"),
             s("namespace", "Namespace for pods (default: all)"),
             b("containers", "Per-container breakdown (pods only)"),
             s("selector", "Label selector"),
             en("sort_by", "cpu or memory", false, "cpu", "memory"));

        tool("kubectl_rollout",
             "Deployment/StatefulSet/DaemonSet rollout control: status, history, restart, undo (rollback), pause, resume.",
             true, false,
             en("action", "Action", true, "status", "history", "restart", "undo", "pause", "resume"),
             sr("resource", "deployment | statefulset | daemonset"),
             sr("name", "Resource name"),
             sr("namespace", "Namespace"),
             i("to_revision", "Revision number for undo (optional)"));

        tool("kubectl_auth_can_i",
             "Check RBAC permissions: can the current (or impersonated) identity perform a verb on a resource? Use list=true to dump all permissions.",
             false, false,
             s("verb", "get | list | create | delete | patch | * ..."),
             s("resource", "Resource, optionally with subresource e.g. pods/log"),
             s("namespace", "Namespace"),
             s("as_user", "Impersonate this user"),
             s("as_service_account", "Impersonate ServiceAccount as namespace:name"),
             b("list", "List all allowed actions instead of checking one"));

        tool("kubectl_diff",
             "Show what kubectl apply WOULD change for a manifest, without applying. Use before risky applies.",
             false, false,
             sr("yaml_manifest", "Manifest YAML (multi-document ok)"),
             s("namespace", "Default namespace for namespaced objects lacking one"));

        tool("kubectl_wait",
             "Block until a condition is met (e.g. condition=Ready on pods, condition=Available on deployments, delete).",
             false, false,
             sr("resource", "Resource type"),
             s("name", "Resource name"),
             s("selector", "Label selector (alternative to name)"),
             sr("condition", "e.g. condition=Ready, condition=Available, jsonpath='{.status.phase}'=Running, delete"),
             s("namespace", "Namespace"),
             i("timeout_seconds", "Max wait (default 120)"));

        // ======================= IN-CLUSTER TROUBLESHOOTING =======================
        tool("kubectl_exec",
             "Run a shell command inside a running container (sh -c). Use for DNS checks (nslookup), connectivity (curl/wget/nc), "
             + "env inspection, file/config checks, process lists.",
             true, false,
             sr("pod_name", "Pod name"),
             sr("namespace", "Namespace"),
             s("container", "Container name"),
             sr("command", "Shell command, e.g. 'nslookup kubernetes.default' or 'cat /etc/config/app.yaml'"),
             i("timeout_seconds", "Timeout (default 60)"));

        tool("kubectl_debug",
             "Attach an ephemeral debug container to a pod (for distroless/no-shell images) or debug a NODE via a privileged pod with host filesystem at /host. "
             + "Runs a command non-interactively and returns output.",
             true, false,
             sr("target", "Pod name, or 'node/<node-name>'"),
             s("namespace", "Namespace (pods only)"),
             s("image", "Debug image (default busybox:1.36; use nicolaka/netshoot for network tooling)"),
             s("target_container", "Share process namespace with this container (pod debugging)"),
             sr("command", "Shell command to run in the debug container"),
             i("timeout_seconds", "Timeout (default 120)"));

        tool("kubectl_run_pod",
             "Launch a temporary throwaway pod (auto-deleted) that runs a command and returns output. Ideal for testing service DNS, "
             + "network policies, or database connectivity from inside the cluster.",
             true, false,
             sr("namespace", "Namespace to run in"),
             s("image", "Image (default busybox:1.36; nicolaka/netshoot has curl/dig/nc; curlimages/curl for curl)"),
             sr("command", "Shell command, e.g. 'wget -qO- http://api.default.svc:8080/health'"),
             s("service_account", "ServiceAccount to run as (test RBAC/workload identity)"),
             s("labels", "Labels to apply, e.g. app=probe (test NetworkPolicies)"),
             i("timeout_seconds", "Timeout (default 120)"));

        tool("service_probe",
             "Test a Service or Pod HTTP endpoint from the host by opening a temporary port-forward and issuing a curl request. "
             + "Returns status line, headers, and body.",
             false, false,
             sr("target", "svc/<name> or pod/<name> or deploy/<name>"),
             sr("namespace", "Namespace"),
             i("port", "Target port on the service/pod (required)"),
             s("path", "HTTP path (default /)"),
             en("method", "HTTP method", false, "GET", "POST", "PUT", "DELETE", "HEAD"),
             s("body", "Request body (for POST/PUT)"),
             s("headers", "Extra headers, one per line: 'Content-Type: application/json'"),
             b("https", "Use https (insecure, skips cert verification)"));

        tool("kubectl_cp",
             "Copy files between the host and a container. Use to pull config/log files out for analysis or push a fix in.",
             true, false,
             sr("source", "Host path or <namespace>/<pod>:<path>"),
             sr("destination", "Host path or <namespace>/<pod>:<path>"),
             s("container", "Container name"));

        // ======================= MUTATION / FIX =======================
        tool("kubectl_apply",
             "Create or update resources from a YAML/JSON manifest (multi-document supported). Use dry_run='server' first to validate. "
             + "Supports server-side apply for conflict-free field management.",
             true, false,
             sr("yaml_manifest", "Full manifest"),
             s("namespace", "Default namespace for objects lacking one"),
             en("dry_run", "none | client | server", false, "none", "client", "server"),
             b("server_side", "Use --server-side (with --force-conflicts)"),
             b("prune", "Prune resources with matching selector not in manifest (requires selector)"),
             s("selector", "Label selector used with prune"));

        tool("kubectl_patch",
             "Patch a resource in place. type=strategic (default, k8s-aware merge), merge (JSON merge patch), or json (RFC 6902 ops array). "
             + "Great for surgical fixes: bumping resources, toggling flags, fixing probes, removing finalizers.",
             true, false,
             sr("resource", "Resource type"),
             sr("name", "Resource name"),
             s("namespace", "Namespace"),
             sr("patch", "Patch document as JSON or YAML string"),
             en("type", "Patch type", false, "strategic", "merge", "json"),
             s("subresource", "e.g. status or scale"));

        tool("kubectl_scale",
             "Scale deployment/statefulset/replicaset/replicationcontroller.",
             true, false,
             sr("resource", "Resource type"),
             sr("name", "Resource name"),
             sr("namespace", "Namespace"),
             i("replicas", "Desired replica count"),
             i("current_replicas", "Precondition: only scale if current count matches"));

        tool("kubectl_set",
             "Quick updates on workloads: image (roll new image), env (set/unset env vars), resources (requests/limits), "
             + "serviceaccount, selector.",
             true, false,
             en("action", "What to set", true, "image", "env", "resources", "serviceaccount"),
             sr("resource", "Resource type (deployment, statefulset, daemonset, cronjob)"),
             sr("name", "Resource name"),
             sr("namespace", "Namespace"),
             s("container", "Container name (default: all / '*')"),
             arr("values", "image: ['nginx:1.27'] | env: ['KEY=value','UNSET_ME-'] | resources: ['--limits=cpu=500m,memory=512Mi','--requests=cpu=100m'] | serviceaccount: ['sa-name']"));

        tool("kubectl_label_annotate",
             "Add/overwrite/remove labels or annotations. Value 'key-' removes. Useful for toggling selectors, "
             + "marking nodes, or adding restart annotations.",
             true, false,
             en("action", "label or annotate", true, "label", "annotate"),
             sr("resource", "Resource type"),
             sr("name", "Resource name"),
             s("namespace", "Namespace"),
             arr("values", "e.g. ['tier=frontend','deprecated-']"),
             b("overwrite", "Overwrite existing (default true)"),
             s("selector", "Apply to all matching selector instead of name"));

        tool("kubectl_create",
             "Imperatively create common resources without writing YAML: namespace, configmap/secret from literals, "
             + "serviceaccount, job from a cronjob (manual trigger), or token for a serviceaccount.",
             true, false,
             en("kind", "Kind", true, "namespace", "configmap", "secret", "serviceaccount", "job", "token"),
             sr("name", "Name (for kind=job: new job name)"),
             s("namespace", "Namespace"),
             arr("literals", "key=value pairs for configmap/secret"),
             s("from_cronjob", "CronJob name (kind=job)"),
             s("secret_type", "generic (default) | docker-registry | tls"));

        tool("kubectl_delete",
             "Delete resources by name or selector. Deleting a namespace or using resource='all' requires confirm=true. "
             + "force=true does immediate deletion (use for pods stuck Terminating).",
             true, true,
             sr("resource", "Resource type"),
             s("name", "Resource name"),
             s("namespace", "Namespace"),
             s("selector", "Label selector (alternative to name)"),
             b("force", "Force delete with --grace-period=0"),
             b("wait", "Wait for deletion to finish (default true)"),
             b("ignore_not_found", "Don't error if absent"),
             b("confirm", "Required for namespace deletion or resource='all'"));

        tool("kubectl_node_ops",
             "Node maintenance: cordon, uncordon, drain (evict pods), taint (add/remove).",
             true, true,
             en("action", "Action", true, "cordon", "uncordon", "drain", "taint"),
             sr("node", "Node name"),
             s("taint", "For taint: 'key=value:NoSchedule' to add, 'key:NoSchedule-' to remove"),
             b("ignore_daemonsets", "drain: ignore DaemonSet pods (default true)"),
             b("delete_emptydir_data", "drain: allow deleting pods with emptyDir (default true)"),
             b("force", "drain: delete unmanaged pods"),
             i("timeout_seconds", "drain timeout (default 300)"));

        tool("kubectl_raw",
             "Escape hatch: run kubectl with arbitrary arguments (args array, no shell). Covers anything not exposed as a dedicated tool "
             + "(e.g. certificate approve, expose, autoscale, cp variants, plugin commands). Stdin can be provided.",
             true, true,
             arr("args", "Arguments after 'kubectl', e.g. ['expose','deploy','web','--port=80','-n','prod']"),
             s("stdin", "Optional data piped to stdin (e.g. for apply -f -)"),
             i("timeout_seconds", "Timeout (default 60)"));

        // ======================= HELM =======================
        tool("helm",
             "Run helm (args array). Read: list -A, status, get values/manifest, history, show values <chart>, search repo, template. "
             + "Write: install, upgrade --install, rollback, uninstall, repo add/update. Use --set/--values as args; values YAML can go via stdin with '-f -'.",
             true, true,
             arr("args", "Arguments after 'helm'"),
             s("stdin", "Optional YAML piped to stdin (use '-f -' in args)"),
             i("timeout_seconds", "Timeout (default 300)"));

        // ======================= LOCAL CLUSTER TOOLS =======================
        tool("local_cluster",
             "Control the local cluster tool: minikube (status, start, stop, addons list/enable/disable, service list, ip, ssh -- cmd, image load, "
             + "dashboard --url, profile list), k3d (cluster list/create/delete/start/stop, node list, image import), "
             + "or kind (get clusters, load docker-image). Pass args array.",
             true, true,
             en("tool", "Which tool", true, "minikube", "k3d", "kind"),
             arr("args", "Arguments after the tool name, e.g. ['addons','enable','ingress']"),
             i("timeout_seconds", "Timeout (default 300)"));

        tool("run_shell",
             "Run a shell command on the MCP host (docker, curl, dig, kustomize, jq, etc). DISABLED unless server started with MCP_ALLOW_SHELL=true.",
             true, true,
             sr("command", "Shell command"),
             i("timeout_seconds", "Timeout (default 60)"));
    }

    private Tools() {}

    public static JsonObject listTools() {
        JsonObject result = new JsonObject();
        JsonArray arr = new JsonArray();
        for (JsonObject t : TOOLS) arr.add(t);
        result.add("tools", arr);
        return result;
    }

    // ---------- Argument helpers ----------

    private static String str(JsonObject a, String k) {
        return a != null && a.has(k) && !a.get(k).isJsonNull() ? a.get(k).getAsString().trim() : "";
    }
    private static boolean bool(JsonObject a, String k, boolean def) {
        return a != null && a.has(k) && !a.get(k).isJsonNull() ? a.get(k).getAsBoolean() : def;
    }
    private static int num(JsonObject a, String k, int def) {
        if (a == null || !a.has(k) || a.get(k).isJsonNull()) return def;
        try { return a.get(k).getAsInt(); } catch (Exception e) { return Integer.parseInt(a.get(k).getAsString()); }
    }
    private static List<String> list(JsonObject a, String k) {
        List<String> out = new ArrayList<>();
        if (a == null || !a.has(k) || a.get(k).isJsonNull()) return out;
        JsonElement e = a.get(k);
        if (e.isJsonArray()) e.getAsJsonArray().forEach(x -> out.add(x.getAsString()));
        else for (String s : e.getAsString().split("\\s+")) if (!s.isBlank()) out.add(s);
        return out;
    }
    private static boolean has(JsonObject a, String k) { return !str(a, k).isEmpty(); }

    /** Base kubectl invocation with kubeconfig/context wiring. */
    private static List<String> kubectl(JsonObject a, String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("kubectl");
        if (KUBECONFIG != null && !KUBECONFIG.isBlank()) { cmd.add("--kubeconfig"); cmd.add(KUBECONFIG); }
        String ctx = has(a, "context") ? str(a, "context") : DEFAULT_CONTEXT;
        if (ctx != null && !ctx.isBlank()) { cmd.add("--context"); cmd.add(ctx); }
        cmd.addAll(Arrays.asList(args));
        return cmd;
    }

    private static List<String> helm(JsonObject a, List<String> args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("helm");
        if (KUBECONFIG != null && !KUBECONFIG.isBlank()) { cmd.add("--kubeconfig"); cmd.add(KUBECONFIG); }
        String ctx = has(a, "context") ? str(a, "context") : DEFAULT_CONTEXT;
        if (ctx != null && !ctx.isBlank()) { cmd.add("--kube-context"); cmd.add(ctx); }
        cmd.addAll(args);
        return cmd;
    }

    private static void ns(List<String> cmd, JsonObject a, boolean allIfEmpty) {
        if (has(a, "namespace")) { cmd.add("-n"); cmd.add(str(a, "namespace")); }
        else if (allIfEmpty) cmd.add("-A");
    }

    private static void selectors(List<String> cmd, JsonObject a) {
        if (has(a, "selector")) { cmd.add("-l"); cmd.add(str(a, "selector")); }
        if (has(a, "field_selector")) { cmd.add("--field-selector"); cmd.add(str(a, "field_selector")); }
    }

    // ---------- Result helpers ----------

    private static JsonObject text(String s, boolean isError) {
        JsonObject result = new JsonObject();
        JsonArray content = new JsonArray();
        JsonObject tc = new JsonObject();
        tc.addProperty("type", "text");
        tc.addProperty("text", s);
        content.add(tc);
        result.add("content", content);
        result.addProperty("isError", isError);
        return result;
    }

    private static JsonObject fromResult(CommandRunner.Result r) {
        String out = r.output();
        if (r.failed() && !r.timedOut()) out = out + "\n[exit code " + r.exitCode() + "]";
        return text(out, r.failed());
    }

    private static JsonObject runK(JsonObject a, int timeout, String... args) {
        return fromResult(CommandRunner.run(kubectl(a, args), timeout));
    }

    private static String section(String title, CommandRunner.Result r) {
        return "### " + title + "\n" + r.output().strip() + "\n\n";
    }

    // ---------- Execution ----------

    public static JsonObject execute(String name, JsonObject a) throws Exception {
        if (a == null) a = new JsonObject();
        if (READ_ONLY && MUTATING.contains(name)) {
            return text("Refused: server is running in read-only mode (MCP_READ_ONLY=true). Tool '" + name + "' can mutate the cluster.", true);
        }
        switch (name) {
            case "cluster_overview": return clusterOverview(a);
            case "cluster_health_check": return healthCheck(a);
            case "kubectl_api_resources": return apiResources(a);
            case "kubectl_explain": {
                List<String> c = kubectl(a, "explain", str(a, "resource"));
                if (bool(a, "recursive", false)) c.add("--recursive");
                return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
            }
            case "kubectl_config": return config(a);
            case "kubectl_get": return get(a);
            case "kubectl_describe": return describe(a);
            case "kubectl_get_events": return events(a);
            case "kubectl_logs": return logs(a);
            case "kubectl_top": return top(a);
            case "kubectl_rollout": return rollout(a);
            case "kubectl_auth_can_i": return authCanI(a);
            case "kubectl_diff": return withTempManifest(a, "diff");
            case "kubectl_wait": return waitFor(a);
            case "kubectl_exec": return exec(a);
            case "kubectl_debug": return debug(a);
            case "kubectl_run_pod": return runPod(a);
            case "service_probe": return serviceProbe(a);
            case "kubectl_cp": {
                List<String> c = kubectl(a, "cp", str(a, "source"), str(a, "destination"));
                if (has(a, "container")) { c.add("-c"); c.add(str(a, "container")); }
                return fromResult(CommandRunner.run(c, LONG_TIMEOUT));
            }
            case "kubectl_apply": return apply(a);
            case "kubectl_patch": return patch(a);
            case "kubectl_scale": return scale(a);
            case "kubectl_set": return set(a);
            case "kubectl_label_annotate": return labelAnnotate(a);
            case "kubectl_create": return create(a);
            case "kubectl_delete": return delete(a);
            case "kubectl_node_ops": return nodeOps(a);
            case "kubectl_raw": return raw(a);
            case "helm": return helmTool(a);
            case "local_cluster": return localCluster(a);
            case "run_shell": return shell(a);
            default: throw new IllegalArgumentException("Unknown tool: " + name);
        }
    }

    // ---------- Individual tools ----------

    private static JsonObject clusterOverview(JsonObject a) {
        StringBuilder sb = new StringBuilder();
        sb.append(section("Versions", CommandRunner.run(kubectl(a, "version"), 20)));
        sb.append(section("Current context", CommandRunner.run(kubectl(a, "config", "current-context"), 10)));
        sb.append(section("Cluster info", CommandRunner.run(kubectl(a, "cluster-info"), 20)));
        sb.append(section("Nodes", CommandRunner.run(kubectl(a, "get", "nodes", "-o", "wide"), 30)));
        sb.append(section("Namespaces", CommandRunner.run(kubectl(a, "get", "ns"), 20)));
        sb.append(section("Workloads (all namespaces)", CommandRunner.run(kubectl(a, "get", "deploy,sts,ds,cronjob", "-A"), 30)));
        sb.append(section("Metrics-server", CommandRunner.run(kubectl(a, "get", "apiservice", "v1beta1.metrics.k8s.io"), 15)));
        if (CommandRunner.available("minikube")) sb.append(section("minikube status", CommandRunner.run(List.of("minikube", "status"), 30)));
        if (CommandRunner.available("k3d")) sb.append(section("k3d clusters", CommandRunner.run(List.of("k3d", "cluster", "list"), 30)));
        if (CommandRunner.available("kind")) sb.append(section("kind clusters", CommandRunner.run(List.of("kind", "get", "clusters"), 30)));
        if (CommandRunner.available("helm")) sb.append(section("Helm releases", CommandRunner.run(helm(a, List.of("list", "-A")), 30)));
        sb.append("### Server mode\n").append(READ_ONLY ? "READ-ONLY (mutations refused)" : "READ-WRITE")
          .append(", shell ").append(ALLOW_SHELL ? "enabled" : "disabled").append("\n");
        return text(CommandRunner.truncate(sb.toString()), false);
    }

    private static JsonObject healthCheck(JsonObject a) {
        int threshold = num(a, "restart_threshold", 3);
        StringBuilder problems = new StringBuilder();
        StringBuilder detail = new StringBuilder();

        // Nodes
        CommandRunner.Result nodes = CommandRunner.run(kubectl(a, "get", "nodes",
                "-o", "custom-columns=NAME:.metadata.name,READY:.status.conditions[?(@.type==\"Ready\")].status,TAINTS:.spec.taints[*].key,UNSCHED:.spec.unschedulable"), 30);
        for (String line : nodes.output().split("\n")) {
            if (line.startsWith("NAME")) continue;
            if (line.matches(".*\\s(False|Unknown)\\s.*")) problems.append("[CRITICAL] Node NotReady: ").append(line.trim()).append('\n');
            if (line.trim().endsWith("true")) problems.append("[WARN] Node cordoned/unschedulable: ").append(line.split("\\s+")[0]).append('\n');
        }
        detail.append(section("Nodes", nodes));

        // Unhealthy pods
        List<String> podCmd = kubectl(a, "get", "pods", "--field-selector=status.phase!=Running,status.phase!=Succeeded");
        ns(podCmd, a, true);
        CommandRunner.Result badPods = CommandRunner.run(podCmd, 30);
        for (String line : badPods.output().split("\n")) {
            if (line.startsWith("NAME") || line.startsWith("NAMESPACE") || line.contains("No resources found") || line.isBlank()) continue;
            problems.append("[CRITICAL] Pod not running: ").append(line.trim()).append('\n');
        }

        // Restarts / waiting reasons (pods that ARE Running but flapping or with bad containers)
        List<String> allPods = kubectl(a, "get", "pods", "-o",
                "custom-columns=NS:.metadata.namespace,NAME:.metadata.name,RESTARTS:.status.containerStatuses[*].restartCount,WAITING:.status.containerStatuses[*].state.waiting.reason,READY:.status.containerStatuses[*].ready");
        ns(allPods, a, true);
        CommandRunner.Result podsRes = CommandRunner.run(allPods, 30);
        for (String line : podsRes.output().split("\n")) {
            if (line.startsWith("NS") || line.isBlank()) continue;
            String[] cols = line.trim().split("\\s+");
            if (cols.length < 3) continue;
            int maxRestart = 0;
            for (String r : cols[2].split(",")) { try { maxRestart = Math.max(maxRestart, Integer.parseInt(r)); } catch (Exception ignored) {} }
            if (maxRestart >= threshold) problems.append("[WARN] High restarts (").append(maxRestart).append("): ").append(cols[0]).append('/').append(cols[1]).append('\n');
            if (cols.length > 3 && !"<none>".equals(cols[3]))
                problems.append("[CRITICAL] Container waiting (").append(cols[3]).append("): ").append(cols[0]).append('/').append(cols[1]).append('\n');
            if (cols.length > 4 && cols[4].contains("false") && !line.contains("Completed"))
                problems.append("[WARN] Container not ready: ").append(cols[0]).append('/').append(cols[1]).append('\n');
        }

        // Workloads not fully available
        for (String kind : new String[]{"deployments", "statefulsets", "daemonsets"}) {
            List<String> c = kubectl(a, "get", kind, "-o",
                    "custom-columns=NS:.metadata.namespace,NAME:.metadata.name,DESIRED:.spec.replicas,READY:.status.readyReplicas,DS_DESIRED:.status.desiredNumberScheduled,DS_READY:.status.numberReady");
            ns(c, a, true);
            CommandRunner.Result r = CommandRunner.run(c, 30);
            for (String line : r.output().split("\n")) {
                if (line.startsWith("NS") || line.isBlank()) continue;
                String[] cols = line.trim().split("\\s+");
                if (cols.length < 6) continue;
                String desired = kind.equals("daemonsets") ? cols[4] : cols[2];
                String ready = kind.equals("daemonsets") ? cols[5] : cols[3];
                if ("<none>".equals(ready)) ready = "0";
                if (!"<none>".equals(desired) && !desired.equals(ready) && !"0".equals(desired))
                    problems.append("[WARN] ").append(kind).append(" not fully ready (").append(ready).append('/').append(desired).append("): ")
                            .append(cols[0]).append('/').append(cols[1]).append('\n');
            }
        }

        // PVCs
        List<String> pvc = kubectl(a, "get", "pvc", "--field-selector=status.phase!=Bound");
        ns(pvc, a, true);
        CommandRunner.Result pvcRes = CommandRunner.run(pvc, 30);
        for (String line : pvcRes.output().split("\n")) {
            if (line.startsWith("NAME") || line.startsWith("NAMESPACE") || line.contains("No resources found") || line.isBlank()) continue;
            problems.append("[WARN] PVC not bound: ").append(line.trim()).append('\n');
        }

        // Warning events
        List<String> ev = kubectl(a, "get", "events", "--field-selector=type=Warning", "--sort-by=.lastTimestamp");
        ns(ev, a, true);
        CommandRunner.Result evRes = CommandRunner.run(ev, 30);
        String[] evLines = evRes.output().split("\n");
        int start = Math.max(1, evLines.length - 40);
        StringBuilder evTail = new StringBuilder(evLines[0]).append('\n');
        for (int i = start; i < evLines.length; i++) evTail.append(evLines[i]).append('\n');
        detail.append("### Recent Warning events (last 40)\n").append(evTail).append('\n');

        // Metrics
        CommandRunner.Result top = CommandRunner.run(kubectl(a, "top", "nodes"), 20);
        if (!top.failed()) detail.append(section("Node usage", top));
        else detail.append("### Node usage\nmetrics-server unavailable (").append(top.output().lines().findFirst().orElse("")).append(")\n\n");

        String summary = problems.length() == 0
                ? "✅ No problems detected by automated checks.\n\n"
                : "## Problems found (" + problems.toString().lines().count() + ")\n" + problems + "\n"
                  + "Next steps: kubectl_describe the failing objects, kubectl_logs with previous=true for CrashLoopBackOff, "
                  + "kubectl_get_events with involved_object for scheduling/mount issues.\n\n";
        return text(CommandRunner.truncate(summary + "## Details\n" + detail), false);
    }

    private static JsonObject apiResources(JsonObject a) {
        List<String> c = kubectl(a, "api-resources");
        if (bool(a, "namespaced_only", false)) c.add("--namespaced=true");
        if (has(a, "api_group")) { c.add("--api-group"); c.add(str(a, "api_group")); }
        if (bool(a, "verbs_wide", false)) { c.add("-o"); c.add("wide"); }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject config(JsonObject a) {
        String action = str(a, "action");
        List<String> c = kubectl(a, "config");
        switch (action) {
            case "use-context":
                if (READ_ONLY) return text("Refused in read-only mode; pass 'context' per call instead.", true);
                c.add("use-context"); c.add(str(a, "name")); break;
            case "view": c.add("view"); c.add("--minify=false"); break; // secrets are redacted by default
            default: c.add(action);
        }
        return fromResult(CommandRunner.run(c, 20));
    }

    private static JsonObject get(JsonObject a) {
        List<String> c = kubectl(a, "get", str(a, "resource"));
        if (has(a, "name")) c.add(str(a, "name"));
        ns(c, a, !has(a, "name"));
        selectors(c, a);
        if (has(a, "output")) { c.add("-o"); c.add(str(a, "output")); }
        if (bool(a, "show_labels", false)) c.add("--show-labels");
        if (has(a, "sort_by")) { c.add("--sort-by"); c.add(str(a, "sort_by")); }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject describe(JsonObject a) {
        List<String> c = kubectl(a, "describe", str(a, "resource"));
        if (has(a, "name")) c.add(str(a, "name"));
        ns(c, a, false);
        if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject events(JsonObject a) {
        List<String> c = kubectl(a, "get", "events", "--sort-by=.lastTimestamp");
        ns(c, a, true);
        List<String> fs = new ArrayList<>();
        if (bool(a, "warnings_only", false)) fs.add("type=Warning");
        if (has(a, "involved_object")) fs.add("involvedObject.name=" + str(a, "involved_object"));
        if (has(a, "kind")) fs.add("involvedObject.kind=" + str(a, "kind"));
        if (!fs.isEmpty()) { c.add("--field-selector"); c.add(String.join(",", fs)); }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject logs(JsonObject a) {
        List<String> c = kubectl(a, "logs");
        if (has(a, "pod_name")) c.add(str(a, "pod_name"));
        else if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); c.add("--prefix"); }
        else return text("Provide pod_name or selector.", true);
        c.add("-n"); c.add(str(a, "namespace"));
        c.add("--tail=" + num(a, "tail", 300));
        if (has(a, "container")) { c.add("-c"); c.add(str(a, "container")); }
        if (bool(a, "all_containers", false)) { c.add("--all-containers=true"); c.add("--prefix"); }
        if (bool(a, "previous", false)) c.add("-p");
        if (has(a, "since")) c.add("--since=" + str(a, "since"));
        if (bool(a, "timestamps", false)) c.add("--timestamps");
        CommandRunner.Result r = CommandRunner.run(c, DEFAULT_TIMEOUT);
        if (!r.failed() && has(a, "grep")) {
            Pattern p = Pattern.compile(str(a, "grep"), Pattern.CASE_INSENSITIVE);
            StringBuilder sb = new StringBuilder();
            int matches = 0;
            for (String line : r.output().split("\n")) if (p.matcher(line).find()) { sb.append(line).append('\n'); matches++; }
            return text(matches == 0 ? "(no lines matched /" + str(a, "grep") + "/ in " + r.output().lines().count() + " lines)"
                                     : matches + " matching lines:\n" + sb, false);
        }
        return fromResult(r);
    }

    private static JsonObject top(JsonObject a) {
        List<String> c = kubectl(a, "top", str(a, "target"));
        if ("pods".equals(str(a, "target"))) {
            ns(c, a, true);
            if (bool(a, "containers", false)) c.add("--containers");
        }
        if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); }
        if (has(a, "sort_by")) c.add("--sort-by=" + str(a, "sort_by"));
        return fromResult(CommandRunner.run(c, 30));
    }

    private static JsonObject rollout(JsonObject a) {
        List<String> c = kubectl(a, "rollout", str(a, "action"), str(a, "resource") + "/" + str(a, "name"), "-n", str(a, "namespace"));
        if ("undo".equals(str(a, "action")) && num(a, "to_revision", 0) > 0) c.add("--to-revision=" + num(a, "to_revision", 0));
        if ("status".equals(str(a, "action"))) c.add("--timeout=120s");
        return fromResult(CommandRunner.run(c, 150));
    }

    private static JsonObject authCanI(JsonObject a) {
        List<String> c = kubectl(a, "auth", "can-i");
        if (bool(a, "list", false)) c.add("--list");
        else { c.add(str(a, "verb")); c.add(str(a, "resource")); }
        ns(c, a, false);
        if (has(a, "as_user")) { c.add("--as"); c.add(str(a, "as_user")); }
        if (has(a, "as_service_account")) { c.add("--as"); c.add("system:serviceaccount:" + str(a, "as_service_account")); }
        CommandRunner.Result r = CommandRunner.run(c, 20);
        // 'no' returns exit 1 but is a valid answer
        return text(r.output(), r.timedOut());
    }

    private static JsonObject withTempManifest(JsonObject a, String verb) throws Exception {
        File f = File.createTempFile("mcp_" + verb + "_", ".yaml");
        try {
            Files.writeString(f.toPath(), str(a, "yaml_manifest"));
            List<String> c = kubectl(a, verb, "-f", f.getAbsolutePath());
            ns(c, a, false);
            CommandRunner.Result r = CommandRunner.run(c, DEFAULT_TIMEOUT);
            if ("diff".equals(verb)) {
                // diff exits 1 when there are differences — not an error
                if (r.exitCode() == 0) return text("No differences. Manifest matches live state.", false);
                if (r.exitCode() == 1) return text(r.output(), false);
            }
            return fromResult(r);
        } finally { f.delete(); }
    }

    private static JsonObject waitFor(JsonObject a) {
        int t = num(a, "timeout_seconds", 120);
        List<String> c = kubectl(a, "wait", str(a, "resource"));
        if (has(a, "name")) c.add(str(a, "name"));
        if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); }
        c.add("--for=" + str(a, "condition"));
        c.add("--timeout=" + t + "s");
        ns(c, a, false);
        return fromResult(CommandRunner.run(c, t + 10));
    }

    private static JsonObject exec(JsonObject a) {
        List<String> c = kubectl(a, "exec", str(a, "pod_name"), "-n", str(a, "namespace"));
        if (has(a, "container")) { c.add("-c"); c.add(str(a, "container")); }
        c.add("--"); c.add("sh"); c.add("-c"); c.add(str(a, "command"));
        return fromResult(CommandRunner.run(c, num(a, "timeout_seconds", DEFAULT_TIMEOUT)));
    }

    private static JsonObject debug(JsonObject a) {
        String image = has(a, "image") ? str(a, "image") : "busybox:1.36";
        List<String> c = kubectl(a, "debug", str(a, "target"), "-q", "-i", "--image=" + image);
        if (!str(a, "target").startsWith("node/")) {
            ns(c, a, false);
            if (has(a, "target_container")) c.add("--target=" + str(a, "target_container"));
        }
        c.add("--"); c.add("sh"); c.add("-c"); c.add(str(a, "command"));
        return fromResult(CommandRunner.run(c, num(a, "timeout_seconds", 120)));
    }

    private static JsonObject runPod(JsonObject a) {
        String image = has(a, "image") ? str(a, "image") : "busybox:1.36";
        String podName = "mcp-probe-" + UUID.randomUUID().toString().substring(0, 8);
        List<String> c = kubectl(a, "run", podName, "-n", str(a, "namespace"), "--rm", "-i", "-q",
                "--restart=Never", "--image=" + image);
        if (has(a, "labels")) c.add("--labels=" + str(a, "labels"));
        if (has(a, "service_account")) {
            c.add("--overrides={\"spec\":{\"serviceAccountName\":\"" + str(a, "service_account") + "\"}}");
        }
        c.add("--"); c.add("sh"); c.add("-c"); c.add(str(a, "command"));
        CommandRunner.Result r = CommandRunner.run(c, num(a, "timeout_seconds", 120));
        if (r.timedOut()) CommandRunner.run(kubectl(a, "delete", "pod", podName, "-n", str(a, "namespace"), "--ignore-not-found", "--grace-period=0", "--force"), 20);
        return fromResult(r);
    }

    private static JsonObject serviceProbe(JsonObject a) throws Exception {
        int port = num(a, "port", 0);
        if (port <= 0) return text("port is required.", true);
        int local = 20000 + new Random().nextInt(20000);
        List<String> pf = kubectl(a, "port-forward", str(a, "target"), local + ":" + port, "-n", str(a, "namespace"));
        System.out.println(" -> 💻 " + String.join(" ", pf));
        ProcessBuilder pb = new ProcessBuilder(pf);
        pb.redirectErrorStream(true);
        Process fwd = pb.start();
        try {
            // wait for "Forwarding from" or up to 8s
            long deadline = System.currentTimeMillis() + 8000;
            StringBuilder pfOut = new StringBuilder();
            var in = fwd.getInputStream();
            boolean ready = false;
            while (System.currentTimeMillis() < deadline && !ready) {
                while (in.available() > 0) pfOut.append((char) in.read());
                if (pfOut.toString().contains("Forwarding from")) ready = true;
                else if (!fwd.isAlive()) break;
                else Thread.sleep(200);
            }
            if (!ready) return text("port-forward failed to start:\n" + pfOut, true);

            String scheme = bool(a, "https", false) ? "https" : "http";
            String path = has(a, "path") ? str(a, "path") : "/";
            if (!path.startsWith("/")) path = "/" + path;
            List<String> curl = new ArrayList<>(List.of("curl", "-sS", "-i", "-k", "-m", "15",
                    "-X", has(a, "method") ? str(a, "method") : "GET", scheme + "://127.0.0.1:" + local + path));
            if (has(a, "headers")) for (String h : str(a, "headers").split("\n")) if (!h.isBlank()) { curl.add("-H"); curl.add(h.trim()); }
            if (has(a, "body")) { curl.add("--data-binary"); curl.add(str(a, "body")); }
            CommandRunner.Result r = CommandRunner.run(curl, 30);
            return text("Request via port-forward " + str(a, "target") + ":" + port + " (" + str(a, "namespace") + ")\n\n" + r.output(), r.failed());
        } finally {
            fwd.destroyForcibly();
        }
    }

    private static JsonObject apply(JsonObject a) throws Exception {
        File f = File.createTempFile("mcp_apply_", ".yaml");
        try {
            Files.writeString(f.toPath(), str(a, "yaml_manifest"));
            List<String> c = kubectl(a, "apply", "-f", f.getAbsolutePath());
            ns(c, a, false);
            String dry = str(a, "dry_run");
            if (!dry.isEmpty() && !"none".equals(dry)) c.add("--dry-run=" + dry);
            if (bool(a, "server_side", false)) { c.add("--server-side"); c.add("--force-conflicts"); c.add("--field-manager=kube-mcp"); }
            if (bool(a, "prune", false)) {
                if (!has(a, "selector")) return text("prune requires a selector.", true);
                c.add("--prune"); c.add("-l"); c.add(str(a, "selector"));
            }
            return fromResult(CommandRunner.run(c, LONG_TIMEOUT));
        } finally { f.delete(); }
    }

    private static JsonObject patch(JsonObject a) {
        List<String> c = kubectl(a, "patch", str(a, "resource"), str(a, "name"));
        ns(c, a, false);
        String type = has(a, "type") ? str(a, "type") : "strategic";
        c.add("--type=" + type);
        if (has(a, "subresource")) c.add("--subresource=" + str(a, "subresource"));
        c.add("-p"); c.add(str(a, "patch"));
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject scale(JsonObject a) {
        List<String> c = kubectl(a, "scale", str(a, "resource") + "/" + str(a, "name"), "-n", str(a, "namespace"),
                "--replicas=" + num(a, "replicas", 1));
        if (a.has("current_replicas")) c.add("--current-replicas=" + num(a, "current_replicas", 0));
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject set(JsonObject a) {
        String action = str(a, "action");
        String target = str(a, "resource") + "/" + str(a, "name");
        List<String> vals = list(a, "values");
        List<String> c = kubectl(a, "set", action, target, "-n", str(a, "namespace"));
        String container = has(a, "container") ? str(a, "container") : "*";
        switch (action) {
            case "image":
                if (vals.isEmpty()) return text("values must contain the image.", true);
                c.add(container + "=" + vals.get(0)); break;
            case "env":
                c.add("-c"); c.add(container); c.addAll(vals); break;
            case "resources":
                c.add("-c"); c.add(container); c.addAll(vals); break;
            case "serviceaccount":
                if (vals.isEmpty()) return text("values must contain the serviceaccount name.", true);
                c.add(vals.get(0)); break;
            default: return text("Unknown action: " + action, true);
        }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject labelAnnotate(JsonObject a) {
        List<String> c = kubectl(a, str(a, "action"), str(a, "resource"));
        if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); } else c.add(str(a, "name"));
        ns(c, a, false);
        if (bool(a, "overwrite", true)) c.add("--overwrite");
        c.addAll(list(a, "values"));
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject create(JsonObject a) {
        String kind = str(a, "kind");
        List<String> c = kubectl(a, "create");
        switch (kind) {
            case "namespace": c.add("namespace"); c.add(str(a, "name")); break;
            case "serviceaccount": c.add("serviceaccount"); c.add(str(a, "name")); ns(c, a, false); break;
            case "configmap":
                c.add("configmap"); c.add(str(a, "name")); ns(c, a, false);
                for (String l : list(a, "literals")) c.add("--from-literal=" + l);
                break;
            case "secret":
                c.add("secret"); c.add(has(a, "secret_type") ? str(a, "secret_type") : "generic"); c.add(str(a, "name")); ns(c, a, false);
                for (String l : list(a, "literals")) c.add("--from-literal=" + l);
                break;
            case "job":
                c.add("job"); c.add(str(a, "name")); ns(c, a, false);
                c.add("--from=cronjob/" + str(a, "from_cronjob"));
                break;
            case "token": c.add("token"); c.add(str(a, "name")); ns(c, a, false); break;
            default: return text("Unknown kind: " + kind, true);
        }
        return fromResult(CommandRunner.run(c, DEFAULT_TIMEOUT));
    }

    private static JsonObject delete(JsonObject a) {
        String res = str(a, "resource").toLowerCase();
        boolean dangerous = res.startsWith("ns") || res.startsWith("namespace") || res.equals("all") || res.contains("node")
                || res.startsWith("crd") || res.startsWith("customresourcedefinition") || res.startsWith("pv");
        if (dangerous && !bool(a, "confirm", false))
            return text("Refused: deleting '" + res + "' is high-impact. Re-run with confirm=true if intentional.", true);
        if (!has(a, "name") && !has(a, "selector")) return text("Provide name or selector.", true);

        List<String> c = kubectl(a, "delete", str(a, "resource"));
        if (has(a, "name")) c.add(str(a, "name"));
        if (has(a, "selector")) { c.add("-l"); c.add(str(a, "selector")); }
        ns(c, a, false);
        if (bool(a, "force", false)) { c.add("--force"); c.add("--grace-period=0"); }
        if (!bool(a, "wait", true)) c.add("--wait=false");
        if (bool(a, "ignore_not_found", false)) c.add("--ignore-not-found");
        return fromResult(CommandRunner.run(c, LONG_TIMEOUT));
    }

    private static JsonObject nodeOps(JsonObject a) {
        String action = str(a, "action");
        String node = str(a, "node");
        List<String> c;
        int t = DEFAULT_TIMEOUT;
        switch (action) {
            case "cordon": c = kubectl(a, "cordon", node); break;
            case "uncordon": c = kubectl(a, "uncordon", node); break;
            case "drain":
                t = num(a, "timeout_seconds", LONG_TIMEOUT);
                c = kubectl(a, "drain", node, "--timeout=" + t + "s");
                if (bool(a, "ignore_daemonsets", true)) c.add("--ignore-daemonsets");
                if (bool(a, "delete_emptydir_data", true)) c.add("--delete-emptydir-data");
                if (bool(a, "force", false)) c.add("--force");
                break;
            case "taint":
                if (!has(a, "taint")) return text("taint is required, e.g. key=value:NoSchedule or key:NoSchedule-", true);
                c = kubectl(a, "taint", "nodes", node, str(a, "taint"), "--overwrite"); break;
            default: return text("Unknown action: " + action, true);
        }
        return fromResult(CommandRunner.run(c, t + 10));
    }

    private static final Set<String> READ_VERBS = Set.of("get", "describe", "logs", "top", "explain", "api-resources", "api-versions",
            "cluster-info", "version", "diff", "auth", "config", "events", "wait", "rollout");

    private static JsonObject raw(JsonObject a) {
        List<String> args = list(a, "args");
        if (args.isEmpty()) return text("args is required.", true);
        if (READ_ONLY && !READ_VERBS.contains(args.get(0))) return text("Read-only mode: only " + READ_VERBS + " allowed.", true);
        for (String s : args) if (s.equals("--all-namespaces") && args.get(0).equals("delete"))
            return text("Refused: delete across all namespaces via raw is blocked. Use kubectl_delete with an explicit namespace.", true);
        List<String> c = kubectl(a); c.addAll(args);
        String stdin = has(a, "stdin") ? str(a, "stdin") : null;
        return fromResult(CommandRunner.run(c, num(a, "timeout_seconds", DEFAULT_TIMEOUT), stdin));
    }

    private static final Set<String> HELM_READ = Set.of("list", "ls", "status", "get", "history", "show", "search", "template",
            "version", "env", "lint", "dependency", "verify");

    private static JsonObject helmTool(JsonObject a) {
        List<String> args = list(a, "args");
        if (args.isEmpty()) return text("args is required.", true);
        boolean readOp = HELM_READ.contains(args.get(0)) || (args.get(0).equals("repo") && args.size() > 1 && args.get(1).equals("list"));
        if (READ_ONLY && !readOp) return text("Read-only mode: helm write operations refused.", true);
        String stdin = has(a, "stdin") ? str(a, "stdin") : null;
        return fromResult(CommandRunner.run(helm(a, args), num(a, "timeout_seconds", LONG_TIMEOUT), stdin));
    }

    private static final Set<String> LOCAL_READ = Set.of("status", "ip", "version", "profile", "get", "list", "logs", "dashboard", "service", "node", "addons");

    private static JsonObject localCluster(JsonObject a) {
        String toolName = str(a, "tool");
        List<String> args = list(a, "args");
        if (args.isEmpty()) return text("args is required.", true);
        if (READ_ONLY) {
            boolean ok = LOCAL_READ.contains(args.get(0)) && !(args.size() > 1 && Set.of("enable", "disable", "create", "delete", "start", "stop").contains(args.get(1)));
            if (!ok) return text("Read-only mode: only status/inspection commands allowed.", true);
        }
        if (!CommandRunner.available(toolName)) return text(toolName + " is not installed on the MCP host.", true);
        List<String> c = new ArrayList<>(); c.add(toolName); c.addAll(args);
        return fromResult(CommandRunner.run(c, num(a, "timeout_seconds", LONG_TIMEOUT)));
    }

    private static JsonObject shell(JsonObject a) {
        if (!ALLOW_SHELL) return text("run_shell is disabled. Start the server with MCP_ALLOW_SHELL=true to enable host shell access.", true);
        boolean win = System.getProperty("os.name").toLowerCase().contains("win");
        List<String> c = win ? List.of("cmd", "/c", str(a, "command")) : List.of("sh", "-c", str(a, "command"));
        return fromResult(CommandRunner.run(c, num(a, "timeout_seconds", DEFAULT_TIMEOUT)));
    }
}

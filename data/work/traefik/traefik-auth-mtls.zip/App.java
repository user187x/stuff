package middleware;

import io.javalin.Javalin;
import io.javalin.http.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class App {
  private static final Logger log = LoggerFactory.getLogger(App.class);

  private static final int PORT =
      Integer.parseInt(System.getenv().getOrDefault("AUTH_SHIM_PORT", "8080"));
  private static final String VALIDATOR_URL =
      System.getenv().getOrDefault("VALIDATOR_URL", "https://auth-api.local/verify");
  private static final String TLS_CRT_PATH =
      System.getenv().getOrDefault("TLS_CRT_PATH", "/etc/certs/tls.crt");
  private static final boolean ALLOW_INSECURE_FALLBACK = Boolean.parseBoolean(
      System.getenv().getOrDefault("ALLOW_INSECURE_TRUST_FALLBACK", "false"));

  private static final Duration VALIDATOR_TIMEOUT = Duration.ofSeconds(3);
  private static final Duration CONNECT_TIMEOUT = Duration.ofSeconds(5);

  // Pattern matches Subject="..." in the URL-decoded Info header, allowing
  // escaped quotes inside the DN (rare but legal per RFC 4514).
  private static final Pattern SUBJECT_PATTERN =
      Pattern.compile("Subject=\"((?:[^\"\\\\]|\\\\.)*)\"");

  // Readiness flips to true once the HttpClient is built and we've started Javalin.
  private static final AtomicReference<Boolean> ready = new AtomicReference<>(false);

  private static final HttpClient httpClient = buildSecureHttpClient();

  public static void main(String[] args) {
    Javalin.create(config -> {
      config.http.defaultContentType = "text/plain";
      config.routes.get("/auth", App::handleForwardAuth);
      config.routes.post("/auth", App::handleForwardAuth);
      config.routes.get("/health", ctx -> ctx.status(200).result("OK"));
      config.routes.get("/ready", ctx -> {
        if (Boolean.TRUE.equals(ready.get())) {
          ctx.status(200).result("READY");
        } else {
          ctx.status(503).result("NOT READY");
        }
      });
    }).start(PORT);

    ready.set(true);
    log.info("auth-shim listening on :{} (validator={})", PORT, VALIDATOR_URL);
  }

  private static void handleForwardAuth(Context ctx) {
    String correlationId = UUID.randomUUID().toString();
    String userDn = extractUserDn(ctx);

    if (userDn == null || userDn.isBlank()) {
      log.warn("[{}] denied: no client certificate DN in headers", correlationId);
      ctx.status(401).result("Client Certificate Required");
      return;
    }

    // Avoid logging the full DN at INFO — it's PII. Log a fingerprint instead.
    log.info("[{}] validating DN (len={})", correlationId, userDn.length());
    log.debug("[{}] DN={}", correlationId, userDn);

    if (validateDnExternally(userDn, correlationId)) {
      log.info("[{}] authorized", correlationId);
      ctx.header("X-Forwarded-User-Dn", userDn);
      ctx.header("X-Auth-Correlation", correlationId);
      ctx.status(200).result("OK");
    } else {
      log.warn("[{}] denied: external validator rejected DN", correlationId);
      ctx.status(403).result("Forbidden: Invalid Certificate Identity");
    }
  }

  private static boolean validateDnExternally(String dn, String correlationId) {
    try {
      String encodedDn = URLEncoder.encode(dn, StandardCharsets.UTF_8);
      URI targetUri = URI.create(VALIDATOR_URL + "?dn=" + encodedDn);

      HttpRequest request = HttpRequest.newBuilder()
          .uri(targetUri)
          .header("X-Request-Id", correlationId)
          .header("Accept", "application/json,text/plain")
          .timeout(VALIDATOR_TIMEOUT)
          .GET()
          .build();

      HttpResponse<String> response =
          httpClient.send(request, HttpResponse.BodyHandlers.ofString());

      if (response.statusCode() != 200) {
        log.warn("[{}] validator returned {}: {}", correlationId,
            response.statusCode(), truncate(response.body()));
        return false;
      }
      return true;

    } catch (Exception e) {
      log.error("[{}] validator request failed: {}", correlationId, e.getMessage());
      return false; // fail closed
    }
  }

  /**
   * Extracts the user's DN from Traefik's passTLSClientCert headers.
   *
   * Handles three real-world formats of X-Forwarded-Tls-Client-Cert:
   *   1. Full PEM with -----BEGIN/END CERTIFICATE----- markers (older Traefik / some configs)
   *   2. URL-encoded PEM (Traefik v2.8 - v2.9.3)
   *   3. Base64-only body with delimiters & newlines stripped (Traefik >= v2.9.4 incl. v3.x)
   *
   * Falls back to X-Forwarded-Tls-Client-Cert-Info if cert parsing fails.
   */
  static String extractUserDn(Context ctx) {
    String rawCert = ctx.header("X-Forwarded-Tls-Client-Cert");
    if (rawCert != null && !rawCert.isBlank()) {
      try {
        X509Certificate cert = parseTraefikCertHeader(rawCert);
        if (cert != null) {
          return cert.getSubjectX500Principal().getName();
        }
      } catch (Exception e) {
        log.warn("Failed to parse X-Forwarded-Tls-Client-Cert header: {}", e.getMessage());
        log.debug("Cert header parse failure detail", e);
      }
    }

    String infoHeader = ctx.header("X-Forwarded-Tls-Client-Cert-Info");
    if (infoHeader != null && !infoHeader.isBlank()) {
      try {
        String decoded = URLDecoder.decode(infoHeader, StandardCharsets.UTF_8);
        Matcher matcher = SUBJECT_PATTERN.matcher(decoded);
        if (matcher.find()) {
          return matcher.group(1);
        }
        log.warn("Info header present but Subject= not found");
      } catch (Exception e) {
        log.warn("Failed to parse Info header: {}", e.getMessage());
      }
    }
    return null;
  }

  private static X509Certificate parseTraefikCertHeader(String raw) throws Exception {
    CertificateFactory cf = CertificateFactory.getInstance("X.509");

    String value = raw.trim();

    // Case 2: URL-encoded — decode first.
    if (value.indexOf('%') >= 0) {
      value = URLDecoder.decode(value, StandardCharsets.UTF_8);
    }

    // Case 1: already PEM with markers.
    if (value.contains("-----BEGIN CERTIFICATE-----")) {
      return (X509Certificate) cf.generateCertificate(
          new ByteArrayInputStream(value.getBytes(StandardCharsets.UTF_8)));
    }

    // Case 3: base64-only body. Strip any incidental whitespace and decode.
    String b64 = value.replaceAll("\\s+", "");
    byte[] der = Base64.getDecoder().decode(b64);
    return (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(der));
  }

  /**
   * Builds an HttpClient with a TrustStore loaded from the mounted CA bundle.
   * Fails fast on misconfiguration unless ALLOW_INSECURE_TRUST_FALLBACK=true (dev only).
   */
  private static HttpClient buildSecureHttpClient() {
    try {
      CertificateFactory cf = CertificateFactory.getInstance("X.509");
      X509Certificate caCert;
      try (InputStream is = new FileInputStream(TLS_CRT_PATH)) {
        caCert = (X509Certificate) cf.generateCertificate(is);
      }

      KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(null, null);
      keyStore.setCertificateEntry("validator-ca", caCert);

      TrustManagerFactory tmf =
          TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      tmf.init(keyStore);

      SSLContext sslContext = SSLContext.getInstance("TLS");
      sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());

      log.info("Loaded validator CA from {}", TLS_CRT_PATH);

      return HttpClient.newBuilder()
          .sslContext(sslContext)
          .connectTimeout(CONNECT_TIMEOUT)
          .followRedirects(HttpClient.Redirect.NEVER)
          .version(HttpClient.Version.HTTP_2)
          .build();

    } catch (Exception e) {
      if (ALLOW_INSECURE_TRUST_FALLBACK) {
        log.warn("CA load failed at {} — falling back to system trust store (DEV ONLY): {}",
            TLS_CRT_PATH, e.getMessage());
        return HttpClient.newBuilder()
            .connectTimeout(CONNECT_TIMEOUT)
            .followRedirects(HttpClient.Redirect.NEVER)
            .build();
      }
      throw new IllegalStateException(
          "Failed to load validator CA from " + TLS_CRT_PATH
              + ". Set ALLOW_INSECURE_TRUST_FALLBACK=true to use system trust (dev only).",
          e);
    }
  }

  private static String truncate(String s) {
    if (s == null) return "";
    return s.length() <= 200 ? s : s.substring(0, 200) + "…";
  }
}

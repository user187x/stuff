# Fixed k3d + Traefik Gateway API + Podinfo stack

Run order:

```bash
./gen-certs        # issues pki/tls-wildcard.crt (needs pki/ca.key to reuse your trusted CA)
./init-k3d         # cluster + Calico, host ports 80/443 mapped in
./inst-app         # Gateway API CRDs, Traefik, Gateway (TLS), Podinfo, HTTPRoutes
./cnct-web         # patches /etc/hosts; tunnel only if 443 isn't already live
```

Then browse **https://traefik.xxx.local/dashboard/** and **https://podinfo.xxx.local/**
(with `pki/ca.crt` imported in the browser).

## File layout expected

```
.
├── gen-certs  init-k3d  inst-app  cnct-web
├── pki/
│   ├── ca.crt            # your existing CA (already trusted in the browser)
│   ├── ca.key            # ← place it here so gen-certs can sign the wildcard cert
│   └── tls-wildcard.key  # reused if present, generated otherwise
└── lib/manifest.yaml     # optional vendored Gateway API CRDs (downloaded if absent)
```

## What was broken and what changed

**TLS (the reason the browser rejected everything):** `pki/tls.crt` only has
SAN `DNS:xxx.local`. A cert for the apex does **not** cover subdomains, so
`traefik.xxx.local` and `podinfo.xxx.local` failed TLS validation even with the
CA trusted. `tls-wildcard.key` existed but no wildcard certificate was ever
issued for it. New `gen-certs` signs `*.xxx.local` + `xxx.local` (EKU
serverAuth, ≤398-day validity) with your existing CA — browser trust is
preserved as long as `pki/ca.key` is present. `inst-app` now validates the SAN
before creating the secret and uses `pki/tls-wildcard.{crt,key}`.

**init-k3d**
- Added `-p 80:80@loadbalancer` and `-p 443:443@loadbalancer` so the host's
  browser can reach the cluster on standard ports (via k3s ServiceLB →
  Traefik's LoadBalancer Service). Previously nothing exposed 443 except the
  sudo port-forward.
- Added `--cluster-cidr=192.168.0.0/16` so the k3s pod CIDR matches the Tigera
  operator's default IPPool (it defaults to 192.168.0.0/16, k3s to
  10.42.0.0/16 — the mismatch breaks pod networking).
- `helm --wait` only waits for the operator, so the script now also waits for
  the `calico-node` DaemonSet rollout before waiting on CoreDNS.

**inst-app**
- CRD logic was inverted: `CRD_FILE` was always non-empty, so it always applied
  `lib/manifest.yaml` and crashed if the file didn't exist. Now: use the local
  file only if it exists, otherwise download the pinned release (v1.5.1, the
  version Traefik v3's own quickstart installs — v1.6.0 was unvalidated).
- Removed `ports.websecure.port: 443`: Traefik runs as non-root and cannot
  bind :443 in the container, so the pod failed. The container keeps 8443 and
  the Service exposes it as 443 (chart default).
- Gateway listener changed **443 → 8443** with `hostname: "*.xxx.local"`.
  Traefik requires the listener port to equal an *entrypoint* port (websecure
  = 8443), not the Service port. Clients still use 443 (Service maps 443→8443).
- Removed the hand-made `GatewayClass` and set `gateway.enabled: false`: with
  `kubernetesGateway` enabled, the Helm chart itself creates the GatewayClass
  `traefik` **and** a default Gateway named `traefik-gateway`, which collided
  with the script's resources.
- Chart repo updated to the official `https://traefik.github.io/charts`,
  `--force-update` on `helm repo add` so re-runs don't die under `set -e`,
  and a `kubectl wait --for=condition=Programmed` on the Gateway.

**cnct-web**
- Under `set -e`, a failing tunnel killed the script before `$?` could be
  captured — the success/failure message never printed. Fixed with
  `"$@" || exit_code=$?`.
- Dots in domains are now escaped in the `sed` cleanup of `/etc/hosts`.
- After patching hosts, it probes `https://<first-domain>/`; if the k3d port
  mapping already serves 443 it exits — the sudo port-forward tunnel is now
  only a fallback for clusters created with the old `init-k3d`.

## Notes

- The dashboard is at `https://traefik.xxx.local/dashboard/` (the root path
  302-redirects there because of `--api.insecure=true` on entrypoint 9000).
- If you don't have `pki/ca.key`, `gen-certs` refuses to guess: either supply
  the key, or delete `pki/ca.crt` to let it mint a fresh CA (then re-import
  the new `ca.crt` into the browser).

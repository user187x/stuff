package xxx;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static java.util.prefs.Preferences.userNodeForPackage;

public class Transceiver implements Serializable {

 public static final boolean DefindCheckRFDevice = false;
 private static final long serialVersionUID = -6868716251078362877L;
 public LoraUtil mloralib;
 private ArrayList<String> mLoRaSerialPortString;
 private String mDeviceID;
 public byte Freq1 = 1;
 public byte Freq2 = 101;
 public byte Freq3 = 108;
 public byte Power = 3;
 public int m_BaudRate = 9600;

 private JComboBox<String> mUIComPortName;
 private JTextArea logText;
 private JTextArea recevieText;
 private JTextArea sendText;
 private JComboBox<String> mChoiceRecevieDisplay;
 private JFrame mainFrame;
 private JLabel labelMessage;
 private JLabel labelLoRaStatus;
 private JLabel commIndicator;
 private JLabel mLabelStatus;
 private JLabel mLabelID;
 private JLabel mLabelFirmware;
 private JComboBox<String> ChoiceKind;

 public String mDomainName = "http://dashboard.local/";
 private Transceiver transceiverFrameClass;
 public App app;
 public String StringLogFileName;
 public String TextFieldUrl;
 public String checkBoxSaveLog;
 public String checkBoxUpload;
 public String checkBoxDashboard;
 public String Frequency;
 public String PersonId;
 public String ProjectId;
 public String APIKEY;
 public long mCounter;

 static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
 static SecureRandom rnd = new SecureRandom();
 private ThreadRecevieText mThreadRecevieText;

 public void savePreference(String PREF_NAME, String newValue) {
  java.util.prefs.Preferences prefs = userNodeForPackage(this.getClass());
  prefs.put(PREF_NAME, newValue);
 }

 public String loadPreferences(String PREF_NAME, String defaultValue) {
  java.util.prefs.Preferences prefs = userNodeForPackage(this.getClass());
  return prefs.get(PREF_NAME, defaultValue);
 }

 public Transceiver() {
  // Pre-initialize the log text area so we can accept logs even during early setup
  this.logText = new JTextArea(10, 25);
  this.logText.setEditable(false);
  this.logText.setBackground(new Color(40, 42, 54));
  this.logText.setForeground(Color.LIGHT_GRAY);

  this.StringLogFileName = "RF.csv";
  this.data_init();
  if (this.mloralib == null) {
   // Pass our appendLog method so LoraUtil prints to the UI instead of the console
   this.mloralib = new LoraUtil(this.m_BaudRate, 193, this::appendLog);
  }

  this.mDeviceID = "";
  this.transceiverFrameClass = this;
 }

 public void init() {
  this.mainFrame = new JFrame("RF Manager");
  this.mainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
  this.mainFrame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent windowEvent) {
    Transceiver.this.TreadStop();
    if (Transceiver.this.mloralib != null) {
     Transceiver.this.mloralib.FunLora_close();
    }
    System.exit(0);
   }
  });

  // Display Animated Loading Pane first to prevent UI freezing
  JPanel loadingPanel = new JPanel(new BorderLayout(10, 10));
  loadingPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
  JLabel loadingLabel = new JLabel("Searching Devices...", SwingConstants.CENTER);
  JProgressBar progressBar = new JProgressBar();
  progressBar.setIndeterminate(true);
  loadingPanel.add(loadingLabel, BorderLayout.CENTER);
  loadingPanel.add(progressBar, BorderLayout.SOUTH);

  this.mainFrame.setContentPane(loadingPanel);
  this.mainFrame.pack();
  this.mainFrame.setMinimumSize(new Dimension(650, 450));
  this.mainFrame.setLocationRelativeTo(null);
  this.mainFrame.setVisible(true);

  // Run the blocking startup functions in a background thread
  SwingWorker<Void, Void> initWorker = new SwingWorker<>() {
   @Override
   protected Void doInBackground() {
    mLoRaSerialPortString = mloralib.serial_allPorts(); // This can be slow
    data_app_dashboard(); // This does HTTP calls which are also slow
    return null;
   }

   @Override
   protected void done() {
    buildMainUI(); // Build the actual UI after loading is finished
   }
  };
  initWorker.execute();
 }

 private void buildMainUI() {
  this.labelMessage = new JLabel("Status: Ready");
  this.labelLoRaStatus = new JLabel("LoRa Turn Close");

  JPanel mainContent = new JPanel(new BorderLayout());

  JPanel mainPanel = new JPanel();
  mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
  mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

  mainPanel.add(devicePanel());
  mainPanel.add(Box.createVerticalStrut(10));
  mainPanel.add(deviceSettingsPanel());
  mainPanel.add(Box.createVerticalStrut(10));
  mainPanel.add(transmissionPanel());

  JPanel statusBar = new JPanel(new BorderLayout());
  statusBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

  JPanel leftStatus = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
  this.commIndicator = new JLabel("● Disconnected");
  this.commIndicator.setForeground(Color.RED);
  leftStatus.add(this.commIndicator);
  leftStatus.add(this.labelMessage);

  statusBar.add(leftStatus, BorderLayout.WEST);
  statusBar.add(this.labelLoRaStatus, BorderLayout.EAST);

  mainContent.add(mainPanel, BorderLayout.CENTER);
  mainContent.add(statusBar, BorderLayout.SOUTH);

  this.mainFrame.setContentPane(mainContent);
  this.showMenu();

  // Set larger dimensions so elements don't bunch up
  this.mainFrame.setPreferredSize(new Dimension(1050, 750));
  this.mainFrame.setMinimumSize(new Dimension(950, 700));
  this.mainFrame.pack();
  this.mainFrame.setLocationRelativeTo(null);
 }

 public void appendLog(String message) {
  SwingUtilities.invokeLater(() -> {
   if (logText != null) {
    logText.append(message + "\n");
    logText.setCaretPosition(logText.getDocument().getLength());
   }
  });
 }

 public void setConnectionStatus(boolean connected) {
  SwingUtilities.invokeLater(() -> {
   if (commIndicator != null) {
    if (connected) {
     commIndicator.setText("● Connected");
     commIndicator.setForeground(Color.GREEN);
    } else {
     commIndicator.setText("● Disconnected");
     commIndicator.setForeground(Color.RED);
    }
   }
  });
 }

 private void ui_Setp1_OpenComPort() {
  if (this.mUIComPortName.getSelectedItem() != null && !this.mUIComPortName.getSelectedItem().toString().contains("Select LoRa")) {
   this.labelMessage.setText("Connect Device: " + this.mUIComPortName.getSelectedItem());
   this.mloralib.SerialPort_setSerialPort((String)this.mUIComPortName.getSelectedItem());
  }
 }

 private void data_init() {
  this.StringLogFileName = this.loadPreferences("StringLogFileName", "app.csv");
  this.TextFieldUrl = this.loadPreferences("TextFieldUrl", "http://127.0.0.1/index.php?data=");
  this.checkBoxSaveLog = this.loadPreferences("checkBoxSaveLog", "false");
  this.checkBoxUpload = this.loadPreferences("checkBoxUpload", "false");
  this.checkBoxDashboard = this.loadPreferences("checkBoxDashboard", "true");
  this.Frequency = this.loadPreferences("Frequency", "915.00");
  float tFloatFrequency = Float.parseFloat(this.Frequency);
  tFloatFrequency *= 100.0F;
  int tIntFrequency = (int)tFloatFrequency;
  int tFreq1 = tIntFrequency / 65536;
  int tFreq2 = (tIntFrequency - tFreq1 * 65536) / 256;
  int tFreq3 = tIntFrequency % 256;
  this.Freq1 = (byte)tFreq1;
  this.Freq2 = (byte)tFreq2;
  this.Freq3 = (byte)tFreq3;
  String tPower = this.loadPreferences("Power", "3");
  this.Power = (byte)Integer.parseInt(tPower);
  this.ProjectId = this.loadPreferences("ProjectId", "60");
  this.mDeviceID = this.loadPreferences("mDeviceID", "010000D5");
  this.APIKEY = this.loadPreferences("APIKEY", "");
  this.mCounter = Long.parseLong(this.loadPreferences("mCounter", "0"));
  String t4 = this.loadPreferences("BaudRate", "115200");
  this.m_BaudRate = Integer.parseInt(t4);
 }

 private void ui_Setp1_listPortsAsync() {
  this.labelMessage.setText("Searching:");
  this.mUIComPortName.setEnabled(false);

  SwingWorker<ArrayList<String>, Void> scanWorker = new SwingWorker<>() {
   @Override
   protected ArrayList<String> doInBackground() {
    return mloralib.serial_allPorts();
   }

   @Override
   protected void done() {
    try {
     mLoRaSerialPortString = get();
     mUIComPortName.removeAllItems();
     if (mLoRaSerialPortString != null && !mLoRaSerialPortString.isEmpty()) {
      for(String port : mLoRaSerialPortString) {
       mUIComPortName.addItem(port);
      }
     } else {
      mUIComPortName.addItem("Select");
     }
     mUIComPortName.setEnabled(true);
     ui_Setp1_OpenComPort();
     labelMessage.setText("Scan complete.");
    } catch (Exception e) {
     appendLog("Error scanning ports: " + e.getMessage());
    }
   }
  };
  scanWorker.execute();
 }

 public JPanel devicePanel() {
  JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
  panel.setBorder(BorderFactory.createTitledBorder("Device"));

  panel.add(new JLabel("ComPort"));

  this.mUIComPortName = new JComboBox<>();
  if (this.mLoRaSerialPortString != null && !this.mLoRaSerialPortString.isEmpty()) {
   for(String port : this.mLoRaSerialPortString) {
    this.mUIComPortName.addItem(port);
   }
   ui_Setp1_OpenComPort();
  } else {
   this.mUIComPortName.addItem("Select");
  }

  this.mUIComPortName.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    try {
     String data = "LoRa Device Selected: " + Transceiver.this.mUIComPortName.getItemAt(Transceiver.this.mUIComPortName.getSelectedIndex());
     Transceiver.this.labelMessage.setText(data);
     Transceiver.this.ui_Setp1_OpenComPort();
    } catch (Exception var3) {
     Transceiver.this.labelMessage.setText("Disconnect");
    }
   }
  });
  panel.add(this.mUIComPortName);

  JButton refreshButton = new JButton("\uD83D\uDDD8");
  refreshButton.setToolTipText("Refresh");
  refreshButton.addActionListener(e -> Transceiver.this.ui_Setp1_listPortsAsync());
  panel.add(refreshButton);

  return panel;
 }

 public JPanel deviceSettingsPanel() {
  JPanel panel = new JPanel();
  panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
  panel.setBorder(BorderFactory.createTitledBorder("Device Settings"));

  JPanel infoRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 5));
  this.mLabelStatus = new JLabel("Status: No Device");
  this.mLabelID = new JLabel("MAC Address:");
  this.mLabelFirmware = new JLabel("Firmware:");
  infoRow.add(this.mLabelStatus);
  infoRow.add(this.mLabelID);
  infoRow.add(this.mLabelFirmware);
  panel.add(infoRow);

  // -- NEW SETTINGS ROW (Relocated from Preferences) --
  JPanel settingsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));

  // 1. SDR++ Style Frequency Spinners
  JPanel freqPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
  freqPanel.add(new JLabel("Freq: "));

  float currentFreq = 915.00f;
  try {
   currentFreq = Float.parseFloat(Transceiver.this.Frequency);
  } catch (NumberFormatException ignored) {}

  int initGhz = (int) (currentFreq / 1000);
  int initMhz = (int) (currentFreq % 1000);
  int initHz = (int) Math.round((currentFreq - (int)currentFreq) * 1000);

  JSpinner ghzSpinner = new JSpinner(new SpinnerNumberModel(initGhz, 0, 999, 1));
  JSpinner mhzSpinner = new JSpinner(new SpinnerNumberModel(initMhz, 0, 999, 1));
  JSpinner hzSpinner = new JSpinner(new SpinnerNumberModel(initHz, 0, 999, 1));

  // Force 3-digit display with zero-padding
  ghzSpinner.setEditor(new JSpinner.NumberEditor(ghzSpinner, "000"));
  mhzSpinner.setEditor(new JSpinner.NumberEditor(mhzSpinner, "000"));
  hzSpinner.setEditor(new JSpinner.NumberEditor(hzSpinner, "000"));

  javax.swing.event.ChangeListener freqListener = e -> {
   int g = (Integer) ghzSpinner.getValue();
   int m = (Integer) mhzSpinner.getValue();
   int h = (Integer) hzSpinner.getValue();
   float newFreq = (g * 1000f) + m + (h / 1000f);

   Transceiver.this.Frequency = String.format(java.util.Locale.US, "%.3f", newFreq);
   Transceiver.this.savePreference("Frequency", Transceiver.this.Frequency);

   float tFloatFrequency = newFreq * 100.0F;
   int tIntFrequency = (int)tFloatFrequency;
   Transceiver.this.Freq1 = (byte)(tIntFrequency / 65536);
   Transceiver.this.Freq2 = (byte)((tIntFrequency - Transceiver.this.Freq1 * 65536) / 256);
   Transceiver.this.Freq3 = (byte)(tIntFrequency % 256);
  };

  ghzSpinner.addChangeListener(freqListener);
  mhzSpinner.addChangeListener(freqListener);
  hzSpinner.addChangeListener(freqListener);

  freqPanel.add(ghzSpinner);
  freqPanel.add(new JLabel(" GHz . "));
  freqPanel.add(mhzSpinner);
  freqPanel.add(new JLabel(" MHz . "));
  freqPanel.add(hzSpinner);
  freqPanel.add(new JLabel(" Hz "));
  settingsRow.add(freqPanel);

  // 2. Power Setting
  JPanel powerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
  powerPanel.add(new JLabel("Power: "));
  JComboBox<String> choicePower = new JComboBox<>();
  for (int i = 0; i <= 15; ++i) {
   choicePower.addItem((i + 2) + " dBm");
  }
  choicePower.setSelectedIndex(Transceiver.this.Power);
  choicePower.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    Transceiver.this.Power = (byte) choicePower.getSelectedIndex();
    Transceiver.this.savePreference("Power", Integer.toString(Transceiver.this.Power));
   }
  });
  powerPanel.add(choicePower);
  settingsRow.add(powerPanel);

  // 3. Baud Rate Setting
  JPanel baudPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 0));
  baudPanel.add(new JLabel("Baud: "));
  int[] baudRates = new int[]{1200, 2400, 4800, 19200, 38400, 57600, 115200};
  JComboBox<String> choiceBaudRate = new JComboBox<>();
  int defaultBaudIndex = 6;
  for (int i = 0; i < baudRates.length; ++i) {
   choiceBaudRate.addItem(baudRates[i] + " bps");
   if (baudRates[i] == Transceiver.this.m_BaudRate) {
    defaultBaudIndex = i;
   }
  }
  choiceBaudRate.setSelectedIndex(defaultBaudIndex);
  choiceBaudRate.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    Transceiver.this.m_BaudRate = baudRates[choiceBaudRate.getSelectedIndex()];
    Transceiver.this.savePreference("BaudRate", Integer.toString(Transceiver.this.m_BaudRate));
   }
  });
  baudPanel.add(choiceBaudRate);
  settingsRow.add(baudPanel);

  panel.add(settingsRow);
  // -- END NEW SETTINGS ROW --

  JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
  JComboBox<String> LoRaModeChoice = new JComboBox<>();
  LoRaModeChoice.addItem("Broadcast");
  LoRaModeChoice.addItem("Node (Client)");
  LoRaModeChoice.addItem("Gateway (Server)");
  LoRaModeChoice.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    String data = "LoRa Device Setup to: " + LoRaModeChoice.getItemAt(LoRaModeChoice.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
   }
  });
  actionRow.add(LoRaModeChoice);

  final JButton startButton = new JButton("Connect");
  startButton.addActionListener(e -> {
   if (Transceiver.this.mThreadRecevieText != null) {
    Transceiver.this.labelMessage.setText("Disconnect");
    Transceiver.this.labelLoRaStatus.setText("LoRa Turn Close");
    startButton.setText("Connect");
    Transceiver.this.mDeviceID = "";

    Transceiver.this.TreadStop();
    Transceiver.this.mloralib.FunLora_close();
    Transceiver.this.setConnectionStatus(false);
    appendLog("System: Disconnected from Device.");

    Transceiver.this.mLabelStatus.setText("Status: No LoRa Device");
    Transceiver.this.mLabelID.setText("MAC Address:");
    Transceiver.this.mLabelFirmware.setText("Firmware Version:");
   } else {
    Transceiver.this.labelMessage.setText("Connect");
    Transceiver.this.mDeviceID = Transceiver.this.mloralib.GetDeviceID();
    Transceiver.this.TreadStop();

    if (Transceiver.this.mDeviceID != null && !Transceiver.this.mDeviceID.isEmpty()) {
     Transceiver.this.setConnectionStatus(true);
     appendLog("System: Connected to Device (" + Transceiver.this.mDeviceID + ").");
    } else {
     Transceiver.this.setConnectionStatus(false);
     appendLog("System: Failed to connect or retrieve Device ID.");
    }

    startButton.setText("Disconnect");
    String StringID = Integer.toString(Transceiver.this.mloralib.GetFirmwareVersion());
    Transceiver.this.labelLoRaStatus.setText("Enable LoRa ID " + Transceiver.this.mDeviceID + ", Firmware Version:" + StringID);
    Transceiver.this.mLabelStatus.setText("Enable LoRa ID " + Transceiver.this.mDeviceID + ", Firmware Version:" + StringID);
    Transceiver.this.mLabelID.setText("MAC Address:" + Transceiver.this.mDeviceID);
    Transceiver.this.mLabelFirmware.setText("Firmware Version:" + StringID);
    Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
    Transceiver.this.TreadStart();
    Transceiver.this.labelMessage.setText("RF LoRa Device working, now.");
   }
  });
  actionRow.add(startButton);

  JButton preferencesButton = new JButton("Preferences");
  preferencesButton.addActionListener(e -> {
   Transceiver.this.labelMessage.setText("Preferences Opened");
   new Preferences(Transceiver.this.transceiverFrameClass);
  });
  actionRow.add(preferencesButton);

  panel.add(actionRow);
  return panel;
 }
 public JPanel transmissionPanel() {
  JPanel outerPanel = new JPanel(new BorderLayout(10, 0));
  outerPanel.setBorder(BorderFactory.createTitledBorder("Transmission"));

  JPanel logPanel = new JPanel(new BorderLayout());
  logPanel.add(new JLabel(" Activity"), BorderLayout.NORTH);

  JScrollPane logScroll = new JScrollPane(this.logText);
  logPanel.add(logScroll, BorderLayout.CENTER);

  outerPanel.add(logPanel, BorderLayout.WEST);

  JPanel rightPanel = new JPanel();
  rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

  JPanel sendRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
  sendRow.add(new JLabel(" Transmit Data "));

  this.ChoiceKind = new JComboBox<>();
  this.ChoiceKind.addItem("Text (UTF-8):");
  this.ChoiceKind.addItem("Hex (00 to ff) for E.g 01,aa");
  this.ChoiceKind.addItem("Decimal (0 to 255) E.g: 1,122,255");
  this.ChoiceKind.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    String data = "Setup: " + Transceiver.this.ChoiceKind.getItemAt(Transceiver.this.ChoiceKind.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
   }
  });
  sendRow.add(this.ChoiceKind);

  JButton buttonSend = new JButton("Send");
  buttonSend.addActionListener(e -> {
   Transceiver.this.TreadStop();
   try {
    TimeUnit.MILLISECONDS.sleep(100L);
   } catch (InterruptedException e1) {
    e1.printStackTrace();
   }

   Transceiver.this.mloralib.WriteMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
   String tSendTextString = Transceiver.this.sendText.getText();
   Transceiver.this.labelMessage.setText("Send:" + tSendTextString);
   appendLog("Send: " + tSendTextString);

   try {
    TimeUnit.MILLISECONDS.sleep(100L);
   } catch (InterruptedException e1) {
    e1.printStackTrace();
   }

   if (Transceiver.this.ChoiceKind.getSelectedIndex() == 0) {
    int len = tSendTextString.length();
    if (len > 16) len = 16;
    byte[] data = tSendTextString.getBytes(StandardCharsets.UTF_8);
    Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len);
   } else if (Transceiver.this.ChoiceKind.getSelectedIndex() == 1) {
    try {
     String[] parts = tSendTextString.split(",");
     int len1 = parts.length;
     if (len1 > 16) len1 = 16;
     byte[] data = new byte[len1];
     for(int i = 0; i < len1; ++i) {
      data[i] = (byte)((int)Long.parseLong(parts[i], 16));
     }
     Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len1);
    } catch (NumberFormatException ignored) {}
   } else if (Transceiver.this.ChoiceKind.getSelectedIndex() == 2) {
    try {
     String[] parts = tSendTextString.split(",");
     int len1 = parts.length;
     if (len1 > 16) len1 = 16;
     byte[] data = new byte[len1];
     for(int i = 0; i < len1; ++i) {
      data[i] = (byte)((int)Long.parseLong(parts[i], 10));
     }
     Transceiver.this.mloralib.FunLora_5_write16bytesArray(data, len1);
    } catch (NumberFormatException ignored) {}
   }

   try {
    TimeUnit.MILLISECONDS.sleep(100L);
   } catch (InterruptedException e1) {
    e1.printStackTrace();
   }

   Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
   Transceiver.this.TreadStart();
  });

  // Track the current state of the button
  final boolean[] isLocked = {false};

  JButton encryption = new JButton("\uD83D\uDD13"); // Unlocked icon
  encryption.setToolTipText("Encrypt");

  encryption.addActionListener(e -> {
   // Toggle state
   isLocked[0] = !isLocked[0];

   if (isLocked[0]) {
    encryption.setText("\uD83D\uDD12"); // Closed lock glyph
    encryption.setToolTipText("Decrypt");
    // TODO: Add your encryption logic here
   } else {
    encryption.setText("\uD83D\uDD13"); // Open lock glyph
    encryption.setToolTipText("Encrypt");
    // TODO: Add your decryption logic here
   }
  });

  sendRow.add(encryption);
  sendRow.add(buttonSend);
  rightPanel.add(sendRow);

  this.sendText = new JTextArea(4, 40);
  this.sendText.setText("Send data");
  JScrollPane sendScroll = new JScrollPane(this.sendText);
  rightPanel.add(sendScroll);

  JPanel receiveRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
  receiveRow.add(new JLabel("Receive data "));

  this.mChoiceRecevieDisplay = new JComboBox<>();
  this.mChoiceRecevieDisplay.addItem("Text (UTF-8):");
  this.mChoiceRecevieDisplay.addItem("Hex (00 to ff) for E.g 01,aa");
  this.mChoiceRecevieDisplay.addItem("Decimal (0 to 255) E.g: 1,122,255");
  this.mChoiceRecevieDisplay.addItemListener(e -> {
   if (e.getStateChange() == ItemEvent.SELECTED) {
    String data = "Receive: " + Transceiver.this.mChoiceRecevieDisplay.getItemAt(Transceiver.this.mChoiceRecevieDisplay.getSelectedIndex());
    Transceiver.this.labelMessage.setText(data);
    Transceiver.this.recevieText.setText("");
    Transceiver.this.TreadStop();
    Transceiver.this.TreadStart();
   }
  });
  receiveRow.add(this.mChoiceRecevieDisplay);

  JButton buttonClear = new JButton("Clear");
  buttonClear.addActionListener(e -> {
   Transceiver.this.labelMessage.setText("Clear");
   Transceiver.this.recevieText.setText("");
   Transceiver.this.logText.setText("");
  });
  receiveRow.add(buttonClear);
  rightPanel.add(receiveRow);

  this.recevieText = new JTextArea(6, 40);
  this.recevieText.setText("Data can be spread to the Internet, Dashboard etc.,see \"Preferences\".");
  JScrollPane receiveScroll = new JScrollPane(this.recevieText);
  rightPanel.add(receiveScroll);

  outerPanel.add(rightPanel, BorderLayout.CENTER);

  return outerPanel;
 }

 public String FunHTTPPost(String urlString, String data) {
  StringBuilder sb = new StringBuilder();
  try {
   URI url = new URI(urlString);
   HttpURLConnection con = (HttpURLConnection)url.toURL().openConnection();
   con.setRequestMethod("POST");
   con.setDoOutput(true);
   con.getOutputStream().write(data.getBytes(StandardCharsets.UTF_8));
   con.getInputStream();
   int HttpResult = con.getResponseCode();
   if (HttpResult == 200) {
    BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
    String line = null;
    while((line = br.readLine()) != null) {
     sb.append(line).append("\n");
    }
    br.close();
    return sb.toString();
   }
  } catch (ProtocolException e) {
   appendLog("Protocol Error: " + e.getMessage());
  } catch (UnsupportedEncodingException e) {
   appendLog("Encoding Error: " + e.getMessage());
  } catch (IOException | URISyntaxException e) {
   appendLog("IO Error: " + e.getMessage());
  }
  return "";
 }

 private String FunRandomString(int len) {
  StringBuilder sb = new StringBuilder(len);
  for(int i = 0; i < len; ++i) {
   sb.append("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".length())));
  }
  return sb.toString();
 }

 public String FunHTTP(String urlString) {
  String data = "";
  try {
   URI uri = new URI(urlString);
   try {

    URLConnection conn = uri.toURL().openConnection();
    InputStream is = conn.getInputStream();
    BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
    StringBuilder sb = new StringBuilder();

    String line = "";
    while((line = br.readLine()) != null) {
     sb.append(line);
    }
    data = sb.toString();
   } catch (IOException e) {
    appendLog("HTTP Request IO Error: " + e.getMessage());
   }
  } catch (URISyntaxException e) {
   appendLog("Malformed URL Error: " + e.getMessage());
  }
  return data;
 }

 public String data_app_dashboard_01_login(String mDeviceID) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxPerson.php?action=login", "email=" + mDeviceID + "&password=" + mDeviceID);
   appendLog("Dashboard Login URL Check: " + t1);
   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }
    if ("OK".equals(result) && "1".equals(totalRecordCount)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("PersonId") ? obj3.get("PersonId").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
   }
  }
  return "";
 }

 public String data_app_dashboard_02_CreateAccount(String mDeviceID) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxPerson.php?action=create&groupid=0&level=0&FBID=0", "Name=" + mDeviceID + "&email=" + mDeviceID + "&password=" + mDeviceID + "&BirthDate=&idNumber=&Phone=&EmergencyPhone=&EmergencyPeople=&deviceID=&Memo=");
   appendLog("Dashboard Create URL Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";

    if ("OK".equals(result)) {
     JsonObject obj3 = obj2.getAsJsonObject("Record");
     if (obj3 != null && obj3.has("PersonId")) {
      return obj3.get("PersonId").getAsString();
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    appendLog("JSON parsing error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_03_ListProject(String mDeviceID, String PersonalId) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTProjects.php?action=selectPersonalId&IoT=1", "PersonalId=" + PersonalId);
   appendLog("List Project URL Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }

    if ("OK".equals(result)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("id") ? obj3.get("id").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    appendLog("JSON parsing error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_04_CreateProject(String mDeviceID, String PersonalId) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTProjects.php?action=create&IoT=1", "projectName=" + mDeviceID + "&imagefilename2=&description=" + mDeviceID + "&instructions=" + mDeviceID + "&PersonalId=" + PersonalId + "&shared=1&block=&device=");
   appendLog("Create Project URL Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    if ("OK".equals(result) && "0".equals(totalRecordCount)) {
     return "0";
    }

    if ("OK".equals(result) && "1".equals(totalRecordCount)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("PersonId") ? obj3.get("PersonId").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    appendLog("JSON parsing error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_05_ListIoTWidgets(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTWidgets.php?action=List", "IoTProjectsId=" + IoTProjectsId);
   appendLog("List IoT Widgets Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";

    if ("OK".equals(result) && obj2.has("maxid")) {
     return obj2.get("maxid").getAsString();
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    appendLog("JSON parsing error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_06_CreateIoTWidgets(String mDeviceID, String PersonId, String IoTProjectsId, String maxid, String APIKEY, String iData, String iDatatype) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTWidgets.php?action=create&IoT=1", "Data=" + iData + "&OwnerId=" + PersonId + "&Datatype=" + iDatatype + "&IoTProjectsId=" + IoTProjectsId + "&IoTWidgetID=" + maxid + "&title=appLoRa&APIKEY=" + APIKEY);
   appendLog("Create IoT Widgets Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";

    if ("OK".equals(result)) {
     JsonArray array = obj2.getAsJsonArray("Records");
     if (array != null && !array.isEmpty()) {
      JsonObject obj3 = array.get(0).getAsJsonObject();
      return obj3.has("id") ? obj3.get("id").getAsString() : "";
     }
    }
   } catch (JsonSyntaxException | IllegalStateException e) {
    appendLog("JSON parsing error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_07_ListIoTWidgetsDB(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTWidgets.php?action=ListDB", "IoTProjectsId=" + IoTProjectsId + "&Datatype='database'");
   appendLog("List IoT Widgets DB Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCountStr = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "0";

    if ("OK".equals(result)) {
     if (!totalRecordCountStr.isEmpty()) {
      int tintTotalRecordCount = Integer.parseInt(totalRecordCountStr);
      if (tintTotalRecordCount == 0) {
       return "";
      }
      JsonArray array = obj2.getAsJsonArray("Records");
      if (array != null && !array.isEmpty()) {
       JsonObject obj3 = array.get(0).getAsJsonObject();
       return obj3.get("id").getAsString();
      }
     }
    }
   } catch (JsonSyntaxException | IllegalStateException | NumberFormatException e) {
    appendLog("JSON/Parse Error: " + e.getMessage());
   }
  }
  return "";
 }

 public String data_app_dashboard_08_GetAPIKEY(String mDeviceID, String PersonalId, String IoTProjectsId) {
  if (!mDeviceID.isEmpty()) {
   String t1 = this.FunHTTPPost(this.mDomainName + "AjaxIoTWidgets.php?action=ListDB", "IoTProjectsId=" + IoTProjectsId + "&Datatype='database'");
   appendLog("Get APIKEY Check: " + t1);

   try {
    JsonObject obj2 = JsonParser.parseString(t1).getAsJsonObject();
    String result = obj2.has("Result") ? obj2.get("Result").getAsString() : "";
    String totalRecordCount = obj2.has("TotalRecordCount") ? obj2.get("TotalRecordCount").getAsString() : "";

    if ("OK".equals(result)) {
     if (!totalRecordCount.isEmpty()) {
      int tintTotalRecordCount = Integer.parseInt(totalRecordCount);
      if (tintTotalRecordCount == 0) {
       return "";
      }
      JsonArray array = obj2.getAsJsonArray("Records");
      if (array != null && !array.isEmpty()) {
       JsonObject obj3 = array.get(0).getAsJsonObject();
       return obj3.has("APIKEY") ? obj3.get("APIKEY").getAsString() : "";
      }
     }
    }
   } catch (JsonSyntaxException | IllegalStateException | NumberFormatException e) {
    appendLog("JSON/Parse Error: " + e.getMessage());
   }
  }
  return "";
 }

 public void data_app_dashboard() {
  if (this.mDeviceID.isEmpty()) {
   this.mDeviceID = "010000D5";
  }
  appendLog("Initializing Dashboard sync with Device ID: " + this.mDeviceID);

  this.PersonId = this.data_app_dashboard_01_login(this.mDeviceID);
  if (!this.PersonId.isEmpty()) {
   if (this.PersonId.equals("0")) {
    this.PersonId = this.data_app_dashboard_02_CreateAccount(this.mDeviceID);
    if (this.PersonId.isEmpty()) {
     return;
    }
   }

   if (!this.PersonId.equals("0")) {
    this.ProjectId = this.data_app_dashboard_03_ListProject(this.mDeviceID, this.PersonId);
    if (this.ProjectId.equals("0")) {
     this.ProjectId = this.data_app_dashboard_04_CreateProject(this.mDeviceID, this.PersonId);
    }

    String IoTWidgetsId = this.data_app_dashboard_07_ListIoTWidgetsDB(this.mDeviceID, this.PersonId, this.ProjectId);
    if (IoTWidgetsId.isEmpty()) {
     String maxid = this.data_app_dashboard_05_ListIoTWidgets(this.mDeviceID, this.PersonId, this.ProjectId);
     int intmaxid = Integer.parseInt(maxid);
     maxid = Integer.toString(intmaxid + 1);
     String date = (new SimpleDateFormat("yyyMMddHH")).format(new Date());
     this.APIKEY = date + this.FunRandomString(5);
     this.APIKEY = this.ProjectId + "-" + this.mDeviceID;
     IoTWidgetsId = this.data_app_dashboard_06_CreateIoTWidgets(this.mDeviceID, this.PersonId, this.ProjectId, maxid, this.APIKEY, this.APIKEY, "database");
     appendLog("Created new IoT Widget ID: " + IoTWidgetsId);
    }

    this.APIKEY = this.data_app_dashboard_08_GetAPIKEY(this.mDeviceID, this.PersonId, this.ProjectId);
    this.savePreference("APIKEY", this.APIKEY);
    this.savePreference("ProjectId", this.ProjectId);
    this.savePreference("mDeviceID", this.mDeviceID);
   }
  }
 }

 private void showMenu() {
  final JMenuBar menuBar = new JMenuBar();
  JMenu fileMenu = new JMenu("File");
  JMenu editMenu = new JMenu("Edit");

  JMenuItem newMenuItem = new JMenuItem("New");
  newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
  newMenuItem.setActionCommand("New");

  JMenuItem openMenuItem = new JMenuItem("Open");
  openMenuItem.setActionCommand("Open");
  JMenuItem saveMenuItem = new JMenuItem("Save");
  saveMenuItem.setActionCommand("Save");
  JMenuItem exitMenuItem = new JMenuItem("Exit");
  exitMenuItem.setActionCommand("Exit");
  JMenuItem cutMenuItem = new JMenuItem("Cut");
  cutMenuItem.setActionCommand("Cut");
  JMenuItem copyMenuItem = new JMenuItem("Copy");
  copyMenuItem.setActionCommand("Copy");
  JMenuItem pasteMenuItem = new JMenuItem("Paste");
  pasteMenuItem.setActionCommand("Paste");

  MenuItemListener menuItemListener = new MenuItemListener();
  newMenuItem.addActionListener(menuItemListener);
  openMenuItem.addActionListener(menuItemListener);
  saveMenuItem.addActionListener(menuItemListener);
  exitMenuItem.addActionListener(menuItemListener);
  cutMenuItem.addActionListener(menuItemListener);
  copyMenuItem.addActionListener(menuItemListener);
  pasteMenuItem.addActionListener(menuItemListener);

  fileMenu.add(newMenuItem);
  fileMenu.add(openMenuItem);
  fileMenu.add(saveMenuItem);
  fileMenu.addSeparator();
  fileMenu.add(exitMenuItem);

  editMenu.add(cutMenuItem);
  editMenu.add(copyMenuItem);
  editMenu.add(pasteMenuItem);

  menuBar.add(fileMenu);
  menuBar.add(editMenu);

  this.mainFrame.setJMenuBar(menuBar);
 }

 private String encodeValue(String value) {
  return URLEncoder.encode(value, StandardCharsets.UTF_8);
 }

 public void TreadStop() {
  this.savePreference("mCounter", Long.toString(this.mCounter));
  if (this.mThreadRecevieText != null) {
   this.mThreadRecevieText.interrupt();
   this.mThreadRecevieText = null;
  }
 }

 public void TreadStart() {
  if (this.mThreadRecevieText != null) {
   this.mThreadRecevieText.interrupt();
   this.mThreadRecevieText = null;
  }

  this.mThreadRecevieText = new ThreadRecevieText(this.labelMessage, this.recevieText, this.mloralib, this.mChoiceRecevieDisplay, this.transceiverFrameClass);
  this.mThreadRecevieText.start();
 }

 class MenuItemListener implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   Transceiver.this.labelMessage.setText(e.getActionCommand() + " MenuItem clicked.");
   if (Desktop.isDesktopSupported() && e.getActionCommand().equals("about app")) {
    try {
     Desktop.getDesktop().browse(new URI("http://www.app.com/"));
    } catch (IOException | URISyntaxException e1) {
     e1.printStackTrace();
    }
   }
  }
 }

 class ThreadRecevieText extends Thread {
  private Random generator;
  private JTextArea mRrecevieText;
  private LoraUtil threadloralib;
  private byte[] oldData;
  private JComboBox<String> mChoiceRecevieDisplay;
  private int delaytime = 1000;
  private JLabel mlabelMessage;
  private Transceiver mLo;

  public ThreadRecevieText(JLabel ilabelMessage, JTextArea iComRrecevieText, LoraUtil iloralib, JComboBox<String> iChoiceRecevieDisplay, Transceiver imLo) {
   this.mlabelMessage = ilabelMessage;
   this.mRrecevieText = iComRrecevieText;
   this.generator = new Random();
   this.threadloralib = iloralib;
   Transceiver.this.mloralib.ReadMode(Transceiver.this.Freq1, Transceiver.this.Freq2, Transceiver.this.Freq3, Transceiver.this.Power);
   this.mChoiceRecevieDisplay = iChoiceRecevieDisplay;
   this.mLo = imLo;
  }

  public void run() {
   while(!isInterrupted()) {
    long tCounter = Transceiver.this.mloralib.FunLora_7_counter_long();
    if (tCounter != this.mLo.mCounter) {
     this.mLo.appendLog("tCounter=" + Long.toString(tCounter));
     this.mLo.mCounter = tCounter;
     byte[] data = Transceiver.this.mloralib.FunLora_6_readPureData();
     if (data != null) {
      int len3 = data.length;
      data[len3 - 1] = 0;
      Transceiver.this.mloralib.Fun_CRC(data);
      if (data.length > 4 && data[0] == -63 && data[1] == -122) {
       int len = data[2] - 2;
       if (data.length == len + 6 && len > 0) {
        byte[] data2 = new byte[len];

        for(int i2 = 0; i2 < len; ++i2) {
         byte t1 = data[3 + i2];
         data2[i2] = t1;
        }

        String tRecHex = "";

        if (this.mChoiceRecevieDisplay.getSelectedIndex() == 0) {
         tRecHex = new String(data2, StandardCharsets.UTF_8);
        } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 1) {
         tRecHex = LoraUtil.FunBytesToHexString(data2, ',');
        } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 2) {
         tRecHex = LoraUtil.FunBytesToString(data2, ',');
        }

        this.mLo.appendLog("Received <- " + tRecHex);
        Transceiver.this.recevieText.setText(tRecHex + "\n" + Transceiver.this.recevieText.getText());

        if ("true".equals(this.mLo.checkBoxUpload) && Transceiver.this.TextFieldUrl.length() > 5) {
         String data3 = Transceiver.this.FunHTTP(Transceiver.this.TextFieldUrl + tRecHex);
         this.mlabelMessage.setText(data3);
        }

        if (this.mLo.checkBoxDashboard.equals("true")) {
         String thttpURLResult = "";
         if (this.mChoiceRecevieDisplay.getSelectedIndex() == 0) {
          String fw = this.mLo.mDomainName + "AjaxIoTTable.php?action=upload&Key=String&Value=" + Transceiver.this.encodeValue(tRecHex) + "&apikey=" + Transceiver.this.APIKEY;
          thttpURLResult = Transceiver.this.FunHTTP(fw);
         } else if (this.mChoiceRecevieDisplay.getSelectedIndex() == 1 || this.mChoiceRecevieDisplay.getSelectedIndex() == 2) {
          for(int i = 0; i < len; ++i) {
           int t1 = data2[i] & 255;
           String t2 = Integer.toString(t1);
           String thttpURL = this.mLo.mDomainName + "AjaxIoTTable.php?action=upload&Key=byte" + Integer.toString(i) + "&Value=" + t2 + "&apikey=" + Transceiver.this.APIKEY;
           thttpURLResult = Transceiver.this.FunHTTP(thttpURL);
          }
         }
         this.mlabelMessage.setText(thttpURLResult);
        }

        if (this.mLo.checkBoxSaveLog.equals("true")) {
         try {
          if (!this.mLo.StringLogFileName.isEmpty()) {
           String filename = this.mLo.StringLogFileName;
           FileWriter fw = new FileWriter(filename, true);
           fw.write(tRecHex + "\n");
           fw.close();
          }
         } catch (IOException ioe) {
          this.mLo.appendLog("IOException saving log: " + ioe.getMessage());
         }
        }
        this.oldData = data2.clone();
       }
      }
     }
    }

    try {
     sleep((long)this.delaytime);
    } catch (InterruptedException e) {
     break;
    }

    if (this.delaytime < 500) {
     this.delaytime += 2;
    }
   }
  }
 }

 public static class MessageDialog extends JDialog {
  @Serial
  private static final long serialVersionUID = 1L;

  public MessageDialog(JFrame parent, String iMsg, int iWidth, int iHight) {
   super(parent, true);
   this.setLayout(new BorderLayout());

   JPanel panel = new JPanel();
   JButton closeBtn = new JButton("Close");
   closeBtn.addActionListener(e -> dispose());
   panel.add(closeBtn);
   this.add(panel, BorderLayout.SOUTH);

   // Replaced custom Graphics paint with a simple centered Swing JLabel
   JLabel msgLabel = new JLabel(iMsg, SwingConstants.CENTER);
   this.add(msgLabel, BorderLayout.CENTER);

   this.setSize(iWidth, iHight);
   this.setLocationRelativeTo(parent);
   this.addWindowListener(new WindowAdapter() {
    public void windowClosing(WindowEvent windowEvent) {
     MessageDialog.this.dispose();
    }
   });
  }
 }
}
#!/bin/sh

touch /localFeatureB

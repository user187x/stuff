//Exports decompiled pseudo-C for every function in the current program to a single file.
//Used by the ghidra-mcp headless_export tool. First script argument = output path.
//@category MCP
//@keybinding
//@menupath
//@toolbar

import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class ExportDecompiledC extends GhidraScript {
    @Override
    protected void run() throws Exception {
        String[] args = getScriptArgs();
        String out = args.length > 0 ? args[0]
                : currentProgram.getExecutablePath() + ".c";

        DecompInterface decomp = new DecompInterface();
        decomp.openProgram(currentProgram);

        int ok = 0, fail = 0;
        try (BufferedWriter w = new BufferedWriter(new FileWriter(out))) {
            w.write("// Decompiled by ghidra-mcp: " + currentProgram.getName() + "\n");
            w.write("// Language: " + currentProgram.getLanguageID() + "\n\n");
            for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
                if (monitor.isCancelled()) break;
                if (f.isThunk()) continue;
                DecompileResults res = decomp.decompileFunction(f, 60, monitor);
                if (res != null && res.decompileCompleted()) {
                    w.write("// " + f.getEntryPoint() + "  " + f.getSignature().getPrototypeString() + "\n");
                    w.write(res.getDecompiledFunction().getC());
                    w.write("\n\n");
                    ok++;
                } else {
                    w.write("// FAILED to decompile " + f.getName() + " @ " + f.getEntryPoint() + "\n\n");
                    fail++;
                }
            }
        } finally {
            decomp.dispose();
        }
        println("[ExportDecompiledC] wrote " + out + " (" + ok + " functions, " + fail + " failures)");
    }
}

package xxx;

import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LoraUtil {
 public int m_BaudRate = 115200;
 boolean debug = true;
 public SerialPort comPort;
 public SerialPort[] mSerialPort;
 private ArrayList<SerialPort> mLoRaSerialPort = new ArrayList<>();
 public ArrayList<String> mLoRaSerialPortString = new ArrayList<>();
 public static String OS = null;
 private String mSerialPortDescriptivePortName;
 public byte m_TXRX;
 public byte m_Freq1;
 public byte m_Freq2;
 public byte m_Freq3;
 public byte m_Power;
 public int m_c1orc2 = 193;
 public loraDevice mCurrentLoRa;
 private static final char[] hexArray = "0123456789ABCDEF".toCharArray();

 public LoraUtil(int i_BaudRate, int i_c1orc2) {
  if (OS == null) {
   OS = System.getProperty("os.name");
  }

  this.mCurrentLoRa = new loraDevice();
  this.m_c1orc2 = i_c1orc2;
  this.m_BaudRate = i_BaudRate;
 }

 public boolean CheckPIDVID(SerialPort iSerialPort) {
  OS.startsWith("Windows");
  return true;
 }

 public ArrayList<String> serial_allPorts() {
  this.mLoRaSerialPort.clear();
  this.mLoRaSerialPortString.clear();
  this.mSerialPort = SerialPort.getCommPorts();

  for(int length = this.mSerialPort.length; length > 0; --length) {
   System.out.println("SerialPort: " + this.mSerialPort[length - 1].getDescriptivePortName() + ",PATH:" + this.mSerialPort[length - 1].getSystemPortName());
   System.out.println("  ");
   if (OS.startsWith("Mac")) {
    if (this.CheckPIDVID(this.mSerialPort[length - 1])) {
     this.mLoRaSerialPort.add(0, this.mSerialPort[length - 1]);
     this.mLoRaSerialPortString.add(0, this.mSerialPort[length - 1].getSystemPortName());
    }
   } else if (OS.startsWith("Linux")) {
    if (this.CheckPIDVID(this.mSerialPort[length - 1])) {
     this.mLoRaSerialPort.add(0, this.mSerialPort[length - 1]);
     this.mLoRaSerialPortString.add(0, this.mSerialPort[length - 1].getSystemPortName());
    }
   } else if (OS.startsWith("Windows") && this.CheckPIDVID(this.mSerialPort[length - 1])) {
    this.mLoRaSerialPort.add(0, this.mSerialPort[length - 1]);
    this.mLoRaSerialPortString.add(0, this.mSerialPort[length - 1].getSystemPortName());
   }
  }

  return this.mLoRaSerialPortString;
 }

 public void SerialPort_setSerialPort(String iSerialPortDescriptivePortName) {
  this.mSerialPortDescriptivePortName = iSerialPortDescriptivePortName;
 }

 public void ReadMode(byte Freq1, byte Freq2, byte Freq3, byte Power) {
  this.m_TXRX = 3;
  this.Setup(this.m_TXRX, Freq1, Freq2, Freq3, Power);
 }

 public void WriteMode(byte Freq1, byte Freq2, byte Freq3, byte Power) {
  this.m_TXRX = 2;
  this.Setup(this.m_TXRX, Freq1, Freq2, Freq3, Power);
 }

 public byte[] write(byte[] array1) {
  return this.writeCheckLength(array1, 0);
 }

 public byte[] writeCheckLength(byte[] array1, int iLen) {
  if (this.debug) {
   System.out.println("----------------");
  }

  ArrayList<Byte> readBuffer = new ArrayList<>();

  try {
   if (this.comPort != null && this.comPort.isOpen()) {
    if (this.debug) {
     System.out.println("COM Port->" + FunBytesToHex(array1));
    }

    int tLen1 = array1.length;
    this.comPort.writeBytes(array1, (int) array1.length);

    try {
     int i = 0;

     for(int totalnum = 0; i < 20; ++i) {
      int lenComPort = this.comPort.bytesAvailable();
      if (lenComPort <= 0) {
       TimeUnit.MILLISECONDS.sleep(1L);
      } else {
       byte[] readBuffer2 = new byte[lenComPort];
       int numRead2 = this.comPort.readBytes(readBuffer2, readBuffer2.length);
       totalnum += numRead2;
       System.out.println("Read " + numRead2 + " bytes.");

       for(int j = 0; j < readBuffer2.length; ++j) {
        readBuffer.add(readBuffer2[j]);
       }

       if (iLen != 0 && totalnum >= iLen) {
        break;
       }
      }
     }
    } catch (Exception e) {
     e.printStackTrace();
    }
   }
  } catch (Exception e1) {
   e1.printStackTrace();
  }

  if (readBuffer.size() == 0) {
   return null;
  } else {
   byte[] newData = FunToByteArray(readBuffer);
   if (this.debug) {
    System.out.println("COM Port<-" + FunBytesToHex(newData));
   }

   return newData;
  }
 }

 public byte[] reset() {
  byte CRC = 0;
  byte tc1 = (byte)this.m_c1orc2;
  byte[] t1 = new byte[]{-63, 1, 0, CRC};
  CRC = this.Fun_CRC2(t1, 3);
  t1[3] = CRC;
  byte[] data2 = this.write(t1);
  return data2;
 }

 public byte[] readSetting() {
  byte CRC = 0;
  byte tc1 = (byte)this.m_c1orc2;
  byte[] t1 = new byte[]{-63, 2, 0, CRC};
  CRC = this.Fun_CRC2(t1, 3);
  t1[3] = CRC;
  byte[] data2 = this.write(t1);
  return data2;
 }

 public byte[] Setup(byte TXRX, byte Freq1, byte Freq2, byte Freq3, byte Power) {
  this.reset();
  this.readSetting();
  this.m_TXRX = TXRX;
  this.m_Freq1 = Freq1;
  this.m_Freq2 = Freq2;
  this.m_Freq3 = Freq3;
  this.m_Power = Power;
  byte CRC = 0;
  byte tc1 = (byte)this.m_c1orc2;
  byte[] t1 = new byte[]{(byte)this.m_c1orc2, 3, 5, TXRX, Freq1, Freq2, Freq3, Power, CRC};
  CRC = this.Fun_CRC2(t1, 8);
  t1[8] = CRC;
  byte[] data2 = this.write(t1);
  return data2;
 }

 public byte[] FunLora_ChipSendByte(byte[] array1) {
  byte[] data2 = this.write(array1);
  return data2;
 }

 public byte[] FunLora_ChipSendByteCheckLength(byte[] array1, int iLen) {
  byte[] data2 = this.writeCheckLength(array1, iLen);
  return data2;
 }

 public int GetChipID() {
  byte[] tDeviceData = this.GetChipIDAll();
  return tDeviceData.length > 9 && tDeviceData[0] == -128 && tDeviceData[1] == -128 ? tDeviceData[3] : 0;
 }

 public int GetFirmwareVersion() {
  byte[] tDeviceData = this.GetChipIDAll();
  return tDeviceData.length > 9 && tDeviceData[0] == -128 && tDeviceData[1] == -128 ? tDeviceData[4] : 0;
 }

 public String GetDeviceID() {
  byte[] tDeviceData = this.GetChipIDAll();
  if (tDeviceData.length >= 7 && tDeviceData[0] == -128 && tDeviceData[1] == -128) {
   this.mCurrentLoRa.id[0] = tDeviceData[5];
   this.mCurrentLoRa.id[1] = tDeviceData[6];
   if (this.m_c1orc2 == 193) {
    this.mCurrentLoRa.id[2] = tDeviceData[7];
    this.mCurrentLoRa.id[3] = tDeviceData[8];
   }

   return FunBytesToHex(this.mCurrentLoRa.id);
  } else {
   return "";
  }
 }

 public byte Fun_CRC2(byte[] data, int CRCIndex) {
  byte crc = 0;

  for(int i = 0; i < CRCIndex; ++i) {
   byte t1 = data[i];
   crc ^= t1;
  }

  return crc;
 }

 public byte Fun_CRC(byte[] data) {
  return this.Fun_CRC2(data, data.length);
 }

 public byte[] FunLora_Serial(byte[] array1, int CRCNum, int ResultLen) {
  ArrayList<Byte> readBuffer = new ArrayList();

  try {
   if (this.comPort != null) {
    this.comPort.closePort();
   }

   if (this.comPort == null || !this.comPort.isOpen()) {
    this.comPort = SerialPort.getCommPort(this.mSerialPortDescriptivePortName);
    this.comPort.setBaudRate(this.m_BaudRate);
    this.comPort.openPort();
    this.comPort.setComPortTimeouts(0, 0, 0);
   }

   int t1 = array1.length;
   array1[t1 - 1] = this.Fun_CRC(array1);
   if (this.debug) {
    System.out.println(FunBytesToHex(array1));
   }

   this.comPort.writeBytes(array1, (int) array1.length);
   TimeUnit.MILLISECONDS.sleep(20L);
   if (this.m_c1orc2 == 194) {
    TimeUnit.MILLISECONDS.sleep(10L);
   }

   try {
    int i = 0;

    for(int totalnum = 0; i < 5; ++i) {
     if (this.comPort.bytesAvailable() <= 0) {
      TimeUnit.MILLISECONDS.sleep(1L);
     } else {
      byte[] readBuffer2 = new byte[this.comPort.bytesAvailable()];
      int numRead2 = this.comPort.readBytes(readBuffer2, (int) readBuffer2.length);
      totalnum += numRead2;
      System.out.println("Read " + numRead2 + " bytes.");

      for(int j = 0; j < readBuffer2.length; ++j) {
       readBuffer.add(readBuffer2[j]);
      }

      if (totalnum >= ResultLen) {
       break;
      }
     }
    }
   } catch (Exception e) {
    e.printStackTrace();
   }
  } catch (Exception e1) {
   e1.printStackTrace();
  }

  byte[] newData = FunToByteArray(readBuffer);
  return newData;
 }

 public byte[] GetChipIDAll() {
  byte[] array1 = new byte[]{-128, 0, 0, 0};
  byte[] newData = this.FunLora_Serial(array1, 3, 10);
  System.out.println(FunBytesToHex(newData));
  return newData;
 }

 public byte[] FunLora_5_write16bytesArray(byte[] data_array, int iLen) {
  int len = 3 + data_array.length + 1;
  byte[] CMD_Data = new byte[len];
  CMD_Data[0] = (byte)this.m_c1orc2;
  CMD_Data[1] = 5;
  CMD_Data[2] = (byte)data_array.length;

  for(int i = 0; i < data_array.length; ++i) {
   CMD_Data[3 + i] = data_array[i];
  }

  CMD_Data[len - 1] = 0;
  CMD_Data[len - 1] = this.Fun_CRC(CMD_Data);
  byte[] data2 = this.write(CMD_Data);
  return data2;
 }

 public byte[] FunLora_6_readPureData() {
  int len = 4;
  byte[] CMD_Data = new byte[len];
  CMD_Data[0] = (byte)this.m_c1orc2;
  CMD_Data[1] = 6;
  CMD_Data[2] = 0;
  CMD_Data[len - 1] = this.Fun_CRC(CMD_Data);
  byte[] data2 = this.FunLora_ChipSendByte(CMD_Data);
  return data2;
 }

 public long FunLora_7_counter_long() {
  long tCounter = 0L;
  int len = 4;
  byte[] CMD_Data = new byte[len];
  CMD_Data[0] = (byte)this.m_c1orc2;
  CMD_Data[1] = 7;
  CMD_Data[2] = 0;
  CMD_Data[len - 1] = this.Fun_CRC(CMD_Data);
  byte[] data2 = this.FunLora_ChipSendByteCheckLength(CMD_Data, 6);
  if (data2 != null && data2.length >= 6 && data2[0] == -63 && data2[1] == -121) {
   tCounter = (long)((byte)(data2[3] * 255) + data2[4]);
   System.out.println("       Read  Counter: " + tCounter);
  }

  return tCounter;
 }

 public byte[] FunLora_7_counter() {
  int len = 4;
  byte[] CMD_Data = new byte[len];
  CMD_Data[0] = (byte)this.m_c1orc2;
  CMD_Data[1] = 7;
  CMD_Data[2] = 0;
  CMD_Data[len - 1] = this.Fun_CRC(CMD_Data);
  byte[] data2 = this.FunLora_ChipSendByte(CMD_Data);
  return data2;
 }

 public void FunLora_initByName(String iSerialPortDescriptivePortName) {
  try {
   if (this.comPort != null) {
    this.comPort.closePort();
   }

   this.comPort = SerialPort.getCommPort(iSerialPortDescriptivePortName);
   this.comPort.setBaudRate(this.m_BaudRate);
   this.comPort.openPort();
   this.comPort.setComPortTimeouts(256, 0, 0);
   byte[] array1 = new byte[]{-128, 0, 0, 0};
   array1[3] = this.Fun_CRC(array1);
   if (this.debug) {
    System.out.println(FunBytesToHex(array1));
   }

   this.comPort.writeBytes(array1, (int) array1.length);
   TimeUnit.MILLISECONDS.sleep(7L);

   try {
    this.comPort.addDataListener(new SerialPortDataListener() {
     public int getListeningEvents() {
      return 1;
     }

     public void serialEvent(SerialPortEvent event) {
      if (event.getEventType() == 1) {
       byte[] newData = new byte[LoraUtil.this.comPort.bytesAvailable()];
       int numRead = LoraUtil.this.comPort.readBytes(newData, (int) newData.length);
       System.out.print("Read " + numRead + " bytes.");
       System.out.println(LoraUtil.FunBytesToHex(newData));
      }
     }
    });
   } catch (Exception e) {
    e.printStackTrace();
    this.comPort.closePort();
   }
  } catch (Exception e1) {
   e1.printStackTrace();
  }

 }

 public void FunLora_close() {
  try {
   if (this.comPort != null) {
    this.comPort.closePort();
   }

   this.comPort = null;
  } catch (Exception e1) {
   e1.printStackTrace();
  }

 }

 public static String FunBytesToHex(byte[] bytes, char iSplit) {
  int hasSplit = 2;
  if (iSplit != '$') {
   hasSplit = 3;
  }

  char[] hexChars = new char[bytes.length * hasSplit];

  for(int j = 0; j < bytes.length; ++j) {
   int v = bytes[j] & 255;
   hexChars[j * hasSplit] = hexArray[v >>> 4];
   hexChars[j * hasSplit + 1] = hexArray[v & 15];
   if (hasSplit == 3) {
    hexChars[j * 3 + 2] = iSplit;
   }
  }

  return new String(hexChars);
 }

 public static String FunBytesToHexString(byte[] bytes, char iSplit) {
  String d1 = "";

  for(int j = 0; j < bytes.length; ++j) {
   int t1 = bytes[j] & 255;
   String t2 = Integer.toHexString(t1);
   if (d1 == "") {
    d1 = t2;
   } else {
    d1 = d1 + "," + t2;
   }
  }

  return d1;
 }

 public static String FunBytesToString(byte[] bytes, char iSplit) {
  String d1 = "";

  for(int j = 0; j < bytes.length; ++j) {
   int t1 = bytes[j] & 255;
   String t2 = Integer.toString(t1);
   if (d1 == "") {
    d1 = t2;
   } else {
    d1 = d1 + "," + t2;
   }
  }

  return d1;
 }

 public static String FunBytesToHex(byte[] bytes) {
  return FunBytesToHex(bytes, '$');
 }

 public static String FunByteToHex(byte ibyte) {
  byte[] bytes = new byte[]{ibyte};
  return FunBytesToHex(bytes);
 }

 public static byte[] FunToByteArray(List<Byte> in) {
  int n = in.size();
  byte[] ret = new byte[n];

  for(int i = 0; i < n; ++i) {
   ret[i] = (Byte)in.get(i);
  }

  return ret;
 }

 public class loraDevice {
  public byte[] id = new byte[4];
  public long m_UniqueNumber;
  public byte dataChip;
  public byte dataFW_Ver;
  public String DescriptivePortName;

  public loraDevice() {
  }
 }
}


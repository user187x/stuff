package xxx;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MessageDialog extends Dialog {
 private static final long serialVersionUID = 1L;
 private String mMsg;
 private int mWidth;
 private int mHight;

 public MessageDialog(Frame parent, String iMsg, int iWidth, int iHight) {
  super(parent, true);
  this.mMsg = iMsg;
  this.mWidth = iWidth;
  this.mHight = iHight;
  this.setLayout(new BorderLayout());
  Panel panel = new Panel();
  panel.add(new Button("Close"));
  this.add("South", panel);
  this.setSize(iWidth, iHight);
  this.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent windowEvent) {
    MessageDialog.this.dispose();
   }
  });
 }

 public boolean action(Event evt, Object arg) {
  if (arg.equals("Close")) {
   this.dispose();
   return true;
  } else {
   return false;
  }
 }

 public void paint(Graphics g) {
  g.drawString(this.mMsg, 20, this.mHight / 2);
 }
}


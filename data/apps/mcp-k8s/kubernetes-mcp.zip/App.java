package mcp;

import com.google.gson.*;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.sse.SseClient;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kubernetes MCP server.
 *
 * Transports:
 *   - Streamable HTTP:  POST http://localhost:8080/mcp        (modern clients, stateless JSON responses)
 *   - Legacy SSE:       GET  http://localhost:8080/sse  +  POST /messages?sessionId=...
 *
 * Environment:
 *   MCP_PORT (8080), MCP_READ_ONLY, MCP_ALLOW_SHELL, MCP_KUBECONFIG, MCP_CONTEXT, MCP_MAX_OUTPUT — see Tools.java
 */
public class App {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson compact = new Gson();
    private static final ConcurrentHashMap<String, SseClient> clients = new ConcurrentHashMap<>();
    private static final List<String> SUPPORTED_PROTOCOLS = List.of("2025-06-18", "2025-03-26", "2024-11-05");

    public static void main(String[] args) {
        int port = Integer.parseInt(System.getenv().getOrDefault("MCP_PORT", "8080"));

        Javalin app = Javalin.create(config -> {
            config.router.ignoreTrailingSlashes = true;
            config.http.asyncTimeout = 0L;
            config.http.maxRequestSize = 20L * 1024 * 1024; // large manifests

            // ---- Streamable HTTP transport ----
            config.routes.post("/mcp", ctx -> {
                JsonElement body = JsonParser.parseString(ctx.body());
                if (body.isJsonArray()) { // batch
                    JsonArray responses = new JsonArray();
                    for (JsonElement e : body.getAsJsonArray()) {
                        JsonObject r = dispatch(e.getAsJsonObject(), "http");
                        if (r != null) responses.add(r);
                    }
                    if (responses.size() == 0) { ctx.status(202); return; }
                    ctx.contentType("application/json").result(compact.toJson(responses));
                    return;
                }
                JsonObject response = dispatch(body.getAsJsonObject(), "http");
                if (response == null) { ctx.status(202); return; }
                ctx.contentType("application/json").result(compact.toJson(response));
            });
            config.routes.get("/mcp", ctx -> ctx.status(405).result("Use POST for Streamable HTTP, or GET /sse for the SSE transport."));
            config.routes.delete("/mcp", ctx -> ctx.status(200));

            // ---- Legacy SSE transport ----
            config.routes.sse("/sse", client -> {
                String sessionId = UUID.randomUUID().toString();
                clients.put(sessionId, client);
                client.keepAlive();
                System.out.println("\n[🌐 SSE] client connected, session " + sessionId);
                client.sendEvent("endpoint", "/messages?sessionId=" + sessionId);
                client.onClose(() -> {
                    clients.remove(sessionId);
                    System.out.println("\n[❌ SSE] client disconnected, session " + sessionId);
                });
            });

            config.routes.post("/messages", ctx -> {
                String sessionId = ctx.queryParam("sessionId");
                SseClient client = sessionId == null ? null : clients.get(sessionId);
                if (client == null) { ctx.status(404).result("Session not found"); return; }
                JsonObject request = JsonParser.parseString(ctx.body()).getAsJsonObject();
                JsonObject response = dispatch(request, "sse:" + sessionId);
                if (response != null) client.sendEvent("message", compact.toJson(response));
                ctx.status(202).result("Accepted");
            });

            config.routes.get("/health", ctx -> ctx.result("ok"));
        }).start(port);

        System.out.println("=================================================");
        System.out.println("Kubernetes MCP Server started on port " + port);
        System.out.println("  Streamable HTTP: http://localhost:" + port + "/mcp");
        System.out.println("  SSE (legacy):    http://localhost:" + port + "/sse");
        System.out.println("  Mode: " + ("true".equalsIgnoreCase(System.getenv("MCP_READ_ONLY")) ? "READ-ONLY" : "READ-WRITE")
                + " | shell: " + ("true".equalsIgnoreCase(System.getenv("MCP_ALLOW_SHELL")) ? "enabled" : "disabled"));
        System.out.println("  Tools: " + Tools.listTools().getAsJsonArray("tools").size());
        System.out.println("=================================================");
    }

    /** Handles one JSON-RPC message. Returns null for notifications (no response). */
    private static JsonObject dispatch(JsonObject request, String transport) {
        String method = request.has("method") ? request.get("method").getAsString() : "unknown_method";
        JsonElement id = request.get("id");
        boolean isNotification = id == null || id.isJsonNull();

        System.out.println("\n[📩 " + transport + "] " + method);

        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        if (!isNotification) response.add("id", id);

        try {
            switch (method) {
                case "initialize": {
                    JsonObject params = request.has("params") ? request.getAsJsonObject("params") : new JsonObject();
                    String requested = params.has("protocolVersion") ? params.get("protocolVersion").getAsString() : "2024-11-05";
                    String version = SUPPORTED_PROTOCOLS.contains(requested) ? requested : "2024-11-05";

                    JsonObject result = new JsonObject();
                    result.addProperty("protocolVersion", version);
                    JsonObject capabilities = new JsonObject();
                    capabilities.add("tools", new JsonObject());
                    capabilities.add("prompts", new JsonObject());
                    result.add("capabilities", capabilities);
                    JsonObject serverInfo = new JsonObject();
                    serverInfo.addProperty("name", "kubernetes-mcp");
                    serverInfo.addProperty("version", "2.0.0");
                    result.add("serverInfo", serverInfo);
                    result.addProperty("instructions",
                        "Kubernetes operations server. Start with cluster_overview, then cluster_health_check to find problems. "
                        + "Diagnose with kubectl_describe / kubectl_logs (previous=true for crashes) / kubectl_get_events. "
                        + "Validate fixes with kubectl_diff or kubectl_apply dry_run=server before applying. "
                        + "kubectl_raw and helm accept arbitrary args for anything not covered by a dedicated tool.");
                    response.add("result", result);
                    break;
                }
                case "notifications/initialized":
                case "notifications/cancelled":
                    return null;
                case "ping":
                    response.add("result", new JsonObject());
                    break;
                case "tools/list":
                    response.add("result", Tools.listTools());
                    break;
                case "tools/call": {
                    JsonObject params = request.getAsJsonObject("params");
                    String toolName = params.get("name").getAsString();
                    JsonObject toolArgs = params.has("arguments") && params.get("arguments").isJsonObject()
                            ? params.getAsJsonObject("arguments") : new JsonObject();
                    System.out.println(" -> 🛠️  " + toolName + " " + gson.toJson(toolArgs));
                    long t0 = System.currentTimeMillis();
                    JsonObject toolResult = Tools.execute(toolName, toolArgs);
                    System.out.println(" -> " + (toolResult.get("isError").getAsBoolean() ? "⚠️  error" : "✅ ok")
                            + " in " + (System.currentTimeMillis() - t0) + "ms");
                    response.add("result", toolResult);
                    break;
                }
                case "prompts/list":
                    response.add("result", Prompts.list());
                    break;
                case "prompts/get":
                    response.add("result", Prompts.get(request.getAsJsonObject("params")));
                    break;
                case "resources/list": {
                    JsonObject r = new JsonObject(); r.add("resources", new JsonArray());
                    response.add("result", r);
                    break;
                }
                default: {
                    if (isNotification) return null;
                    JsonObject error = new JsonObject();
                    error.addProperty("code", -32601);
                    error.addProperty("message", "Method not found: " + method);
                    response.add("error", error);
                }
            }
        } catch (Exception e) {
            System.out.println(" -> ❌ " + e);
            if (isNotification) return null;
            JsonObject error = new JsonObject();
            error.addProperty("code", -32000);
            error.addProperty("message", e.getClass().getSimpleName() + ": " + e.getMessage());
            response.add("error", error);
        }
        return isNotification ? null : response;
    }

    /** Reusable diagnostic playbooks exposed as MCP prompts. */
    static final class Prompts {
        static JsonObject list() {
            JsonArray prompts = new JsonArray();
            prompts.add(prompt("triage_cluster", "Full cluster triage: find and prioritize every problem, then propose fixes.", null));
            prompts.add(prompt("debug_workload", "Root-cause a failing pod/deployment and propose a concrete fix.", "workload", "namespace"));
            prompts.add(prompt("debug_networking", "Diagnose service/ingress connectivity or DNS problems end to end.", "service", "namespace"));
            JsonObject r = new JsonObject(); r.add("prompts", prompts); return r;
        }

        static JsonObject get(JsonObject params) {
            String name = params.get("name").getAsString();
            JsonObject args = params.has("arguments") ? params.getAsJsonObject("arguments") : new JsonObject();
            String w = args.has("workload") ? args.get("workload").getAsString() : "<workload>";
            String s = args.has("service") ? args.get("service").getAsString() : "<service>";
            String n = args.has("namespace") ? args.get("namespace").getAsString() : "default";
            String text = switch (name) {
                case "triage_cluster" -> """
                    Run cluster_overview, then cluster_health_check. For each problem found, use kubectl_describe, kubectl_get_events
                    (warnings_only=true, involved_object=<name>) and kubectl_logs (previous=true for CrashLoopBackOff) to establish root cause.
                    Group findings by severity, explain each root cause in one paragraph, and propose a concrete fix (manifest, patch, or command).
                    Validate any fix with kubectl_diff or kubectl_apply dry_run=server before applying, then confirm with kubectl_rollout status.""";
                case "debug_workload" -> "Debug workload '" + w + "' in namespace '" + n + "'. Steps: kubectl_get with output=yaml; kubectl_describe the "
                    + "deployment and its pods; kubectl_get_events for the namespace; kubectl_logs (all_containers=true, and previous=true if restarting); "
                    + "check image pull, probes, resources/limits vs node capacity (kubectl_top), config/secret mounts, RBAC (kubectl_auth_can_i as_service_account). "
                    + "State the root cause and apply a minimal fix via kubectl_patch or kubectl_apply, then verify with kubectl_rollout status.";
                case "debug_networking" -> "Diagnose connectivity to service '" + s + "' in namespace '" + n + "'. Steps: kubectl_get svc/endpoints/endpointslices "
                    + "(check selector matches pod labels and targetPort matches containerPort); kubectl_get networkpolicies; kubectl_run_pod with image "
                    + "nicolaka/netshoot to test DNS (dig " + s + "." + n + ".svc.cluster.local) and TCP connectivity; service_probe from the host; "
                    + "check ingress/gateway resources and their controller logs. Report the failing hop and fix it.";
                default -> throw new IllegalArgumentException("Unknown prompt: " + name);
            };
            JsonObject msg = new JsonObject();
            msg.addProperty("role", "user");
            JsonObject content = new JsonObject();
            content.addProperty("type", "text");
            content.addProperty("text", text);
            msg.add("content", content);
            JsonArray messages = new JsonArray(); messages.add(msg);
            JsonObject r = new JsonObject(); r.add("messages", messages); return r;
        }

        private static JsonObject prompt(String name, String desc, String... argNames) {
            JsonObject p = new JsonObject();
            p.addProperty("name", name);
            p.addProperty("description", desc);
            if (argNames != null) {
                JsonArray a = new JsonArray();
                for (String an : argNames) {
                    JsonObject o = new JsonObject();
                    o.addProperty("name", an);
                    o.addProperty("required", false);
                    a.add(o);
                }
                p.add("arguments", a);
            }
            return p;
        }
    }
}

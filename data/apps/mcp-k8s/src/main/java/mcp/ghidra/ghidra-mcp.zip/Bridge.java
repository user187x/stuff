package ghidramcp;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.StringJoiner;

/** Thin client to the in-Ghidra McpBridge HTTP server. */
public final class Bridge {

    private static final String BASE = System.getenv().getOrDefault("GHIDRA_BRIDGE_URL", "http://127.0.0.1:8765");
    private static final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5)).build();

    private Bridge() {}

    public record Response(int status, String body, boolean ok) {}

    public static Response get(String path, Map<String, String> params) {
        StringJoiner qs = new StringJoiner("&");
        if (params != null) for (Map.Entry<String, String> e : params.entrySet()) {
            if (e.getValue() == null || e.getValue().isEmpty()) continue;
            qs.add(enc(e.getKey()) + "=" + enc(e.getValue()));
        }
        String url = BASE + path + (qs.length() > 0 ? "?" + qs : "");
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(120)).GET().build();
            HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
            return new Response(resp.statusCode(), resp.body(), resp.statusCode() >= 200 && resp.statusCode() < 300);
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            return new Response(-1,
                "{\"error\":\"Cannot reach Ghidra bridge at " + BASE + " — is Ghidra open with McpBridge.java running? (" + e.getMessage() + ")\"}",
                false);
        }
    }

    public static boolean reachable() {
        return get("/ping", Map.of()).ok();
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}

package ghidramcp;

import com.google.gson.*;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.sse.SseClient;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Kubernetes MCP server.
 *
 * Transports:
 *   - Streamable HTTP:  POST http://localhost:8080/mcp        (modern clients, stateless JSON responses)
 *   - Legacy SSE:       GET  http://localhost:8080/sse  +  POST /messages?sessionId=...
 *
 * Environment:
 *   MCP_PORT (8080), MCP_READ_ONLY, MCP_ALLOW_SHELL, MCP_KUBECONFIG, MCP_CONTEXT, MCP_MAX_OUTPUT — see Tools.java
 */
public class App {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson compact = new Gson();
    private static final ConcurrentHashMap<String, SseClient> clients = new ConcurrentHashMap<>();
    private static final List<String> SUPPORTED_PROTOCOLS = List.of("2025-06-18", "2025-03-26", "2024-11-05");

    public static void main(String[] args) {
        int port = Integer.parseInt(System.getenv().getOrDefault("MCP_PORT", "8080"));

        Javalin app = Javalin.create(config -> {
            config.router.ignoreTrailingSlashes = true;
            config.http.asyncTimeout = 0L;
            config.http.maxRequestSize = 20L * 1024 * 1024; // large manifests

            // ---- Streamable HTTP transport ----
            config.routes.post("/mcp", ctx -> {
                JsonElement body = JsonParser.parseString(ctx.body());
                if (body.isJsonArray()) { // batch
                    JsonArray responses = new JsonArray();
                    for (JsonElement e : body.getAsJsonArray()) {
                        JsonObject r = dispatch(e.getAsJsonObject(), "http");
                        if (r != null) responses.add(r);
                    }
                    if (responses.size() == 0) { ctx.status(202); return; }
                    ctx.contentType("application/json").result(compact.toJson(responses));
                    return;
                }
                JsonObject response = dispatch(body.getAsJsonObject(), "http");
                if (response == null) { ctx.status(202); return; }
                ctx.contentType("application/json").result(compact.toJson(response));
            });
            config.routes.get("/mcp", ctx -> ctx.status(405).result("Use POST for Streamable HTTP, or GET /sse for the SSE transport."));
            config.routes.delete("/mcp", ctx -> ctx.status(200));

            // ---- Legacy SSE transport ----
            config.routes.sse("/sse", client -> {
                String sessionId = UUID.randomUUID().toString();
                clients.put(sessionId, client);
                client.keepAlive();
                System.out.println("\n[🌐 SSE] client connected, session " + sessionId);
                client.sendEvent("endpoint", "/messages?sessionId=" + sessionId);
                client.onClose(() -> {
                    clients.remove(sessionId);
                    System.out.println("\n[❌ SSE] client disconnected, session " + sessionId);
                });
            });

            config.routes.post("/messages", ctx -> {
                String sessionId = ctx.queryParam("sessionId");
                SseClient client = sessionId == null ? null : clients.get(sessionId);
                if (client == null) { ctx.status(404).result("Session not found"); return; }
                JsonObject request = JsonParser.parseString(ctx.body()).getAsJsonObject();
                JsonObject response = dispatch(request, "sse:" + sessionId);
                if (response != null) client.sendEvent("message", compact.toJson(response));
                ctx.status(202).result("Accepted");
            });

            config.routes.get("/health", ctx -> ctx.result("ok"));
        }).start(port);

        System.out.println("=================================================");
        System.out.println("Ghidra MCP Server started on port " + port);
        System.out.println("  Streamable HTTP: http://localhost:" + port + "/mcp");
        System.out.println("  SSE (legacy):    http://localhost:" + port + "/sse");
        System.out.println("  Mode: " + ("true".equalsIgnoreCase(System.getenv("MCP_READ_ONLY")) ? "READ-ONLY" : "READ-WRITE")
                + " | shell: " + ("true".equalsIgnoreCase(System.getenv("MCP_ALLOW_SHELL")) ? "enabled" : "disabled"));
        System.out.println("  Tools: " + Tools.listTools().getAsJsonArray("tools").size());
        System.out.println("=================================================");
    }

    /** Handles one JSON-RPC message. Returns null for notifications (no response). */
    private static JsonObject dispatch(JsonObject request, String transport) {
        String method = request.has("method") ? request.get("method").getAsString() : "unknown_method";
        JsonElement id = request.get("id");
        boolean isNotification = id == null || id.isJsonNull();

        System.out.println("\n[📩 " + transport + "] " + method);

        JsonObject response = new JsonObject();
        response.addProperty("jsonrpc", "2.0");
        if (!isNotification) response.add("id", id);

        try {
            switch (method) {
                case "initialize": {
                    JsonObject params = request.has("params") ? request.getAsJsonObject("params") : new JsonObject();
                    String requested = params.has("protocolVersion") ? params.get("protocolVersion").getAsString() : "2024-11-05";
                    String version = SUPPORTED_PROTOCOLS.contains(requested) ? requested : "2024-11-05";

                    JsonObject result = new JsonObject();
                    result.addProperty("protocolVersion", version);
                    JsonObject capabilities = new JsonObject();
                    capabilities.add("tools", new JsonObject());
                    capabilities.add("prompts", new JsonObject());
                    result.add("capabilities", capabilities);
                    JsonObject serverInfo = new JsonObject();
                    serverInfo.addProperty("name", "ghidra-mcp");
                    serverInfo.addProperty("version", "2.0.0");
                    result.add("serverInfo", serverInfo);
                    result.addProperty("instructions",
                        "Ghidra reverse-engineering server. For an open program, call bridge_status then program_info, list_functions, "
                        + "decompile_function, get_xrefs, list_strings/list_imports. Rename/set_comment/set_prototype persist to the Ghidra database. "
                        + "For files on disk (no GUI), use the headless_* tools (require GHIDRA_HOME): headless_analyze to import+analyze, "
                        + "headless_export format=c to pull all decompiled pseudo-C, headless_run_script for custom passes.");
                    response.add("result", result);
                    break;
                }
                case "notifications/initialized":
                case "notifications/cancelled":
                    return null;
                case "ping":
                    response.add("result", new JsonObject());
                    break;
                case "tools/list":
                    response.add("result", Tools.listTools());
                    break;
                case "tools/call": {
                    JsonObject params = request.getAsJsonObject("params");
                    String toolName = params.get("name").getAsString();
                    JsonObject toolArgs = params.has("arguments") && params.get("arguments").isJsonObject()
                            ? params.getAsJsonObject("arguments") : new JsonObject();
                    System.out.println(" -> 🛠️  " + toolName + " " + gson.toJson(toolArgs));
                    long t0 = System.currentTimeMillis();
                    JsonObject toolResult = Tools.execute(toolName, toolArgs);
                    System.out.println(" -> " + (toolResult.get("isError").getAsBoolean() ? "⚠️  error" : "✅ ok")
                            + " in " + (System.currentTimeMillis() - t0) + "ms");
                    response.add("result", toolResult);
                    break;
                }
                case "prompts/list":
                    response.add("result", Prompts.list());
                    break;
                case "prompts/get":
                    response.add("result", Prompts.get(request.getAsJsonObject("params")));
                    break;
                case "resources/list": {
                    JsonObject r = new JsonObject(); r.add("resources", new JsonArray());
                    response.add("result", r);
                    break;
                }
                default: {
                    if (isNotification) return null;
                    JsonObject error = new JsonObject();
                    error.addProperty("code", -32601);
                    error.addProperty("message", "Method not found: " + method);
                    response.add("error", error);
                }
            }
        } catch (Exception e) {
            System.out.println(" -> ❌ " + e);
            if (isNotification) return null;
            JsonObject error = new JsonObject();
            error.addProperty("code", -32000);
            error.addProperty("message", e.getClass().getSimpleName() + ": " + e.getMessage());
            response.add("error", error);
        }
        return isNotification ? null : response;
    }

    /** Reusable diagnostic playbooks exposed as MCP prompts. */
    static final class Prompts {
        static JsonObject list() {
            JsonArray prompts = new JsonArray();
            prompts.add(prompt("triage_binary", "First-pass survey of an unknown binary: metadata, imports, strings, and entry points, with a plan."));
            prompts.add(prompt("analyze_function", "Deep-dive a single function: decompile, resolve callees/callers, and annotate.", "function"));
            prompts.add(prompt("hunt_capability", "Find where a capability (networking, crypto, file I/O, process injection) lives by imports and strings.", "capability"));
            JsonObject r = new JsonObject(); r.add("prompts", prompts); return r;
        }

        static JsonObject get(JsonObject params) {
            String name = params.get("name").getAsString();
            JsonObject args = params.has("arguments") ? params.getAsJsonObject("arguments") : new JsonObject();
            String fn = args.has("function") ? args.get("function").getAsString() : "<function>";
            String cap = args.has("capability") ? args.get("capability").getAsString() : "<capability>";
            String text = switch (name) {
                case "triage_binary" -> """
                    Survey this binary. Call program_info for architecture/compiler/hashes, list_imports to see what APIs it depends on,
                    list_exports and list_segments, then list_strings (filter for http, key, /, .dll, cmd) to spot config and behaviour hints.
                    From imports+strings, form a hypothesis about what the binary does. list_functions and decompile_function on entry / main
                    (or the largest non-thunk functions). Summarize: likely purpose, notable capabilities, and the 3-5 functions worth reading next.
                    If no program is open (bridge_status fails), run headless_analyze on the file first, or headless_export format=c to pull all pseudo-C.""";
                case "analyze_function" -> "Analyze function '" + fn + "'. decompile_function to get its C; get_xrefs on its entry to see callers; "
                    + "for each callee, decompile or at least read its signature; identify parameters, loops, and any imported API calls (crypto, alloc, network). "
                    + "Explain what it does in plain language, then improve the database: rename it to something descriptive, set_prototype with the recovered "
                    + "signature, and set_comment (plate) with a one-line summary at its entry point.";
                case "hunt_capability" -> "Locate '" + cap + "' behaviour. list_imports and filter mentally for the relevant APIs (e.g. networking: socket/connect/WSAStartup/recv; "
                    + "crypto: Crypt*/EVP_/AES; file I/O: fopen/CreateFile/ReadFile; injection: VirtualAllocEx/WriteProcessMemory/CreateRemoteThread). "
                    + "For each hit, get_xrefs to find the calling functions, decompile_function those, and list_strings for supporting evidence (URLs, key material, paths). "
                    + "Report each site as address + function + what it does.";
                default -> throw new IllegalArgumentException("Unknown prompt: " + name);
            };
            JsonObject msg = new JsonObject();
            msg.addProperty("role", "user");
            JsonObject content = new JsonObject();
            content.addProperty("type", "text");
            content.addProperty("text", text);
            msg.add("content", content);
            JsonArray messages = new JsonArray(); messages.add(msg);
            JsonObject r = new JsonObject(); r.add("messages", messages); return r;
        }

        private static JsonObject prompt(String name, String desc, String... argNames) {
            JsonObject p = new JsonObject();
            p.addProperty("name", name);
            p.addProperty("description", desc);
            if (argNames != null) {
                JsonArray a = new JsonArray();
                for (String an : argNames) {
                    JsonObject o = new JsonObject();
                    o.addProperty("name", an);
                    o.addProperty("required", false);
                    a.add(o);
                }
                p.add("arguments", a);
            }
            return p;
        }
    }
}

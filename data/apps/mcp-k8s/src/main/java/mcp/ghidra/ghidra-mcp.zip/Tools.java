package ghidramcp;

import com.google.gson.*;
import java.io.File;
import java.util.*;

/**
 * Tools for the Ghidra MCP server.
 *
 * Two families:
 *   1. LIVE tools  -> talk to an open Ghidra instance via the McpBridge HTTP API (interactive RE).
 *   2. HEADLESS tools -> drive analyzeHeadless for batch import/analysis/scripting without the GUI.
 *
 * Environment:
 *   GHIDRA_BRIDGE_URL   default http://127.0.0.1:8765  (the in-Ghidra script)
 *   GHIDRA_HOME         install dir containing support/analyzeHeadless (required for headless tools)
 *   GHIDRA_PROJECT_DIR  project directory for headless runs (default: system temp / ghidra_mcp_projects)
 *   MCP_READ_ONLY=true  refuse mutating tools (rename/comment/prototype/headless writes)
 */
public final class Tools {

    private static final boolean READ_ONLY = "true".equalsIgnoreCase(System.getenv("MCP_READ_ONLY"));
    private static final String GHIDRA_HOME = System.getenv("GHIDRA_HOME");
    private static final String PROJECT_DIR = System.getenv().getOrDefault("GHIDRA_PROJECT_DIR",
            System.getProperty("java.io.tmpdir") + File.separator + "ghidra_mcp_projects");

    private record Param(String name, String type, String desc, boolean required, String[] enumVals) {}
    private static Param s(String n, String d)  { return new Param(n, "string", d, false, null); }
    private static Param sr(String n, String d) { return new Param(n, "string", d, true, null); }
    private static Param b(String n, String d)  { return new Param(n, "boolean", d, false, null); }
    private static Param i(String n, String d)  { return new Param(n, "integer", d, false, null); }
    private static Param arr(String n, String d){ return new Param(n, "array", d, false, null); }
    private static Param en(String n, String d, boolean r, String... v) { return new Param(n, "string", d, r, v); }

    private static final List<JsonObject> TOOLS = new ArrayList<>();
    private static final Set<String> MUTATING = new HashSet<>();

    private static void tool(String name, String desc, boolean mutating, Param... params) {
        JsonObject t = new JsonObject();
        t.addProperty("name", name);
        t.addProperty("description", desc);
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonArray required = new JsonArray();
        for (Param p : params) {
            JsonObject pj = new JsonObject();
            pj.addProperty("type", p.type());
            pj.addProperty("description", p.desc());
            if ("array".equals(p.type())) { JsonObject it = new JsonObject(); it.addProperty("type", "string"); pj.add("items", it); }
            if (p.enumVals() != null) { JsonArray e = new JsonArray(); for (String v : p.enumVals()) e.add(v); pj.add("enum", e); }
            props.add(p.name(), pj);
            if (p.required()) required.add(p.name());
        }
        schema.add("properties", props);
        if (required.size() > 0) schema.add("required", required);
        t.add("inputSchema", schema);
        JsonObject ann = new JsonObject();
        ann.addProperty("readOnlyHint", !mutating);
        t.add("annotations", ann);
        TOOLS.add(t);
        if (mutating) MUTATING.add(name);
    }

    static {
        // ---------------- LIVE (open Ghidra program) ----------------
        tool("bridge_status", "Check whether an interactive Ghidra program is reachable via the McpBridge script, and which program is loaded.", false);
        tool("program_info", "Metadata for the open program: language, compiler, image base, pointer size, function count, hashes.", false);

        tool("list_functions", "List functions in the open program with entry, size, and signature. Supports name filter and pagination.",
             false, s("filter", "Case-insensitive substring on function name"), i("limit", "Max rows (default 1000)"), i("offset", "Skip N"));

        tool("decompile_function", "Decompile a function to C. Identify it by name or by any address inside it.",
             false, s("name", "Function name"), s("address", "Any address within the function"), i("timeout", "Decompiler timeout seconds (default 60)"));

        tool("disassemble", "Disassembly listing. Pass a function (name/address) for the whole body, or an address + count for a linear window.",
             false, s("name", "Function name"), s("address", "Start address or address in function"), i("count", "Instruction count for address mode (default 50)"));

        tool("get_xrefs", "Cross-references TO an address or function entry — who calls/references this.",
             false, s("address", "Target address"), s("name", "Function name (uses its entry point)"));

        tool("list_symbols", "Symbol table entries (functions, labels, data) with address and type. Filterable.",
             false, s("filter", "Case-insensitive substring"), i("limit", "Max rows (default 1000)"));

        tool("list_strings", "Defined strings with their addresses. Filter by content and minimum length — great for finding URLs, keys, format strings.",
             false, s("filter", "Case-insensitive substring"), i("min_length", "Minimum length (default 4)"), i("limit", "Max rows (default 2000)"));

        tool("list_imports", "Imported/external symbols (API calls the binary depends on) with owning library.", false);
        tool("list_exports", "Exported symbols / external entry points.", false);
        tool("list_segments", "Memory blocks/segments with range, size, and RWX + initialized flags.", false);

        tool("read_bytes", "Raw bytes at an address as hex (max 4096).",
             false, sr("address", "Address"), i("length", "Byte count (default 64, max 4096)"));

        tool("data_at", "The defined data item at an address (type and value).", false, sr("address", "Address"));

        // mutations
        tool("rename", "Rename a function (by name/address) or the symbol at an address. Persists in the Ghidra database.",
             true, s("name", "Existing function name"), s("address", "Address of function or symbol"), sr("new_name", "New name"));

        tool("set_comment", "Attach a comment at an address (eol/pre/post/plate/repeat).",
             true, sr("address", "Address"), sr("comment", "Comment text (empty clears)"),
             en("type", "Comment type", false, "eol", "pre", "post", "plate", "repeat"));

        tool("set_prototype", "Apply a C function signature/prototype to a function, e.g. 'int process(char *buf, size_t len)'.",
             true, s("name", "Function name"), s("address", "Address in function"), sr("prototype", "C prototype"));

        // ---------------- HEADLESS (batch, no GUI) ----------------
        tool("headless_analyze",
             "Import a binary into a headless Ghidra project and run auto-analysis. Returns the analyzeHeadless log. "
             + "Use for files not open in the GUI. Requires GHIDRA_HOME.",
             true,
             sr("binary_path", "Path to the binary on the MCP host"),
             s("project_name", "Project name (default derived from filename)"),
             b("overwrite", "Overwrite if already imported (default true)"),
             i("timeout_seconds", "Max analysis time (default 600)"));

        tool("headless_run_script",
             "Run a Ghidra script (e.g. a .java/.py GhidraScript) against a binary headlessly, optionally after import+analysis. "
             + "Script stdout is returned. Use for bulk extraction, custom passes, or exporting decompilation.",
             true,
             sr("binary_path", "Binary to load (imported if not already in the project)"),
             sr("script_name", "Script filename available on Ghidra's script path or in script_dir"),
             s("script_dir", "Extra directory to add to the script search path"),
             arr("script_args", "Arguments passed to the script"),
             s("project_name", "Project name"),
             b("analyze", "Run auto-analysis before the script (default true)"),
             i("timeout_seconds", "Timeout (default 600)"));

        tool("headless_export",
             "Export an analyzed program: 'c' (decompiled pseudo-C for all functions via a bundled script), "
             + "or a Ghidra export format ('ascii', 'html', 'xml', 'binary'). Returns a path to the produced file.",
             true,
             sr("binary_path", "Binary to analyze/export"),
             en("format", "Export format", true, "c", "ascii", "html", "xml", "binary"),
             s("project_name", "Project name"),
             s("output_path", "Where to write (default: alongside the binary)"),
             i("timeout_seconds", "Timeout (default 600)"));

        tool("headless_version", "Report the analyzeHeadless / Ghidra version and confirm GHIDRA_HOME is wired up.", false);
    }

    private Tools() {}

    public static JsonObject listTools() {
        JsonObject r = new JsonObject();
        JsonArray a = new JsonArray();
        for (JsonObject t : TOOLS) a.add(t);
        r.add("tools", a);
        return r;
    }

    // ---------- arg helpers ----------
    private static String str(JsonObject a, String k) { return a != null && a.has(k) && !a.get(k).isJsonNull() ? a.get(k).getAsString().trim() : ""; }
    private static boolean has(JsonObject a, String k) { return !str(a, k).isEmpty(); }
    private static boolean bool(JsonObject a, String k, boolean d) { return a != null && a.has(k) && !a.get(k).isJsonNull() ? a.get(k).getAsBoolean() : d; }
    private static int num(JsonObject a, String k, int d) {
        if (a == null || !a.has(k) || a.get(k).isJsonNull()) return d;
        try { return a.get(k).getAsInt(); } catch (Exception e) { try { return Integer.parseInt(a.get(k).getAsString()); } catch (Exception x) { return d; } }
    }
    private static List<String> list(JsonObject a, String k) {
        List<String> out = new ArrayList<>();
        if (a == null || !a.has(k) || a.get(k).isJsonNull()) return out;
        JsonElement e = a.get(k);
        if (e.isJsonArray()) e.getAsJsonArray().forEach(x -> out.add(x.getAsString()));
        else if (!e.getAsString().isBlank()) out.add(e.getAsString());
        return out;
    }
    private static Map<String, String> params(JsonObject a, String... keys) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String k : keys) if (has(a, k)) m.put(k, str(a, k));
        return m;
    }

    // ---------- result helpers ----------
    private static JsonObject text(String s, boolean isError) {
        JsonObject r = new JsonObject();
        JsonArray content = new JsonArray();
        JsonObject tc = new JsonObject();
        tc.addProperty("type", "text");
        tc.addProperty("text", s);
        content.add(tc);
        r.add("content", content);
        r.addProperty("isError", isError);
        return r;
    }

    private static JsonObject fromBridge(Bridge.Response resp) {
        boolean err = !resp.ok() || resp.body().contains("\"error\"");
        String body = resp.body();
        // Pretty-print JSON when possible for readability
        try {
            JsonElement el = JsonParser.parseString(body);
            body = new GsonBuilder().setPrettyPrinting().create().toJson(el);
        } catch (Exception ignored) {}
        return text(body, err);
    }

    // ---------- dispatch ----------
    public static JsonObject execute(String name, JsonObject a) throws Exception {
        if (a == null) a = new JsonObject();
        if (READ_ONLY && MUTATING.contains(name))
            return text("Refused: read-only mode (MCP_READ_ONLY=true). '" + name + "' can modify the program.", true);

        switch (name) {
            case "bridge_status": {
                boolean up = Bridge.reachable();
                return text(up ? fromBridge(Bridge.get("/ping", Map.of())).getAsJsonArray("content").get(0).getAsJsonObject().get("text").getAsString()
                               : "Ghidra bridge not reachable. Open Ghidra with a program and run ghidra_scripts/McpBridge.java, "
                                 + "or use the headless_* tools instead.", !up);
            }
            case "program_info":    return fromBridge(Bridge.get("/program_info", Map.of()));
            case "list_functions":  return fromBridge(Bridge.get("/functions", params(a, "filter", "limit", "offset")));
            case "decompile_function": return fromBridge(Bridge.get("/decompile", params(a, "name", "address", "timeout")));
            case "disassemble":     return fromBridge(Bridge.get("/disassemble", params(a, "name", "address", "count")));
            case "get_xrefs":       return fromBridge(Bridge.get("/xrefs", params(a, "address", "name")));
            case "list_symbols":    return fromBridge(Bridge.get("/symbols", params(a, "filter", "limit")));
            case "list_strings":    return fromBridge(Bridge.get("/strings", params(a, "filter", "min_length", "limit")));
            case "list_imports":    return fromBridge(Bridge.get("/imports", Map.of()));
            case "list_exports":    return fromBridge(Bridge.get("/exports", Map.of()));
            case "list_segments":   return fromBridge(Bridge.get("/segments", Map.of()));
            case "read_bytes":      return fromBridge(Bridge.get("/read_bytes", params(a, "address", "length")));
            case "data_at":         return fromBridge(Bridge.get("/data_at", params(a, "address")));
            case "rename":          return fromBridge(Bridge.get("/rename", params(a, "name", "address", "new_name")));
            case "set_comment":     return fromBridge(Bridge.get("/set_comment", params(a, "address", "comment", "type")));
            case "set_prototype":   return fromBridge(Bridge.get("/set_prototype", params(a, "name", "address", "prototype")));

            case "headless_version":  return headlessVersion();
            case "headless_analyze":  return headlessAnalyze(a);
            case "headless_run_script": return headlessRunScript(a);
            case "headless_export":   return headlessExport(a);
            default: throw new IllegalArgumentException("Unknown tool: " + name);
        }
    }

    // ---------- headless ----------
    private static String headlessBinary() {
        if (GHIDRA_HOME == null || GHIDRA_HOME.isBlank()) return null;
        boolean win = System.getProperty("os.name").toLowerCase().contains("win");
        return GHIDRA_HOME + File.separator + "support" + File.separator + (win ? "analyzeHeadless.bat" : "analyzeHeadless");
    }

    private static JsonObject requireHome() {
        return text("GHIDRA_HOME is not set. Point it at your Ghidra install (the dir containing support/analyzeHeadless) to use headless tools.", true);
    }

    private static String projectName(JsonObject a, File binary) {
        if (has(a, "project_name")) return str(a, "project_name");
        String base = binary.getName().replaceAll("[^A-Za-z0-9._-]", "_");
        return "mcp_" + base;
    }

    private static List<String> baseHeadless(String project) {
        new File(PROJECT_DIR).mkdirs();
        List<String> cmd = new ArrayList<>();
        cmd.add(headlessBinary());
        cmd.add(PROJECT_DIR);
        cmd.add(project);
        return cmd;
    }

    private static JsonObject headlessVersion() {
        if (headlessBinary() == null) return requireHome();
        CommandRunner.Result r = CommandRunner.run(List.of(headlessBinary()), 30);
        // analyzeHeadless with no args prints usage incl. version banner
        return text(r.output(), false);
    }

    private static JsonObject headlessAnalyze(JsonObject a) {
        if (headlessBinary() == null) return requireHome();
        File bin = new File(str(a, "binary_path"));
        if (!bin.isFile()) return text("binary not found: " + bin, true);
        String project = projectName(a, bin);
        List<String> cmd = baseHeadless(project);
        cmd.add("-import"); cmd.add(bin.getAbsolutePath());
        if (bool(a, "overwrite", true)) cmd.add("-overwrite");
        CommandRunner.Result r = CommandRunner.run(cmd, num(a, "timeout_seconds", 600));
        return text(r.output(), r.failed());
    }

    private static JsonObject headlessRunScript(JsonObject a) {
        if (headlessBinary() == null) return requireHome();
        File bin = new File(str(a, "binary_path"));
        if (!bin.isFile()) return text("binary not found: " + bin, true);
        String project = projectName(a, bin);
        List<String> cmd = baseHeadless(project);
        cmd.add("-import"); cmd.add(bin.getAbsolutePath());
        cmd.add("-overwrite");
        if (!bool(a, "analyze", true)) cmd.add("-noanalysis");
        if (has(a, "script_dir")) { cmd.add("-scriptPath"); cmd.add(str(a, "script_dir")); }
        cmd.add("-postScript"); cmd.add(str(a, "script_name"));
        cmd.addAll(list(a, "script_args"));
        CommandRunner.Result r = CommandRunner.run(cmd, num(a, "timeout_seconds", 600));
        return text(r.output(), r.failed());
    }

    private static JsonObject headlessExport(JsonObject a) {
        if (headlessBinary() == null) return requireHome();
        File bin = new File(str(a, "binary_path"));
        if (!bin.isFile()) return text("binary not found: " + bin, true);
        String format = str(a, "format");
        String project = projectName(a, bin);
        String outPath = has(a, "output_path") ? str(a, "output_path")
                : bin.getAbsolutePath() + "." + ("c".equals(format) ? "c" : format);

        List<String> cmd = baseHeadless(project);
        cmd.add("-import"); cmd.add(bin.getAbsolutePath());
        cmd.add("-overwrite");

        if ("c".equals(format)) {
            // Use Ghidra's bundled DecompileHeadless-style export via the built-in "ExportCFunctionsScript"? 
            // Not standard across versions, so ship our own exporter script alongside.
            cmd.add("-scriptPath"); cmd.add(scriptDir());
            cmd.add("-postScript"); cmd.add("ExportDecompiledC.java"); cmd.add(outPath);
        } else {
            String ghidraFormat = switch (format) {
                case "ascii" -> "Ascii"; case "html" -> "Html"; case "xml" -> "XML"; case "binary" -> "Binary"; default -> "Ascii";
            };
            cmd.add("-export"); cmd.add(outPath);
            // -export uses the format inferred from the exporter name flag in newer versions:
            cmd.add("-exporter"); cmd.add(ghidraFormat);
        }
        CommandRunner.Result r = CommandRunner.run(cmd, num(a, "timeout_seconds", 600));
        String note = new File(outPath).isFile() ? "\n\nOutput written to: " + outPath : "\n\n(no output file produced — check the log above)";
        return text(r.output() + note, r.failed());
    }

    /** Directory next to the jar where we drop the bundled exporter script. */
    static String scriptDir() {
        String dir = System.getenv().getOrDefault("GHIDRA_MCP_SCRIPTS",
                new File(System.getProperty("user.dir"), "ghidra_scripts").getAbsolutePath());
        new File(dir).mkdirs();
        return dir;
    }
}

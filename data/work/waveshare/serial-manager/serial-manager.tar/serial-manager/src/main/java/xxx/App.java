package xxx;

import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class App extends Frame {
 private final Var mVar = new Var();
 public UI mUI = new UI();
 public int lan = 0;
 public String[][] mStr = new String[][]{{"Open iFrogLab APP ", "請選取APP"}, {"iFrogLab LoRa App", "LoRa 應用程式"}, {"for iFrogLab LoRa Gateway, LoRa 1272, LoRa Module, Node, ENZO..", "for iFrogLab LoRa Gateway, LoRa 1272, LoRa Module, Node, ENZO.."}, {"Remember to choose, open and execute immediately next time", "記住選擇的APP，下次立即開啟和啟動該APP"}, {"iFrogLab TCP/UDP/UART APP", "TCP/UDP/UART 應用程式"}, {"for iFrogLab TCP/UDP/UART", "for iFrogLab TCP/UDP/UART"}, {"iFrogLab Application", "iFrogLab 應用程式"}, {"Version:", "版本編號:"}};

 public App() {

  FlatDarkLaf.setup();
  this.mVar.transceiverFrameClass = new TransceiverFrame();
  this.mVar.appClass = this;
  this.data_init();
  this.mUI.mainFrame = new Frame(this.mStr[6][this.lan]);
  this.mUI.mainFrame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent windowEvent) {
    if (App.this.mVar.transceiverFrameClass.mloralib != null) {
     App.this.mVar.transceiverFrameClass.mloralib.FunLora_close();
    }

    System.exit(0);
   }
  });
  this.mUI.mainFrame.setSize(this.mVar.Win_Width, this.mVar.Win_High + 60);
  this.mUI.mainFrame.setMinimumSize(new Dimension(this.mVar.Win_Width, this.mVar.Win_High + 60));
  this.mUI.mainFrame.setMaximumSize(new Dimension(this.mVar.Win_Width, this.mVar.Win_High + 60));
  this.mUI.mainFrame.setResizable(false);
  this.mUI.mainFrame.setLayout(null);
  this.ui_Step1(this.mUI.mainFrame);
  this.mUI.mainFrame.setVisible(true);
  this.mUI.mainFrame.addComponentListener(new ComponentListener() {
   public void componentResized(ComponentEvent e) {
   }

   public void componentMoved(ComponentEvent e) {
   }

   public void componentShown(ComponentEvent e) {
   }

   public void componentHidden(ComponentEvent e) {
   }
  });
 }

 static void main(String[] args) {
  System.out.println("Hello, World");
  new App();
 }

 private void data_init() {
  String t1 = this.mVar.transceiverFrameClass.FunPreferencesLoad("Language", "0");
  if (t1 != "") {
   this.lan = Integer.parseInt(t1);
  }

 }

 public void ui_Step1(Frame mainFrame) {
  int y = 0;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mStr[0][this.lan]);
  l1.setSize(this.mVar.Win_Width, 30);
  mainFrame.add(l1);
  l1.setLocation(10, 20 + this.mUI.tUITop);
  Button preferencesButton = new Button(this.mStr[1][this.lan]);
  preferencesButton.setBounds(100, 100, 300, 30);
  mainFrame.add(preferencesButton);
  preferencesButton.setLocation(50, y + 40 + this.mUI.tUITop + preferencesButton.size().height / 2);
  preferencesButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    App.this.mVar.transceiverFrameClass.FunPreferencesSave("APP", "0");
    App.this.mVar.transceiverFrameClass.ifroglablora_main(App.this.mVar.appClass);
    App.this.mUI.mainFrame.setVisible(false);
   }
  });
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mStr[2][this.lan]);
  l2.setSize(500, 60);
  mainFrame.add(l2);
  l2.setLocation(50, 75 + this.mUI.tUITop);
  Button TCPButton = new Button(this.mStr[4][this.lan]);
  TCPButton.setBounds(100, 100, 300, 30);
  mainFrame.add(TCPButton);
  TCPButton.setLocation(50, y + 140 + this.mUI.tUITop + preferencesButton.size().height / 2);
  TCPButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    App.this.mVar.transceiverFrameClass.FunPreferencesSave("APP", "1");
   }
  });
  Label l3 = new Label();
  l3.setAlignment(0);
  l3.setText(this.mStr[5][this.lan]);
  l3.setSize(500, 60);
  mainFrame.add(l3);
  l3.setLocation(50, 175 + this.mUI.tUITop);
  this.mUI.mDirect2APP = new Checkbox(this.mStr[3][this.lan]);
  this.mUI.mDirect2APP.setSize(400, 30);
  mainFrame.add(this.mUI.mDirect2APP);
  this.mUI.mDirect2APP.setLocation(50, 240 + this.mUI.tUITop);
  this.mUI.mDirect2APP.setState(Boolean.parseBoolean(this.mVar.transceiverFrameClass.FunPreferencesLoad("mDirect2APP", "true")));
  this.mUI.mDirect2APP.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    App.this.mVar.transceiverFrameClass.FunPreferencesSave("mDirect2APP", tcheck);
   }
  });
  Label l4 = new Label();
  l4.setAlignment(0);
  l4.setText(this.mStr[7][this.lan] + this.mVar.Version);
  l4.setSize(500, 60);
  mainFrame.add(l4);
  l4.setLocation(50, 260 + this.mUI.tUITop);
 }

public static class UI {
  public Choice mUIComPortName;
  public int tUITop = 30;
  public Frame mainFrame;
  public Checkbox mDirect2APP;
 }

 public static class Var {
  public String Version = "1.20190818";
  public int Win_Width = 600;
  public int Win_High = 300;
  private App appClass;
  private TransceiverFrame transceiverFrameClass;
 }
}

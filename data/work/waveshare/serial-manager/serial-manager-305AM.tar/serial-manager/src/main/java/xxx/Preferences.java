package xxx;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.JFileChooser;

public class Preferences {
 private TextField TextFieldUrl;
 private Checkbox checkBoxSaveLog;
 private Checkbox checkBoxUpload;
 private Checkbox checkBoxDashboard;
 private Checkbox checkBoxMQTT;
 private Button ButtonLogFileName;
 private Choice mChoicePower;
 private Choice ChoiceBaudRate;
 public int[] ChoiceBaudRateArray = new int[]{1200, 2400, 4800, 19200, 38400, 57600, 115200};
 static final int H_SIZE = 500;
 static final int V_SIZE = 490;
 private Frame mainFrame;
 private Transceiver mLo;
 private TextField TextFieldmHz;

 public Preferences(Transceiver iifroglablora) {
  this.mLo = iifroglablora;
  String t1 = iifroglablora.loadPreferences("Language", "0");
  if (t1 != "") {
   this.mLo.lan = Integer.parseInt(t1);
  }

  this.mainFrame = new Frame();
  this.mainFrame = new Frame(this.mLo.mStr[14][this.mLo.lan]);
  this.mainFrame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent windowEvent) {
    Preferences.this.mainFrame.dispose();
   }
  });
  this.mainFrame.setSize(500, 490);
  this.mainFrame.setMinimumSize(new Dimension(500, 490));
  this.mainFrame.setMaximumSize(new Dimension(500, 490));
  this.mainFrame.setResizable(false);
  this.mainFrame.setLayout((LayoutManager)null);
  this.ui_Step1(this.mainFrame);
  this.ui_Step2(this.mainFrame);
  this.ui_Step3(this.mainFrame);
  this.mainFrame.setVisible(true);
  this.mainFrame.addComponentListener(new ComponentListener() {
   public void componentResized(ComponentEvent e) {
   }

   public void componentMoved(ComponentEvent e) {
   }

   public void componentShown(ComponentEvent e) {
   }

   public void componentHidden(ComponentEvent e) {
   }
  });
 }

 public void ui_Step1(final Frame mainFrame) {
  int tUITop = 0;
  int y = 0;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mLo.mStr[56][this.mLo.lan]);
  l1.setSize(140, 25);
  mainFrame.add(l1);
  l1.setLocation(10, y + 50 + tUITop);
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mLo.mStr[57][this.mLo.lan]);
  l2.setSize(140, 25);
  mainFrame.add(l2);
  l2.setLocation(10, y + 75 + tUITop);
  final Choice ChoiceLanguage = new Choice();
  ChoiceLanguage.setBounds(100, 100, 100, 30);
  ChoiceLanguage.add("English");
  ChoiceLanguage.add("Chinese");
  mainFrame.add(ChoiceLanguage);
  ChoiceLanguage.setLocation(150, y + 55 + tUITop + ChoiceLanguage.size().height / 2);
  ChoiceLanguage.select(this.mLo.lan);
  ChoiceLanguage.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    String t1 = Integer.toString(ChoiceLanguage.getSelectedIndex());
    Preferences.this.mLo.savePreference("Language", t1);
    MessageDialog aboutDialog = new MessageDialog(mainFrame, Preferences.this.mLo.mStr[58][Preferences.this.mLo.lan], 500, 100);
    aboutDialog.setVisible(true);
   }
  });
  Label lineLabel = new Label();
  lineLabel.setAlignment(0);
  lineLabel.setText("");
  lineLabel.setSize(500, 1);
  lineLabel.setBackground(Color.lightGray);
  mainFrame.add(lineLabel);
  lineLabel.setLocation(0, y + 100 + tUITop);
 }

 public void ui_Step2(Frame mainFrame) {
  int tUITop = 110;
  int y = 0;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mLo.mStr[49][this.mLo.lan]);
  l1.setSize(100, 25);
  mainFrame.add(l1);
  l1.setLocation(10, y + 0 + tUITop);
  Label l2 = new Label();
  l2.setAlignment(0);
  l2.setText(this.mLo.mStr[50][this.mLo.lan]);
  l2.setSize(300, 25);
  mainFrame.add(l2);
  l2.setLocation(10, y + 30 + tUITop);
  this.TextFieldmHz = new TextField(this.mLo.mStr[48][this.mLo.lan]);
  this.TextFieldmHz.setBounds(80, 150, 80, 30);
  mainFrame.add(this.TextFieldmHz);
  this.TextFieldmHz.setText(this.mLo.Frequency);
  this.TextFieldmHz.setLocation(320, y + 30 + tUITop);
  this.TextFieldmHz.addTextListener(new TextListener() {
   public void textValueChanged(TextEvent e) {
    String tFrequency = Preferences.this.TextFieldmHz.getText();
    if (tFrequency.length() > 0) {
     float tfloatFrequency = Float.parseFloat(tFrequency);
     if (tfloatFrequency >= 137.0F && tfloatFrequency <= 1020.0F) {
      Preferences.this.mLo.Frequency = tFrequency;
      Preferences.this.mLo.savePreference("Frequency", tFrequency);
      System.out.println("Entered text: " + tFrequency);
     }
    }

   }
  });
  Label l3 = new Label();
  l3.setAlignment(0);
  l3.setText(this.mLo.mStr[51][this.mLo.lan]);
  l3.setSize(150, 25);
  mainFrame.add(l3);
  l3.setLocation(10, y + 60 + tUITop);
  this.mChoicePower = new Choice();
  this.mChoicePower.setBounds(100, 100, 120, 30);

  for(int i = 0; i <= 15; ++i) {
   this.mChoicePower.add(Integer.toString(i + 2) + " dBm");
  }

  this.mChoicePower.select(this.mLo.Power);
  mainFrame.add(this.mChoicePower);
  this.mChoicePower.setLocation(270, 60 + tUITop);
  this.mChoicePower.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(Preferences.this.mChoicePower.getItem(Preferences.this.mChoicePower.getSelectedIndex()));
    int t1 = Preferences.this.mChoicePower.getSelectedIndex();
    Preferences.this.mLo.savePreference("Power", Integer.toString(t1));
   }
  });
  Label l4 = new Label();
  l4.setAlignment(0);
  l4.setText(this.mLo.mStr[61][this.mLo.lan]);
  l4.setSize(340, 25);
  mainFrame.add(l4);
  l4.setLocation(10, y + 85 + tUITop);
  this.ChoiceBaudRate = new Choice();
  this.ChoiceBaudRate.setBounds(100, 100, 180, 30);

  for(int i = 0; i <= 6; ++i) {
   this.ChoiceBaudRate.add(this.ChoiceBaudRateArray[i] + " bps");
  }

  this.ChoiceBaudRate.select(this.mLo.Power);
  mainFrame.add(this.ChoiceBaudRate);
  this.ChoiceBaudRate.setLocation(350, 88 + tUITop);
  String t4 = this.mLo.loadPreferences("BaudRate", "115200");
  int t3 = Integer.parseInt(t4);
  int ChoiceBaudRateIndex = 0;

  for(int i = 0; i <= 6; ++i) {
   if (this.ChoiceBaudRateArray[i] == t3) {
    ChoiceBaudRateIndex = i;
    break;
   }
  }

  this.ChoiceBaudRate.select(ChoiceBaudRateIndex);
  this.ChoiceBaudRate.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(Preferences.this.ChoiceBaudRate.getItem(Preferences.this.ChoiceBaudRate.getSelectedIndex()));
    int t1 = Preferences.this.ChoiceBaudRate.getSelectedIndex();
    String t2 = String.valueOf(Preferences.this.ChoiceBaudRateArray[t1]);
    Preferences.this.mLo.savePreference("BaudRate", t2);
   }
  });
  Label lineLabel = new Label();
  lineLabel.setAlignment(0);
  lineLabel.setText("");
  lineLabel.setSize(500, 1);
  lineLabel.setBackground(Color.lightGray);
  mainFrame.add(lineLabel);
  lineLabel.setLocation(0, 120 + tUITop);
 }

 public void ui_Step3(Frame mainFrame) {
  int tUITop = 90;
  int y = 150;
  Label l1 = new Label();
  l1.setAlignment(0);
  l1.setText(this.mLo.mStr[52][this.mLo.lan]);
  l1.setSize(150, 25);
  mainFrame.add(l1);
  l1.setLocation(10, y + 0 + tUITop);
  this.checkBoxDashboard = new Checkbox();
  this.checkBoxDashboard.setLabel(this.mLo.mStr[45][this.mLo.lan]);
  this.checkBoxDashboard.setSize(170, 30);
  mainFrame.add(this.checkBoxDashboard);
  this.checkBoxDashboard.setState(Boolean.parseBoolean(this.mLo.loadPreferences("checkBoxDashboard", "true")));
  this.checkBoxDashboard.setLocation(10, y + 30 + tUITop);
  this.checkBoxDashboard.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    Preferences.this.mLo.savePreference("checkBoxDashboard", tcheck);
   }
  });
  Button ButtonIoT = new Button(this.mLo.mStr[46][this.mLo.lan]);
  ButtonIoT.setBounds(100, 100, 140, 30);
  ButtonIoT.setLocation(280, y + 30 + tUITop);
  mainFrame.add(ButtonIoT);
  ButtonIoT.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    if (Desktop.isDesktopSupported()) {
     try {
      Desktop.getDesktop().browse(new URI(Preferences.this.mLo.mURL[7] + Preferences.this.mLo.ProjectId));
     } catch (IOException e1) {
      e1.printStackTrace();
     } catch (URISyntaxException e1) {
      e1.printStackTrace();
     }
    }

   }
  });
  this.checkBoxUpload = new Checkbox();
  this.checkBoxUpload.setLabel(this.mLo.mStr[53][this.mLo.lan]);
  this.checkBoxUpload.setSize(250, 30);
  mainFrame.add(this.checkBoxUpload);
  this.checkBoxUpload.setState(Boolean.parseBoolean(this.mLo.loadPreferences("checkBoxUpload", "false")));
  this.checkBoxUpload.setLocation(10, y + 60 + tUITop);
  this.checkBoxUpload.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    Preferences.this.mLo.savePreference("checkBoxUpload", tcheck);
   }
  });
  this.TextFieldUrl = new TextField(this.mLo.mStr[48][this.mLo.lan]);
  this.TextFieldUrl.setBounds(280, 150, 440, 30);
  mainFrame.add(this.TextFieldUrl);
  this.TextFieldUrl.setLocation(50, y + 90 + tUITop);
  this.checkBoxSaveLog = new Checkbox();
  this.checkBoxSaveLog.setLabel(this.mLo.mStr[47][this.mLo.lan]);
  this.checkBoxSaveLog.setSize(110, 30);
  mainFrame.add(this.checkBoxSaveLog);
  this.checkBoxSaveLog.setState(Boolean.parseBoolean(this.mLo.loadPreferences("checkBoxSaveLog", "false")));
  this.checkBoxSaveLog.setLocation(10, y + 120 + tUITop);
  this.checkBoxSaveLog.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    Preferences.this.mLo.savePreference("checkBoxSaveLog", tcheck);
   }
  });
  File f = new File(this.mLo.StringLogFileName);
  this.ButtonLogFileName = new Button(f.getName());
  this.ButtonLogFileName.setBounds(100, 100, 140, 30);
  mainFrame.add(this.ButtonLogFileName);
  this.ButtonLogFileName.setLocation(120, y + 120 + tUITop);
  this.ButtonLogFileName.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
    int result = fileChooser.showSaveDialog((Component)null);
    if (result == 0) {
     File selectedFile = fileChooser.getSelectedFile();
     Preferences.this.mLo.StringLogFileName = selectedFile.getAbsolutePath();
     Preferences.this.mLo.savePreference("StringLogFileName", Preferences.this.mLo.StringLogFileName);
     String LogFileName2 = selectedFile.getName();
     System.out.println("Selected file: " + Preferences.this.mLo.StringLogFileName);
     Preferences.this.ButtonLogFileName.setLabel(LogFileName2);
    }

   }
  });
  this.checkBoxMQTT = new Checkbox();
  this.checkBoxMQTT.setLabel(this.mLo.mStr[54][this.mLo.lan]);
  this.checkBoxMQTT.setSize(150, 30);
  this.checkBoxMQTT.setState(Boolean.parseBoolean(this.mLo.loadPreferences("checkBoxMQTT", "false")));
  this.checkBoxMQTT.setLocation(10, y + 150 + tUITop);
  this.checkBoxMQTT.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    Preferences.this.mLo.savePreference("checkBoxMQTT", tcheck);
   }
  });
  Label lineLabel = new Label();
  lineLabel.setAlignment(0);
  lineLabel.setText("");
  lineLabel.setSize(500, 1);
  lineLabel.setBackground(Color.lightGray);
  mainFrame.add(lineLabel);
  lineLabel.setLocation(0, y + 170 + tUITop);
  new Checkbox();
  Checkbox mDirect2APP = new Checkbox(this.mLo.mStr[59][this.mLo.lan]);
  mDirect2APP.setSize(1650, 25);
  mainFrame.add(mDirect2APP);
  mDirect2APP.setState(Boolean.parseBoolean(this.mLo.loadPreferences("mDirect2APP", "true")));
  mDirect2APP.setLocation(10, y + 180 + tUITop);
  mDirect2APP.addItemListener(new ItemListener() {
   public void itemStateChanged(ItemEvent e) {
    System.out.println(" Checkbox: " + (e.getStateChange() == 1 ? "checked" : "unchecked"));
    String tcheck = "false";
    if (e.getStateChange() == 1) {
     tcheck = "true";
    }

    Preferences.this.mLo.savePreference("mDirect2APP", tcheck);
   }
  });
  Label l4 = new Label();
  l4.setAlignment(0);
  l4.setText(this.mLo.mStr[58][this.mLo.lan]);
  l4.setSize(580, 30);
  mainFrame.add(l4);
  l4.setLocation(10, y + 200 + tUITop);
 }
}


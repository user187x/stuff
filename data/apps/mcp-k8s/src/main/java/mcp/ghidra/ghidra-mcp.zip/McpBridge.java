//Persistent HTTP bridge that exposes the current Ghidra program to the kubernetes-style MCP server.
//Run this from Ghidra's Script Manager with a program open. It blocks, serving on 127.0.0.1:8765
//(override with GHIDRA_MCP_PORT). Stop it by cancelling the script.
//@category MCP
//@keybinding
//@menupath
//@toolbar

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.script.GhidraScript;
import ghidra.app.util.DisplayableEol;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSetView;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.*;
import ghidra.program.util.DefinedDataIterator;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class McpBridge extends GhidraScript {

    private HttpServer server;
    private DecompInterface decomp;

    @Override
    protected void run() throws Exception {
        int port = 8765;
        String env = System.getenv("GHIDRA_MCP_PORT");
        if (env != null) try { port = Integer.parseInt(env.trim()); } catch (NumberFormatException ignored) {}

        decomp = new DecompInterface();
        decomp.openProgram(currentProgram);

        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.createContext("/", this::route);
        server.setExecutor(null);
        server.start();

        println("[McpBridge] serving on http://127.0.0.1:" + port + " for program: " + currentProgram.getName());
        println("[McpBridge] Cancel this script (X in the console) to stop the server.");

        try {
            while (!monitor.isCancelled()) Thread.sleep(500);
        } finally {
            server.stop(0);
            decomp.dispose();
            println("[McpBridge] stopped.");
        }
    }

    // ---------------- routing ----------------

    private void route(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        Map<String, String> q = query(ex.getRequestURI().getRawQuery());
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        try {
            String json;
            switch (path) {
                case "/ping":            json = jobj("status", "ok", "program", safe(currentProgram.getName())); break;
                case "/program_info":    json = programInfo(); break;
                case "/functions":       json = listFunctions(q); break;
                case "/decompile":       json = decompile(q); break;
                case "/disassemble":     json = disassemble(q); break;
                case "/xrefs":           json = xrefs(q); break;
                case "/symbols":         json = symbols(q); break;
                case "/strings":         json = strings(q); break;
                case "/imports":         json = imports(); break;
                case "/exports":         json = exports(); break;
                case "/segments":        json = segments(); break;
                case "/read_bytes":      json = readBytes(q); break;
                case "/rename":          json = rename(q); break;
                case "/set_comment":     json = setComment(q); break;
                case "/set_prototype":   json = setPrototype(q); break;
                case "/data_at":         json = dataAt(q); break;
                default:
                    respond(ex, 404, jobj("error", "unknown endpoint: " + path));
                    return;
            }
            respond(ex, 200, json);
        } catch (Exception e) {
            respond(ex, 500, jobj("error", e.getClass().getSimpleName() + ": " + safe(e.getMessage())));
        }
    }

    // ---------------- endpoints ----------------

    private String programInfo() {
        Listing l = currentProgram.getListing();
        StringBuilder b = new StringBuilder("{");
        kv(b, "name", currentProgram.getName()); b.append(',');
        kv(b, "language", currentProgram.getLanguageID().getIdAsString()); b.append(',');
        kv(b, "compiler", currentProgram.getCompilerSpec().getCompilerSpecID().getIdAsString()); b.append(',');
        kv(b, "image_base", currentProgram.getImageBase().toString()); b.append(',');
        kvRaw(b, "pointer_bits", String.valueOf(currentProgram.getDefaultPointerSize() * 8)); b.append(',');
        kvRaw(b, "function_count", String.valueOf(currentProgram.getFunctionManager().getFunctionCount())); b.append(',');
        kv(b, "executable_path", currentProgram.getExecutablePath()); b.append(',');
        kv(b, "executable_md5", currentProgram.getExecutableMD5()); b.append(',');
        kv(b, "executable_sha256", currentProgram.getExecutableSHA256());
        b.append('}');
        return b.toString();
    }

    private String listFunctions(Map<String, String> q) {
        String filter = q.getOrDefault("filter", "").toLowerCase();
        int limit = intp(q, "limit", 1000);
        int offset = intp(q, "offset", 0);
        List<String> rows = new ArrayList<>();
        int i = 0;
        for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
            if (!filter.isEmpty() && !f.getName().toLowerCase().contains(filter)) continue;
            if (i++ < offset) continue;
            if (rows.size() >= limit) break;
            StringBuilder b = new StringBuilder("{");
            kv(b, "name", f.getName()); b.append(',');
            kv(b, "entry", f.getEntryPoint().toString()); b.append(',');
            kvRaw(b, "size", String.valueOf(f.getBody().getNumAddresses())); b.append(',');
            kv(b, "signature", f.getSignature().getPrototypeString()); b.append(',');
            kvRaw(b, "is_thunk", String.valueOf(f.isThunk())); b.append(',');
            kvRaw(b, "is_external", String.valueOf(f.isExternal()));
            b.append('}');
            rows.add(b.toString());
        }
        return "{\"count\":" + rows.size() + ",\"functions\":[" + String.join(",", rows) + "]}";
    }

    private Function resolveFunction(Map<String, String> q) {
        if (q.containsKey("address")) {
            Address a = addr(q.get("address"));
            Function f = currentProgram.getFunctionManager().getFunctionContaining(a);
            if (f != null) return f;
        }
        if (q.containsKey("name")) {
            for (Function f : currentProgram.getFunctionManager().getFunctions(true))
                if (f.getName().equals(q.get("name"))) return f;
        }
        return null;
    }

    private String decompile(Map<String, String> q) {
        Function f = resolveFunction(q);
        if (f == null) return jobj("error", "function not found (pass name or address)");
        int timeout = intp(q, "timeout", 60);
        DecompileResults res = decomp.decompileFunction(f, timeout, monitor);
        if (res == null || !res.decompileCompleted())
            return jobj("error", "decompile failed: " + (res == null ? "null" : safe(res.getErrorMessage())));
        String code = res.getDecompiledFunction().getC();
        StringBuilder b = new StringBuilder("{");
        kv(b, "name", f.getName()); b.append(',');
        kv(b, "entry", f.getEntryPoint().toString()); b.append(',');
        kv(b, "signature", f.getSignature().getPrototypeString()); b.append(',');
        kv(b, "c", code);
        b.append('}');
        return b.toString();
    }

    private String disassemble(Map<String, String> q) {
        Function f = resolveFunction(q);
        AddressSetView body;
        String header;
        if (f != null) { body = f.getBody(); header = f.getName(); }
        else if (q.containsKey("address")) {
            Address start = addr(q.get("address"));
            int count = intp(q, "count", 50);
            List<String> lines = new ArrayList<>();
            InstructionIterator it = currentProgram.getListing().getInstructions(start, true);
            int n = 0;
            while (it.hasNext() && n++ < count) {
                Instruction ins = it.next();
                lines.add(insLine(ins));
            }
            return "{\"from\":" + jstr(start.toString()) + ",\"instructions\":[" + String.join(",", lines) + "]}";
        } else return jobj("error", "pass name or address");

        List<String> lines = new ArrayList<>();
        InstructionIterator it = currentProgram.getListing().getInstructions(body, true);
        while (it.hasNext()) lines.add(insLine(it.next()));
        return "{\"function\":" + jstr(header) + ",\"instructions\":[" + String.join(",", lines) + "]}";
    }

    private String insLine(Instruction ins) {
        StringBuilder b = new StringBuilder("{");
        kv(b, "addr", ins.getAddress().toString()); b.append(',');
        kv(b, "mnemonic", ins.getMnemonicString()); b.append(',');
        kv(b, "text", ins.toString());
        DisplayableEol eol = new DisplayableEol(ins, true, true, true, true, 5, true, true);
        String cmt = eol.getComments().length > 0 ? String.join(" ", eol.getComments()) : null;
        if (cmt != null && !cmt.isEmpty()) { b.append(','); kv(b, "comment", cmt); }
        b.append('}');
        return b.toString();
    }

    private String xrefs(Map<String, String> q) {
        Address target;
        if (q.containsKey("address")) target = addr(q.get("address"));
        else {
            Function f = resolveFunction(q);
            if (f == null) return jobj("error", "pass address or a resolvable name");
            target = f.getEntryPoint();
        }
        List<String> to = new ArrayList<>();
        for (Reference r : getReferencesTo(target)) {
            Function from = currentProgram.getFunctionManager().getFunctionContaining(r.getFromAddress());
            StringBuilder b = new StringBuilder("{");
            kv(b, "from", r.getFromAddress().toString()); b.append(',');
            kv(b, "type", r.getReferenceType().getName()); b.append(',');
            kv(b, "in_function", from != null ? from.getName() : "");
            b.append('}');
            to.add(b.toString());
        }
        return "{\"target\":" + jstr(target.toString()) + ",\"references_to\":[" + String.join(",", to) + "]}";
    }

    private String symbols(Map<String, String> q) {
        String filter = q.getOrDefault("filter", "").toLowerCase();
        int limit = intp(q, "limit", 1000);
        List<String> rows = new ArrayList<>();
        SymbolIterator it = currentProgram.getSymbolTable().getAllSymbols(true);
        while (it.hasNext() && rows.size() < limit) {
            Symbol s = it.next();
            if (!filter.isEmpty() && !s.getName().toLowerCase().contains(filter)) continue;
            StringBuilder b = new StringBuilder("{");
            kv(b, "name", s.getName()); b.append(',');
            kv(b, "address", s.getAddress().toString()); b.append(',');
            kv(b, "type", s.getSymbolType().toString()); b.append(',');
            kvRaw(b, "primary", String.valueOf(s.isPrimary()));
            b.append('}');
            rows.add(b.toString());
        }
        return "{\"count\":" + rows.size() + ",\"symbols\":[" + String.join(",", rows) + "]}";
    }

    private String strings(Map<String, String> q) {
        int minLen = intp(q, "min_length", 4);
        int limit = intp(q, "limit", 2000);
        String filter = q.getOrDefault("filter", "").toLowerCase();
        List<String> rows = new ArrayList<>();
        for (Data d : DefinedDataIterator.definedStrings(currentProgram)) {
            Object val = d.getValue();
            if (val == null) continue;
            String sv = val.toString();
            if (sv.length() < minLen) continue;
            if (!filter.isEmpty() && !sv.toLowerCase().contains(filter)) continue;
            StringBuilder b = new StringBuilder("{");
            kv(b, "address", d.getAddress().toString()); b.append(',');
            kv(b, "value", sv);
            b.append('}');
            rows.add(b.toString());
            if (rows.size() >= limit) break;
        }
        return "{\"count\":" + rows.size() + ",\"strings\":[" + String.join(",", rows) + "]}";
    }

    private String imports() {
        List<String> rows = new ArrayList<>();
        SymbolIterator it = currentProgram.getSymbolTable().getExternalSymbols();
        while (it.hasNext()) {
            Symbol s = it.next();
            StringBuilder b = new StringBuilder("{");
            kv(b, "name", s.getName()); b.append(',');
            kv(b, "library", s.getParentNamespace() != null ? s.getParentNamespace().getName() : "");
            b.append('}');
            rows.add(b.toString());
        }
        return "{\"count\":" + rows.size() + ",\"imports\":[" + String.join(",", rows) + "]}";
    }

    private String exports() {
        List<String> rows = new ArrayList<>();
        SymbolTable st = currentProgram.getSymbolTable();
        SymbolIterator it = st.getAllSymbols(true);
        while (it.hasNext()) {
            Symbol s = it.next();
            if (!s.isExternalEntryPoint()) continue;
            StringBuilder b = new StringBuilder("{");
            kv(b, "name", s.getName()); b.append(',');
            kv(b, "address", s.getAddress().toString());
            b.append('}');
            rows.add(b.toString());
        }
        return "{\"count\":" + rows.size() + ",\"exports\":[" + String.join(",", rows) + "]}";
    }

    private String segments() {
        List<String> rows = new ArrayList<>();
        for (MemoryBlock blk : currentProgram.getMemory().getBlocks()) {
            StringBuilder b = new StringBuilder("{");
            kv(b, "name", blk.getName()); b.append(',');
            kv(b, "start", blk.getStart().toString()); b.append(',');
            kv(b, "end", blk.getEnd().toString()); b.append(',');
            kvRaw(b, "size", String.valueOf(blk.getSize())); b.append(',');
            kvRaw(b, "r", String.valueOf(blk.isRead())); b.append(',');
            kvRaw(b, "w", String.valueOf(blk.isWrite())); b.append(',');
            kvRaw(b, "x", String.valueOf(blk.isExecute())); b.append(',');
            kvRaw(b, "initialized", String.valueOf(blk.isInitialized()));
            b.append('}');
            rows.add(b.toString());
        }
        return "{\"segments\":[" + String.join(",", rows) + "]}";
    }

    private String readBytes(Map<String, String> q) throws Exception {
        Address a = addr(q.get("address"));
        int len = Math.min(intp(q, "length", 64), 4096);
        byte[] buf = new byte[len];
        int n = currentProgram.getMemory().getBytes(a, buf);
        StringBuilder hex = new StringBuilder();
        for (int i = 0; i < n; i++) hex.append(String.format("%02x", buf[i] & 0xff));
        return "{\"address\":" + jstr(a.toString()) + ",\"length\":" + n + ",\"hex\":" + jstr(hex.toString()) + "}";
    }

    private String dataAt(Map<String, String> q) {
        Address a = addr(q.get("address"));
        Data d = currentProgram.getListing().getDataAt(a);
        if (d == null) return jobj("error", "no defined data at " + a);
        StringBuilder b = new StringBuilder("{");
        kv(b, "address", a.toString()); b.append(',');
        kv(b, "type", d.getDataType().getName()); b.append(',');
        kv(b, "value", String.valueOf(d.getValue()));
        b.append('}');
        return b.toString();
    }

    // ---------------- mutations (wrapped in a transaction) ----------------

    private String rename(Map<String, String> q) throws Exception {
        String newName = q.get("new_name");
        if (newName == null || newName.isEmpty()) return jobj("error", "new_name required");
        int tx = currentProgram.startTransaction("MCP rename");
        boolean ok = false;
        try {
            Function f = resolveFunction(q);
            if (f != null) {
                f.setName(newName, SourceType.USER_DEFINED);
                ok = true;
                return jobj("status", "ok", "kind", "function", "new_name", newName);
            }
            if (q.containsKey("address")) {
                Address a = addr(q.get("address"));
                Symbol s = currentProgram.getSymbolTable().getPrimarySymbol(a);
                if (s != null) { s.setName(newName, SourceType.USER_DEFINED); ok = true; }
                else { createLabel(a, newName, true); ok = true; }
                return jobj("status", "ok", "kind", "symbol", "new_name", newName);
            }
            return jobj("error", "pass name or address to rename");
        } finally {
            currentProgram.endTransaction(tx, ok);
        }
    }

    private String setComment(Map<String, String> q) {
        Address a = addr(q.get("address"));
        String comment = q.getOrDefault("comment", "");
        String type = q.getOrDefault("type", "eol").toLowerCase();
        int codeUnitType;
        switch (type) {
            case "pre":    codeUnitType = CodeUnit.PRE_COMMENT; break;
            case "post":   codeUnitType = CodeUnit.POST_COMMENT; break;
            case "plate":  codeUnitType = CodeUnit.PLATE_COMMENT; break;
            case "repeat": codeUnitType = CodeUnit.REPEATABLE_COMMENT; break;
            default:       codeUnitType = CodeUnit.EOL_COMMENT;
        }
        int tx = currentProgram.startTransaction("MCP comment");
        boolean ok = false;
        try {
            currentProgram.getListing().setComment(a, codeUnitType, comment);
            ok = true;
            return jobj("status", "ok", "address", a.toString(), "type", type);
        } finally { currentProgram.endTransaction(tx, ok); }
    }

    private String setPrototype(Map<String, String> q) throws Exception {
        Function f = resolveFunction(q);
        if (f == null) return jobj("error", "function not found");
        String proto = q.get("prototype");
        if (proto == null || proto.isEmpty()) return jobj("error", "prototype required");
        int tx = currentProgram.startTransaction("MCP prototype");
        boolean ok = false;
        try {
            ghidra.app.cmd.function.ApplyFunctionSignatureCmd cmd =
                new ghidra.app.cmd.function.ApplyFunctionSignatureCmd(
                    f.getEntryPoint(),
                    parseSignature(proto, f),
                    SourceType.USER_DEFINED);
            ok = cmd.applyTo(currentProgram, monitor);
            return jobj("status", ok ? "ok" : "failed", "signature", f.getSignature().getPrototypeString());
        } finally { currentProgram.endTransaction(tx, ok); }
    }

    private ghidra.program.model.data.FunctionDefinitionDataType parseSignature(String proto, Function f) throws Exception {
        ghidra.app.util.parser.FunctionSignatureParser parser =
            new ghidra.app.util.parser.FunctionSignatureParser(currentProgram.getDataTypeManager(), null);
        ghidra.program.model.data.FunctionDefinitionDataType def =
            (ghidra.program.model.data.FunctionDefinitionDataType) parser.parse(f.getSignature(), proto);
        return def;
    }

    // ---------------- helpers ----------------

    private Address addr(String s) {
        return currentProgram.getAddressFactory().getAddress(s);
    }

    private int intp(Map<String, String> q, String k, int def) {
        try { return q.containsKey(k) ? Integer.parseInt(q.get(k)) : def; } catch (Exception e) { return def; }
    }

    private void respond(HttpExchange ex, int code, String json) throws IOException {
        byte[] out = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json");
        ex.sendResponseHeaders(code, out.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(out); }
    }

    private Map<String, String> query(String raw) {
        Map<String, String> m = new HashMap<>();
        if (raw == null) return m;
        for (String pair : raw.split("&")) {
            int i = pair.indexOf('=');
            if (i < 0) continue;
            m.put(urlDecode(pair.substring(0, i)), urlDecode(pair.substring(i + 1)));
        }
        return m;
    }

    private String urlDecode(String s) {
        try { return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8); } catch (Exception e) { return s; }
    }

    private String jobj(String... kv) {
        StringBuilder b = new StringBuilder("{");
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (i > 0) b.append(',');
            kv(b, kv[i], kv[i + 1]);
        }
        return b.append('}').toString();
    }

    private void kv(StringBuilder b, String k, String v) {
        b.append(jstr(k)).append(':').append(jstr(v == null ? "" : v));
    }
    private void kvRaw(StringBuilder b, String k, String v) {
        b.append(jstr(k)).append(':').append(v);
    }

    private String jstr(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        return b.append('"').toString();
    }

    private String safe(String s) { return s == null ? "" : s; }
}

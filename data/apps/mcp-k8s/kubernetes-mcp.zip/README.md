# kubernetes-mcp

An MCP server that gives a model full triage → diagnose → fix → deploy capability over any Kubernetes cluster (minikube, k3d, kind, or a real one). It shells out to `kubectl`/`helm`/`minikube`/`k3d`/`kind`, so anything those tools can reach, the model can reach.

## Run

```bash
mvn -q package
java -jar target/kubernetes-mcp-2.0.0.jar
```

Connect a client to `http://localhost:8080/mcp` (Streamable HTTP) or `http://localhost:8080/sse` (legacy SSE).

### Environment variables

| Var | Default | Purpose |
|---|---|---|
| `MCP_PORT` | 8080 | Listen port |
| `MCP_READ_ONLY` | false | Refuse every mutating tool (safe for prod investigation) |
| `MCP_ALLOW_SHELL` | false | Enable `run_shell` (host shell: docker, kustomize, jq, …) |
| `MCP_KUBECONFIG` | – | Path passed as `--kubeconfig` |
| `MCP_CONTEXT` | – | Default context; any tool can override with `context` |
| `MCP_MAX_OUTPUT` | 60000 | Output cap in chars (head+tail kept on truncation) |

## Tools (33)

**Overview / discovery** — `cluster_overview`, `cluster_health_check` (automated problem finder: NotReady nodes, crashlooping/pending pods, restart counts, unavailable workloads, unbound PVCs, warning events, node usage), `kubectl_api_resources`, `kubectl_explain`, `kubectl_config`

**Inspect** — `kubectl_get` (selectors, jsonpath, custom-columns, sort), `kubectl_describe`, `kubectl_get_events` (warnings / per-object), `kubectl_logs` (previous, all containers, selector, since, regex grep), `kubectl_top`, `kubectl_rollout`, `kubectl_auth_can_i` (incl. impersonation), `kubectl_diff`, `kubectl_wait`

**In-cluster troubleshooting** — `kubectl_exec`, `kubectl_debug` (ephemeral containers, node debugging via `node/<name>`), `kubectl_run_pod` (throwaway pod with labels/SA for NetworkPolicy + RBAC testing), `service_probe` (port-forward + curl from host), `kubectl_cp`

**Fix / deploy** — `kubectl_apply` (dry-run client/server, server-side apply, prune), `kubectl_patch` (strategic/merge/json, subresources), `kubectl_scale`, `kubectl_set` (image/env/resources/serviceaccount), `kubectl_label_annotate`, `kubectl_create` (ns, cm/secret from literals, SA, job-from-cronjob, token), `kubectl_delete` (force for stuck Terminating; `confirm=true` required for namespaces/nodes/CRDs/PVs/`all`), `kubectl_node_ops` (cordon/uncordon/drain/taint)

**Escape hatches** — `kubectl_raw` (any kubectl args + stdin), `helm` (any helm args + stdin values), `local_cluster` (minikube/k3d/kind), `run_shell` (gated)

All tools carry MCP `readOnlyHint`/`destructiveHint` annotations so clients can prompt before destructive calls.

## Prompts

`triage_cluster`, `debug_workload(workload, namespace)`, `debug_networking(service, namespace)` — ready-made playbooks the model can pull in.

## Safety notes

- Every command is built as an argv list — no host shell interpolation (except the explicitly-gated `run_shell`).
- All processes have timeouts and are force-killed on expiry; ephemeral probe pods are cleaned up on timeout.
- `kubectl config view` output is redacted by kubectl by default; `kubectl_get secrets -o yaml` is not — run in `MCP_READ_ONLY` with a restricted kubeconfig/ServiceAccount if the model shouldn't see secrets.

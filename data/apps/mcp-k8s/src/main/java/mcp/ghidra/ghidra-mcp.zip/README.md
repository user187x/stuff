# ghidra-mcp

An MCP server that gives a model reverse-engineering control over Ghidra. It works in two modes that share one tool surface:

1. **Live** — talks to an **open Ghidra program** through a small HTTP bridge script (`McpBridge.java`) you run inside Ghidra. Decompile, disassemble, list functions/strings/imports, follow xrefs, and write back renames/comments/prototypes that persist in the Ghidra database.
2. **Headless** — drives `analyzeHeadless` to import, auto-analyze, script, and export binaries **without the GUI**, for files sitting on disk.

Same Javalin + Gson stack and dual SSE / Streamable-HTTP transport as the kubernetes-mcp server.

## Architecture

```
  MCP client ──JSON-RPC──▶  ghidra-mcp (this jar, :8080)
                                 │
                 live ──────────┤ HTTP ─▶  McpBridge.java  (runs inside Ghidra, :8765)
                                 │                             └▶ current program API
                 headless ──────┘ exec ─▶  $GHIDRA_HOME/support/analyzeHeadless
```

## Setup

### 1. Build the server
```bash
mvn -q package
java -jar target/ghidra-mcp-1.0.0.jar
```
Connect a client to `http://localhost:8080/mcp` (Streamable HTTP) or `http://localhost:8080/sse`.

### 2. For live tools — start the in-Ghidra bridge
Copy `ghidra_scripts/McpBridge.java` into a directory on Ghidra's script path (or add this folder via the Script Manager → *Script Directories*). Open your target program, then in the **Script Manager** run **McpBridge.java** (category *MCP*). It serves on `127.0.0.1:8765` and blocks until you cancel it. Leave it running while the model works.

### 3. For headless tools — point at your install
```bash
export GHIDRA_HOME=/opt/ghidra_11.x            # dir containing support/analyzeHeadless
export GHIDRA_MCP_SCRIPTS=$PWD/ghidra_scripts  # so headless_export can find ExportDecompiledC.java
```

### Environment variables

| Var | Default | Purpose |
|---|---|---|
| `MCP_PORT` | 8080 | Server listen port |
| `GHIDRA_BRIDGE_URL` | http://127.0.0.1:8765 | Where the in-Ghidra bridge listens |
| `GHIDRA_HOME` | – | Ghidra install (required for `headless_*`) |
| `GHIDRA_PROJECT_DIR` | temp/ghidra_mcp_projects | Where headless projects are created |
| `GHIDRA_MCP_SCRIPTS` | ./ghidra_scripts | Bundled-script dir for headless export |
| `MCP_READ_ONLY` | false | Refuse mutating tools (rename/comment/prototype/headless writes) |
| `MCP_MAX_OUTPUT` | 60000 | Output cap in chars |

The bridge port inside Ghidra can be set with `GHIDRA_MCP_PORT` before launching Ghidra.

## Tools (21)

**Live — inspect** · `bridge_status`, `program_info`, `list_functions`, `decompile_function`, `disassemble`, `get_xrefs`, `list_symbols`, `list_strings`, `list_imports`, `list_exports`, `list_segments`, `read_bytes`, `data_at`

**Live — annotate (persists)** · `rename` (function or symbol), `set_comment` (eol/pre/post/plate/repeat), `set_prototype` (apply a C signature)

**Headless (batch, no GUI)** · `headless_version`, `headless_analyze` (import + auto-analyze), `headless_run_script` (run any GhidraScript against a binary), `headless_export` (`c` = all pseudo-C via bundled `ExportDecompiledC.java`, or `ascii`/`html`/`xml`/`binary`)

All tools carry MCP `readOnlyHint` annotations.

## Prompts

`triage_binary` · `analyze_function(function)` · `hunt_capability(capability)` — ready-made RE playbooks the model can pull in.

## Typical flows

**Interactive:** open the program in Ghidra → run `McpBridge.java` → ask the model to `triage_binary`. It surveys imports/strings, decompiles `main`, follows xrefs, and renames + comments as it understands the code.

**Bulk:** no GUI needed → `headless_analyze` a sample, then `headless_export format=c` to get one C file of the whole program for the model to read, or `headless_run_script` to run your own extraction pass.

## Notes / caveats

- The bridge binds to loopback only. It exposes read **and** write (rename/comment/prototype) endpoints — anything with access to `:8765` can modify the open program, so keep it local. Set `MCP_READ_ONLY=true` on the MCP server if the model should never write.
- Ghidra's Java API changes between versions. This targets the 10.x–11.x `GhidraScript`/`DecompInterface` API. If a call signature differs on your build (e.g. `CodeUnit` comment constants, `DisplayableEol`, or the `-exporter` headless flag), adjust that one call — the structure stays the same.
- `set_prototype` parses the C prototype against the program's data type manager; unknown types must already exist in Ghidra (import the relevant data type archive first).
- Reverse engineering may be restricted by license terms or law depending on the target and your jurisdiction; use this only on binaries you're authorized to analyze.

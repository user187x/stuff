#!/bin/sh

touch /localFeatureA

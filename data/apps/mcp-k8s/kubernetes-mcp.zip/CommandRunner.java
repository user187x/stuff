package mcp;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Runs external processes with timeout, optional stdin, and output truncation. */
public final class CommandRunner {

    public record Result(int exitCode, String output, boolean timedOut) {
        public boolean failed() { return exitCode != 0 || timedOut; }
    }

    /** Maximum characters returned to the model (head + tail are kept when truncated). */
    public static final int MAX_OUTPUT = Integer.parseInt(System.getenv().getOrDefault("MCP_MAX_OUTPUT", "60000"));

    private CommandRunner() {}

    public static Result run(List<String> command, int timeoutSeconds) {
        return run(command, timeoutSeconds, null);
    }

    public static Result run(List<String> command, int timeoutSeconds, String stdin) {
        System.out.println(" -> 💻 " + String.join(" ", command));
        Process process = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(command);
            pb.redirectErrorStream(true);
            process = pb.start();

            if (stdin != null) {
                try (OutputStream os = process.getOutputStream()) {
                    os.write(stdin.getBytes(StandardCharsets.UTF_8));
                }
            } else {
                process.getOutputStream().close();
            }

            // Read output on a separate thread so a large output never blocks waitFor.
            final Process p = process;
            StringBuilder sb = new StringBuilder();
            Thread reader = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                    char[] buf = new char[8192];
                    int n;
                    while ((n = br.read(buf)) != -1) {
                        synchronized (sb) { sb.append(buf, 0, n); }
                    }
                } catch (IOException ignored) {}
            });
            reader.start();

            boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                reader.join(2000);
                String partial;
                synchronized (sb) { partial = sb.toString(); }
                return new Result(-1, truncate(partial) + "\n\n[TIMEOUT] Command exceeded " + timeoutSeconds + "s and was killed.", true);
            }
            reader.join();
            String out;
            synchronized (sb) { out = sb.toString(); }
            if (out.isBlank()) out = "(no output, exit code " + process.exitValue() + ")";
            return new Result(process.exitValue(), truncate(out), false);
        } catch (IOException e) {
            return new Result(127, "Error launching command '" + command.get(0) + "': " + e.getMessage()
                    + "\nIs it installed and on PATH?", false);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (process != null) process.destroyForcibly();
            return new Result(-1, "Interrupted", true);
        }
    }

    public static String truncate(String s) {
        if (s.length() <= MAX_OUTPUT) return s;
        int head = MAX_OUTPUT * 2 / 3;
        int tail = MAX_OUTPUT - head;
        return s.substring(0, head)
                + "\n\n... [TRUNCATED " + (s.length() - MAX_OUTPUT) + " chars — narrow with namespace/selector/grep/tail] ...\n\n"
                + s.substring(s.length() - tail);
    }

    /** Returns true if the binary is on PATH. */
    public static boolean available(String binary) {
        Result r = run(List.of(System.getProperty("os.name").toLowerCase().contains("win") ? "where" : "which", binary), 5);
        return !r.failed();
    }
}
